#ifndef CPYBUF_C
#define CPYBUF_C

#include "DBdefs.h"
#include "cl4.h"
int cpybuf(char *DEST, char *SOURCE, int Size)
{
	int i;
	//char *v4;
	//char *v6;

	//printf("cpybuf( DEST: x%08X, SRC: x%08X, Size : %d)\n", DEST, SOURCE, Size);

	for ( i = Size; i; --i )
	{
		*DEST++ = *SOURCE++;
	}
	return Size;
}

#endif
