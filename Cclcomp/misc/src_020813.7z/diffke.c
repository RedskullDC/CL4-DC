#ifndef DIFFKEY_C
#define DIFFKEY_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

// Potential name conflict with diffkey()!!!

int _diffkey(char *a1, char *a2, TDef *TdefP)
{
	TDef *tdef; // esi@1
	short TDFtype; // dx@2
	unsigned int v6; // eax@7
	unsigned int v7; // edi@7
	unsigned int v8; // eax@9
	unsigned int v13; // [sp+14h] [bp-14h]@6
	int v14; // [sp+18h] [bp-10h]@1
	int v15; // [sp+18h] [bp-10h]@13
	short v9; // ax@11
	short v10; // ax@14
	short v11; // ax@15

	//printf("_diffkey(a1 = %s, a2 = %s, TDef = x%08X)\n",a1,a2,TdefP);

	tdef = TdefP;
	v14 = 0;
	while ( tdef->TDFentry && (TDFtype = tdef->TDFtype, TDFtype & 1)) // indicates Key field
	{
		if ( TDFtype & 2 )
			v13 = _fwidth(&a1[v14], tdef->TDFsize, TDFtype);
		else
			v13 = tdef->TDFsize;
      
		if ( tdef->TDFtype & 2 )
		{
			v6 = _fwidth(&a2[v14], tdef->TDFsize, tdef->TDFtype);
			v7 = v6;
		}
		else
			v7 = tdef->TDFsize;
       
		v8 = v13;
		if ( v7 <= v13 )
			v8 = v7;
		v9 = _diffattrib(&a1[v14], &a2[v14], v8, tdef->TDFtype);
		
		if ( v9 < v13 || v9 < v7 )
		{
			v15 = (v9 + v14);
			if ( tdef->TDFtype & 0x10 && (v10 = numsz(&a2[v15], v7 - v9)) != 0 )
				v11 = v10 + v15;
			else
				v11 = v15 + 1;
			v14 = v11;
			//printf("_diffkey(v9<v7/13 v14 = %d\n",v14);
			return v14;
		}
		v14 = (v9 + v14);
		tdef++;
	}
	//printf("_diffkey(v14 = %d\n",v14);
	return v14;
}
#endif
