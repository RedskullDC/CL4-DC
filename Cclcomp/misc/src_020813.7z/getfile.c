#ifndef GETFILE_C
#define GETFILE_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

short tdopen_0(int DBno, TDesc *TTptr, int Lock);

// not public
int tgetfile(TDesc *TTptr)
{
     int result; // eax@1
     short Error; // ax@2
     int v3; // edi@2
     char *v4; // esi@5

     result = rdbget(TTptr->DBnumber);
     if ( result >= 0 )
     {
          Error = tdopen_0(result, TTptr, ((unsigned int)TTptr->TDlocked >> 6) & 1);
          v3 = Error;
          if ( Error < 0 )
          {
               if ( Error == -10 )
               {
                    eprint("table locked - %s\n", TTptr->TableName);
               }
               else
               {
                    v4 = TTptr->TableName;
                    if ( !cmpbuf(TTptr->TableName, "domains", 6u) )
                    {
                         if ( !cmpbuf(v4, "elements", 8u) )
                              eprint("can't identify - %s (err=%d)\n", v4, v3);
                    }
               }
          }
          result = v3;
     }
     return result;
}

short tdopen_0(int DBno, TDesc *TTptr, int Lock)
{
     short v4; // eax@5
     short v5; // si@5
     signed int v6; // edx@7
     FLDdesc *fld; // eax@17
     FLDdesc *j; // esi@17
     char FLDtype; // al@18
     int v10; // eax@19
     int v11; // eax@22
     int v12; // eax@36
     TDef *tdef;
     int TDno; // [sp+40h] [bp-2048h]@15
     TDef *v17; // [sp+44h] [bp-2044h]@6
     int RecSize; // [sp+48h] [bp-2040h]@7
     short NumFields; // [sp+4Ch] [bp-203Ch]@7
     char v20[32]; // [sp+50h] [bp-2038h]@21
     ELEMENTREC elem; // [sp+70h] [bp-2018h]@22

     if ( TTptr->TTrtd != -1 )
          __assert_fail("tt->runtd == -1", "getfile.c", 108u, "tdopen");

	if ( Lock )
		v4 = lidentify(DBno, TTptr->TableName);
	else
		v4 = identify(DBno, TTptr->TableName);

     v5 = v4;
     if ( v4 >= 0 )
     {
          v17 = tblrow(v4);
          v4 = -1;
          if ( v17 )
          {
               TTptr->TTrtd = v5;
               v6 = 0;
               tdef = v17;
               NumFields = 0;
               for ( RecSize = 0; tdef->TDFentry; ++tdef )
               {
                    RecSize += tdef->TDFsize;
                    v6 = (unsigned short)pcrc(v6, tdef, 2, 68, 3u);
                    NumFields++;
               }
               if ( !v6 )
                    v6 = 1;
               if ( TTptr->TableCRC )
               {
                    if ( TTptr->TableCRC != v6 )
                    {
                         eprint("table definition incompatibility (calc=%u, got=%u) - %s\n", v6, TTptr->TableCRC, TTptr->TableName);
                         return -1;
                    }
               }
               else
                    TTptr->TableCRC = v6;

               TTptr->TDworkarea1 = (char *)mmalloc(RecSize + 1);
               TTptr->TDworkarea2 = (char *)mmalloc(RecSize + 1);
               TTptr->NumFields = NumFields;
               TDno = identify(DBno, "elements");
               if ( TDno < 0 )
                    TDno = identify(DBno, "domains");
               fld = (FLDdesc *)mmalloc(24 * (NumFields + 1));
               TTptr->TTfields = fld;
               tdef = v17;
               for ( j = fld; tdef->TDFentry; ++tdef )
               {
                    FLDtype = gettype(tdef->TDFtype, tdef->TDFsize);
                    j->FLDtype = FLDtype;

					if ( FLDtype == 'C' )
                         v10 = tdef->TDFsize + 1;
                    else
                    {
                         if ( tdef->TDFsize )
                              v10 = 8;
                         else
                         {
                              v10 = 0;
                              v20[0] = 0;
                              if ( TDno > 0 )	// Read ELEMENTREC directly
                              {
                                   itoms(&elem.TDFentry, tdef->TDFentry);
                                   v11 = (signed short)getr(TDno, (char*)&elem, 0);
                                   if ( (signed short)v11 <= 0 )
                                   {
                                        if ( v11 < 0 )
                                             dberror(v11, 0, TDno);
                                        sprintf(v20, "%d", tdef->TDFentry);	// v11 == 0, not found. use TDFentry directly
                                   }
                                   else
                                        cdbcpystr(v20, elem.FieldName, 0);		// found a match, use FieldName instead.

								   v10 = strlen(v20) + 1;
                              }
                         }
                    }
                    j->FLDdata = mmalloc(2 * v10);	// twice as much space as is required??
                    if ( j->FLDtype == 'S' || j->FLDtype == 'K' )
                         cdbcpystr((char *)j->FLDdata, v20, 0);
                    if ( tdef->TDFtype & 1 )
                         j->FLDstat |= 0x8000u;		// KeyField
                    j->FLDstat |= 0x0004u;			// Quick ZERO flag
                    j->FLDlen	 = tdef->TDFsize;
                    j->FLDelemID = tdef->TDFentry;
                    j->TDFtype   = tdef->TDFtype;
                    ++j;
               }
               if ( TDno > 0 )
               {
                    v12 = release(TDno);
                    if ( v12 < 0 )
                         dberror(v12, 0, TDno);
               }
               TTptr->TDrecsize = RecSize;
               v4 = 0;
          }
     }
     return v4;
}


// different functionality to clenter/libcl4
int rtdget(TDesc *TTptr)
{

    if ( ttab > TTptr || TTptr >= &ttab[no_ttabs] )
        __assert_fail("ttab <= tt && tt < &ttab[no_ttabs]", "getfile.c", 178, "rtdget");

	if ( TTptr->TTrtd == -1 && tgetfile(TTptr) < 0 )
    {
        eprint("can't open table '%s'\n", TTptr->TableName);
        dberror(-98, TTptr->DBnumber, TTptr->TTrtd);
    }
    if ( TTptr->TTrtd < 0 || TTptr->TTrtd >= no_ttabs )
        __assert_fail("tt->runtd >= 0 && tt->runtd < no_ttabs", "getfile.c", 188,  "rtdget");

    return TTptr->TTrtd;
}

int getfile(char *DBname, char *TableName)
{
    DBase **v2; // ecx@7
    TDesc *TTptr; // esi@9
    char *Alias; // eax@16
    short DBno; // [sp+18h] [bp-10h]@1

printf("getfile  DBname = %s, TableName = %s\n", DBname, TableName);

    DBno = 0;
    while ( no_dtabs > DBno )
    {
		if ( !strcmp(DBname, dtab[DBno].FullDBname))
			break;
		DBno++;
    }
    if ( no_dtabs == DBno )
    {
        newdtab();
        if ( no_dtabs <= DBno )
            __assert_fail("dbii < no_dtabs", "getfile.c", 213u, "getfile");
    }
    v2 = &dtab;
    if ( !dtab[DBno].FullDBname )
    {
        dtab[DBno].DBno = -1;
        (*v2)[DBno].FullDBname = mstrcpy(DBname, 0);
    }
    for ( TTptr = ttab + 3; TTptr < &ttab[no_ttabs]; ++TTptr )
    {
        if ( !TTptr->TableName[0] )
            break;
        if ( !strcmp(TTptr->TableName, TableName) )
            break;
    }
    if ( TTptr == &ttab[no_ttabs] )
    {
        newttab();
        TTptr = &ttab[no_ttabs - 1];
    }
    if ( !TTptr->TableName[0] )
    {
        Alias = TableName;
        if ( *TableName )
        {
            if ( *TableName == ',' )
            {
LABEL_20:
                if ( *Alias )
                    *Alias++ = 0;
            }
            else
            {
                while ( 1 )
                {
                    ++Alias;
                    if ( !*Alias )
                        break;
                    if ( *Alias == ',' )
                        goto LABEL_20;
                }
            }
        }
        cdbcpystr(TTptr->TableAlias, Alias, 0);
        cdbcpystr(TTptr->TableName, TableName, 0);
        TTptr->DBnumber = DBno;
        TTptr->TTrtd = -1;
    }
    return rtdget(TTptr);
}

int rdbget(int DBno)
{
     DBase *DTptr; // edi@1
     //char *v2; // eax@2
     char *v3; // esi@2
     //bool v4; // eax@4
     //int ErrorCode; // edx@4
     unsigned int v6; // ST14_4@5
     unsigned int v7; // ecx@5
     int DBnoa; // [sp+18h] [bp-10h]@2

     DTptr = &dtab[DBno];
     if ( DTptr->DBno >= 0 )	// This DBases already opened?
          return DTptr->DBno;
     
	 v3 = mstrcpy(chkpath(DTptr->FullDBname, 0, "CLDPATH", 0, 384), 0);
     DBnoa = cldbopen(v3, 0);
     if ( DBnoa < 0 )
     {
          eprint("can't open database - %s\n", DTptr->FullDBname);
          return DBnoa;
     }
     //v4 = checkForDemo(DBnoa, DTptr->FullDBname);
     //v4 = 1;
	 //ErrorCode = -1;
     //if ( v4 )
     //{
          DTptr->FullDBname = v3;
          DTptr->DBno = DBnoa;
          v6 = 100 * dbspace(DBnoa);
          v7 = v6 / dbsize(DBnoa);
          if ( (signed int)v7 <= 9 )	// Less than 9% free space left!!
          {
               /*if ( isCGI )
               {
                    eprint("%s is %d%% full\n", DTptr->FullDBname, 100 - v7);
               }
               else
               {*/
                    eprint("\a%s is %d%% full\n", DTptr->FullDBname, 100 - v7);
                    sleep(5u);
               //}
          }
          return DBnoa;
     //}
     //return ErrorCode;
}
#endif
