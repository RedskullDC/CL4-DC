#ifndef CMPKEY_C
#define CMPKEY_C

#include "DBdefs.h"
#include "cl4.h"

int _cmpkey(char *a1, char *a2, TDef *a3)
{
	TDef *TDefP; // esi@1
	int v4; // edi@1
	short v5; // dx@2
	short v6; // ax@3
	int v7; // edx@3
	short v8; // ax@5

	printf("_cmpkey(a1 = %08X, a2 = %08X, TDef = %08X)\n" ,a1, a2,a3);

	TDefP = a3;
	v4 = 0;
	v7 = 0;
	while ( TDefP->TDFentry && (v5 = TDefP->TDFtype, v5 & 1) )// &1 = Keyfield
	{
		v6 = _cmpattrib(&a1[v4], TDefP->TDFsize, &a2[v4], TDefP->TDFsize, v5);
		v7 = v6;
		if ( v6 )
			break;
		if ( TDefP->TDFtype & 2 )
			v8 = _fwidth(&a1[v4], TDefP->TDFsize, TDefP->TDFtype);
		else
			v8 = TDefP->TDFsize;
		v4 += v8;
		TDefP++;	// v7 == 0 if we fall out here anyway. Set if v6 != 0 above
	}
	return v7;
}

#endif
