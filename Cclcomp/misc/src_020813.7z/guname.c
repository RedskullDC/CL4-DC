#ifndef GUNAME_C
#define GUNAME_C

#include <sys/types.h>	// for user calls
#include <pwd.h>
#include "DBdefs.h"
#include "cl4.h"

char* gelogin()
{
	__uid_t v0;
	struct passwd *v1;	// not typedef'ed in pwd.h
	char *UserName = "";
	char *v3;

	v0 = geteuid();
	v1 = getpwuid(v0);
	//UserName = "";
	if ( v1 )
		UserName = v1->pw_name;
	v3 = (char*)mstrcpy(UserName, 0);	// Copy to Global mem.
	//printf("gelogin: %s\n",UserName);
	return ftrim(v3);
}

#endif
