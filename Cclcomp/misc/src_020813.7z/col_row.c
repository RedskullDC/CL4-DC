#ifndef COL_ROW_C
#define COL_ROW_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

void fixstr(char *a1)	// called by getprmt. removes any unprintable chars
{
     char *i; // edx@1

     for ( i = a1; *i; ++i )
     {
          if ( (unsigned char)(*i - 94) <= 1u )
               *i = ' ';
     }
}

XTAB *getprmpt(XTAB *xtab)
{
     short FieldNo; // ax@3
     FLDdesc *fld; // eax@6
     short v3; // di@8
     short v4; // ax@8
     XTAB *v5; // edx@12
     short v6; // di@15
     ENTAB *v8; // [sp+14h] [bp-44h]@8
     int TDno; // [sp+18h] [bp-40h]@3
     char nptr[45]; // [sp+1Fh] [bp-39h]@3

     if ( symbol == 930 )
     {
          if ( !xtab->VarExpNo )
          {
               loaderr(7, sym);
               return 0;
          }
          FieldNo = gettf(xtab->VarExpNo, &TDno, nptr);
          if ( FieldNo < 0 )
               __assert_fail("fno >= 0", "getprmpt.c", 0x2Bu, "getprmpt");
          if ( TDno )
               fld = &ttab[TDno].TTfields[FieldNo];
          else
               fld = getvars(FieldNo);
          cdbcpystr(&nptr[1], fld->FLDname, 0);
          fixstr(&nptr[1]);
          v3 = getenmem();
          allenpt(v3, &v8);
          v4 = putconst(&nptr[1], 'C');
          if ( v4 < 0 )
          {
               dallenpt(&v8);
               return 0;
          }
          v8->RecNo = v4;
          v8->TTno = 0;
          v8->entype = 1;
          dallenpt(&v8);
          xtab->Prompt_exp = v3;
          return xtab;
     }
     if ( symbol == 2220 )
          fixstr(sym);
     v6 = loadexp(0, 1);
     v5 = 0;
     if ( v6 )
     {
          xtab->Prompt_exp = v6;
          return xtab;
     }
     return v5;
}

XTAB *getrow(XTAB *xtab, int a2)
{
     short v2; // di@1
     char v3; // zf@5
     short v4; // cx@14
     XTAB *v5; // edx@14
     short v6; // ax@18
     short v7; // cx@20
     short v8; // cx@32
     signed short v9; // dx@35
     short v10; // ax@43
     signed short v11; // ax@51
     signed short v12; // ax@61

     v2 = 0;
     if ( symbol == 1800 )
          goto LABEL_18;
     if ( symbol <= 1800 )
     {
          if ( symbol != 930 )
          {
               if ( symbol > 930 )
                    v3 = symbol == 1580;
               else
                    v3 = symbol == 50;
LABEL_10:
               if ( !v3 )
                    goto LABEL_68;
LABEL_30:
               if ( symbol != 2200 )
               {
                    v2 = symbol;
                    symbol = getsym();
                    if ( symbol != 2200 )
                         goto LABEL_68;
               }
               v8 = __strtol_internal(sym, 0, 10, 0);
               if ( v8 < 0 )
                    v2 = 1580;
               if ( (unsigned int)(a2 - 1) > 1 )
               {
                    if ( v2 == 50 || v2 == 1580 )
                         v8 += prow_0;
                    if ( v8 <= 0 || _li < v8 )
                         v12 = 1;
                    else
                         v12 = v8;
                    v8 = v12;
                    goto LABEL_64;
               }
               v9 = 0;
               if ( v2 == 1840 )
               {
                    v9 = 1024;
               }
               else
               {
                    if ( v2 != 1820 )
                    {
                         if ( v2 != 50 && v2 != 1580 )
                              goto LABEL_48;
                         v10 = prow_0 + v8;
LABEL_47:
                         v8 = v10;
LABEL_48:
                         if ( !v9 )
                         {
                              if ( v8 <= 0 || _li < v8 )
                                   v11 = 1;
                              else
                                   v11 = v8;
                              v8 = v11;
                         }
                         if ( a2 == 2 )
                              prow_0 = v8;
LABEL_64:
                         if ( a2 == 1 )
                              xtab->ALine = v8;
                         else
                              xtab->PLine = v8;
                         symbol = getsym();
                         goto LABEL_69;
                    }
                    v9 = 512;
               }
               if ( v8 < 0 )
               {
                    v3 = v9 == 1024;
                    v9 = 512;
                    if ( !v3 )
                         v9 = 1024;
                    v8 = -v8;
               }
               v10 = v9 | v8;
               goto LABEL_47;
          }
LABEL_18:
          v6 = prow_0 + 1;
          if ( a2 == 1 )
               v6 = prow_0;
          v7 = v6;
          if ( v6 <= 0 || _li < v6 )
               v7 = 1;
          if ( a2 != 4 )
               prow_0 = v7;
          if ( a2 == 1 )
               xtab->ALine = v7;
          else
               xtab->PLine = v7;
          if ( symbol != 930 )
               symbol = getsym();
          goto LABEL_69;
     }
     if ( symbol == 1840 )
          goto LABEL_30;
     if ( symbol <= 1840 )
     {
          v3 = symbol == 1820;
          goto LABEL_10;
     }
     if ( symbol == 2200 )
          goto LABEL_30;
     if ( symbol != 2230 )
     {
LABEL_68:
          loaderr(35, sym);
          return 0;
     }
     v4 = loadexp(0, 1);
     v5 = 0;
     if ( v4 )
     {
          if ( a2 == 1 )
               xtab->ALine_exp = v4;
          else
               xtab->PLine_exp = v4;
LABEL_69:
          v5 = xtab;
     }
     return v5;
}

XTAB *getadwid(XTAB *xtab)
{
     short FieldNo; // eax@9
     FLDdesc *fld; // eax@12
     short v3; // cx@20
     XTAB *v4; // edx@20
     int TDno; // [sp+14h] [bp-14h]@9
     char v7[32]; // [sp+1Bh] [bp-Dh]@9

     if ( symbol == 930 )
     {
LABEL_8:
          if ( !xtab->VarExpNo )
          {
LABEL_22:
               loaderr(37, sym);
               return 0;
          }
          FieldNo = gettf(xtab->VarExpNo, &TDno, v7);
          if ( FieldNo < 0 )
               __assert_fail("fno >= 0", "getadwid.c", 0x28u, "getadwid");
          if ( TDno )
               fld = &ttab[TDno].TTfields[FieldNo];
          else
               fld = getvars(FieldNo);
          if ( fld->FLDtype == 'D' )
               xtab->width = 0x400u;            // bit mask to signify special behaviour
          else
               xtab->width = getdwid(fld);
          if ( symbol != 930 )
               symbol = getsym();
          return xtab;
     }
     if ( symbol <= 930 )
     {
          if ( symbol != 50 )
               goto LABEL_22;
          goto LABEL_8;
     }
     if ( symbol == 2200 )
     {
          xtab->width = __strtol_internal(sym, 0, 10, 0);
          symbol = getsym();
          return xtab;
     }
     if ( symbol != 2230 )
          goto LABEL_22;
     v3 = loadexp(0, 1);
     v4 = 0;
     if ( v3 )
     {
          xtab->widthEXP = v3;
          return xtab;
     }
     return v4;
}
XTAB *getcol(XTAB *xt, int a2)
{
     short TestSym; // di@1
     char v3; // zf@9
     short v4; // cx@18
     XTAB *v5; // edx@18
     signed short v6; // ax@25
     signed short v7; // cx@27
     signed short v8; // ax@34
     short v9; // ax@44
     short v10; // cx@44
     unsigned short v11; // dx@47
     short v12; // ax@55
     short v13; // ax@63
     short v14; // ax@75
     char v15; // zf@81
     signed int v16; // edi@92
     signed int v17; // eax@105
     int v19; // [sp+0h] [bp-28h]@90
     char *v20; // [sp+4h] [bp-24h]@90
     signed int v21; // [sp+14h] [bp-14h]@1
     short v22; // [sp+18h] [bp-10h]@1

     v22 = 0;
     v21 = 0;
     TestSym = 0;
     if ( syml == 1 && symbol == 2230 && sym[0] == 99 )
          symbol = 170;
     if ( symbol == 1800 )
          goto LABEL_22;
     if ( symbol <= 1800 )
     {
          if ( symbol != 930 )
          {
               if ( symbol > 930 )
                    v3 = symbol == 1580;        // "-"
               else
                    v3 = symbol == 50;          // "+"
LABEL_14:
               if ( !v3 )
               {
LABEL_78:
                    if ( syml == 1 )
                    {
                         v10 = 1;
                         if ( sym[0] != '^' )
                         {
                              if ( sym[0] > '^' )
                              {
                                   v10 = 0x1000u;
                                   v15 = sym[0] == 'c';
                              }
                              else
                              {
                                   v10 = 0x2000u;
                                   v15 = sym[0] == '$';
                              }
                              if ( !v15 )
                                   v10 = 0;
                         }
                         if ( !v10 )
                              goto LABEL_91;
                         goto LABEL_86;
                    }
LABEL_90:
                    v20 = sym;
                    v19 = 34;
LABEL_110:
                    loaderr(v19, v20);
                    return 0;
               }
LABEL_42:
               if ( symbol != 2200 )
               {
                    TestSym = symbol;
                    symbol = getsym();
                    if ( symbol != 2200 )
                         goto LABEL_90;
               }
               v9 = __strtol_internal(sym, 0, 10, 0);
               v10 = v9;
               if ( v9 < 0 )
                    TestSym = 1580;             // "-"
               if ( a2 != 1 )
               {
                    if ( TestSym == 50 || TestSym == 1580 )
                         v10 = ppcol_1 + v9;
                    if ( a2 == 4 )
                    {
                         if ( v10 <= 0 || _co < v10 )
                              v10 = 1;
                    }
                    else
                    {
                         if ( v10 <= 0 || _co < v10 )
                              v14 = 1;
                         else
                              v14 = v10;
                         v10 = v14;
                         ppcol_1 = v14;
                    }
                    goto LABEL_86;
               }
               v11 = 0;
               if ( TestSym == 1840 )           // "<"
               {
                    v11 = 0x2000u;
               }
               else
               {
                    if ( TestSym != 1820 )
                    {
                         if ( TestSym != 50 && TestSym != 1580 )
                         {
LABEL_60:
                              if ( !v11 )
                              {
                                   if ( v10 <= 0 || _co < v10 )
                                        v13 = 1;
                                   else
                                        v13 = v10;
                                   picol_0 = v13;
                                   v10 = v13;
                              }
LABEL_86:
                              if ( a2 == 1 )
                                   xt->ACol = v10;
                              else
                                   xt->PCol = v10;
                              symbol = getsym();
                              goto LABEL_91;
                         }
                         v12 = picol_0 + v9;
LABEL_59:
                         v10 = v12;
                         goto LABEL_60;
                    }
                    v11 = 0x1000u;
               }
               if ( v9 < 0 )
               {
                    v3 = v11 == 0x2000;
                    v11 = 0x1000u;
                    if ( !v3 )
                         v11 = 0x2000u;
                    v10 = -v9;
               }
               v12 = v11 | v10;
               goto LABEL_59;
          }
LABEL_22:
          if ( a2 == 1 )
          {
               if ( picol_0 <= 0 || _co < picol_0 )
                    v6 = 1;
               else
                    v6 = picol_0;
               v7 = v6;
               picol_0 = v6;
          }
          else
          {
               v7 = ppcol_1;
               if ( a2 == 4 )
               {
                    if ( ppcol_1 <= 0 || _co < ppcol_1 )
                         v7 = 1;
               }
               else
               {
                    if ( ppcol_1 <= 0 || _co < ppcol_1 )
                         v8 = 1;
                    else
                         v8 = ppcol_1;
                    v7 = v8;
                    ppcol_1 = v8;
               }
          }
          if ( a2 == 1 )
               xt->ACol = v7;
          else
               xt->PCol = v7;
          if ( symbol != 930 )
               symbol = getsym();
          goto LABEL_91;
     }
     if ( symbol == 1840 )                      // "<"
          goto LABEL_42;
     if ( symbol <= 1840 )
     {
          v3 = symbol == 1820;                  // ">"
          goto LABEL_14;
     }
     if ( symbol == 2200 )
          goto LABEL_42;
     if ( symbol != 2230 )
          goto LABEL_78;
     v4 = loadexp(0, 1);
     v5 = 0;
     if ( !v4 )
          return v5;
     if ( a2 == 1 )
          xt->ACol_exp = v4;
     else
          xt->PCol_exp = v4;
LABEL_91:
     if ( symbol == 180 )
     {
          v16 = 1;
          symbol = getsym();
     }
     else
     {
          v16 = 0;
     }
     if ( v16 || syml == 1 )
     {
          switch ( sym[0] )
          {
               case 'f':
                    v22 = 1;
                    goto LABEL_104;
               case 's':
                    v22 = 2;
                    goto LABEL_104;
               case 'u':
                    v22 = 4;
                    goto LABEL_104;
               case 'r':
                    v22 = 32;
                    goto LABEL_104;
               case 'B':
                    v22 = 16;
                    goto LABEL_104;
               case 'b':
                    v22 = 8;
                    goto LABEL_104;
               case 'n':
               case 'x':
                    v22 = 63;
LABEL_104:
                    symbol = getsym();
                    break;
               default:
                    v17 = 1;
                    if ( !v16 )
                         v17 = 0;
                    v21 = v17;
                    break;
          }
          if ( v21 )
          {
               v20 = sym;
               v19 = 36;
               goto LABEL_110;
          }
     }
     if ( a2 == 1 )
          xt->Attr = v22;
     else
          xt->ScrAttrib = v22;
     return xt;
}

#endif
