#ifndef LEWHILE_C
#define LEWHILE_C

int lewhile(int *a1)
{
    short v1; // ax@4
    PTAB *v2; // edi@4
    short v3; // ax@11
    short *v7; // edx@20
    short v10; // ST00_2@28
    PTAB *v12; // edi@28
    PTAB *v13; // eax@29
    short v14; // ax@31
	short v17; // ax@35
    short v19; // edx@35
    PTAB *ptb2; // edi@36
    int v21; // eax@38

	if ( &itab[no_itabs] <= it ) // "it" is some nice global goodness
    {
		newitab();
        if ( it >= &itab[no_itabs] )
			__assert_fail("it < max_it", "lewhile.c", 36, "lewhile");
	}
    it->field_C = 2;
    v1 = getptabp(*(short *)a1);
	v2 = v1 ? (PTAB *)&ptarr.TableAddr[8 * (unsigned short)v1 - 8] : 0;
	v2->Operand = *(short *)a1;
    it->PTno = v1;
    
	++it;
    if ( &itab[no_itabs] <= it )
    {
		newitab();
        if ( it >= &itab[no_itabs] )
			__assert_fail("it < max_it", "lewhile.c", 48, "lewhile");
	}
    do							// find end of line
		symbol = getsym();
	while ( symbol == 930 );

	v2->OpCode = 310;                          // 310 = "while"
    v2->SrcLineNo = lla;
    v3 = loadexp(1, 1);
    v2->TABno = v3;
    if ( !v3 || symbol != 930 )
    {
		while ( symbol )
        {
			if ( v2->TABno )
				loaderr(33, sym);
			symbol = getsym();
            if ( comp_abort )
				break;
			if ( symbol == 930 )
				goto LABEL_18;
		}
        return 0;
	}

LABEL_18:
	while (symbol == 930)
		symbol = getsym();
    
	++*a1;
    if ( symbol != 1710 )                   // "wend"
    {
		while ( symbol )
        {
			loadstate(a1);					// many levels of recursion possible here
            if ( comp_abort )
				break;
			while (symbol == 930)
				symbol = getsym();

            if ( symbol == 1710 )           // wend
				goto LABEL_26;
		}
        return 0;
	}

LABEL_26:
    symbol = getsym();
    --it;
    if ( it->field_C != 2 )
    {
		loaderr(23, sym);                     // "wend without while"
        return 0;
	}
    v10 = (*a1)++;
    v12 = PTARR(getptabp(v10));
    v12->OpCode = 700;                         // 700 = "goto"  Branch always
    
	v13 = it->PTno ? (PTAB *)&ptarr.TableAddr[8 * (it->PTno - 1)] : 0;
	v14 = v13->Operand;
    v12->Operand = v14;

	v17 = *(short *)a1;
    v13->Operand = v17;
    
	v19 = v14 + 1;
	while ( v19 <= v17 )
	{
		ptb2 = v19 ? (PTAB *)&ptarr.TableAddr[8 * (v19 - 1)] : 0;

		v21 = ptb2->OpCode;
        if ( v21 == 320 )				// 320 = continue
        {
			if ( !ptb2->Operand )
				ptb2->Operand = v14;	// first instruction of the loop
		}
        else if ( v21 == 330 )			// 330 = end_loop
		{
			if ( !ptb2->Operand )
				ptb2->Operand = v17;	// instruction after the loop
		}
		v19++;
	}
    return 1;	// exit_success
}


#endif
