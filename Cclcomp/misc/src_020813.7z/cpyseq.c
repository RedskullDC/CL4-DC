#ifndef CPYSEQ_C
#define CPYSEQ_C

#include "DBdefs.h"
#include "cl4.h"
int cpyseq(char *DEST, char *SOURCE, int MaxLen)
{
	int v3; // ecx@1
	char *v4; // edx@1
	char *v6; // esi@2
	char v7; // al@4

	//printf("cpyseq( DEST: x%08X, SRC: x%08X, MaxLen : %d)\n", DEST, SOURCE, MaxLen);

	v3 = MaxLen;
	v4 = DEST;
	if ( MaxLen )
	{
		v6 = SOURCE;
		do
		{
			v7 = *v6++;
			*v4++ = v7;
			if ( !--v3 )
				break;
		}
		while ( v7 );
	}
	return v4 - DEST;

	/*
	v3 = MaxLen;
	v4 = DEST;
	if ( MaxLen )
	{
		v7 = *SOURCE;
		v6 = SOURCE + 1;
		*DEST = *SOURCE;
		v4 = DEST + 1;
		if ( v7 )
		{
			do
			{
				--v3;
				if ( !v3 )
					break;
				v7 = *v6++;
				*v4++ = v7;
			}
			while ( v7 );
		}
	}
	return v4 - DEST;
	*/
}

#endif
