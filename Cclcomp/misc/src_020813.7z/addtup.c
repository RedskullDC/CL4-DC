#ifndef ADDTUPLE_C
#define ADDTUPLE_C

#include "DBdefs.h"
#include "cl4.h"

// not public
void sum(char *a1, char *a2, short TDFsize)
{
	short Carry; // si@1
	int v4; // ecx@1
	short v5; // ax@2
	short v6; // ax@4

	Carry = 0;
	v4 = (TDFsize - 1);
	v6 = v4;
	while ( v6 >= 0 )
	{
		v5 = a2[v4] + a1[v4] + 1;
		if ( !(Carry & 0x100) )
			v5 = a2[v4] + a1[v4];
		Carry = v5;
		a1[v4] = v5;
		v6 = --v4;
	}
}

void _addtuple(char *Buffer1, char *Buffer2,TDef *TDefPtr)
{
	char *v3; // edi@1
	TDef *TDefP; // esi@1
	short v5; // eax@6
	short v6; // eax@9

	//printf("_addtuple(Buffer1: %S,Buffer2 = %Sd, TDef = x%08X)\n" ,Buffer1,Buffer2,TDefPtr);

	v3 = Buffer2;
	for ( TDefP = TDefPtr; TDefP->TDFentry; TDefP++ )
	{
		if ( !(TDefP->TDFtype & 1) && TDefP->TDFtype & 0x0FC0 )
			sum(Buffer1, v3, TDefP->TDFsize);
		
		if ( TDefP->TDFtype & 2 )
			v5 = _fwidth(Buffer1, TDefP->TDFsize, TDefP->TDFtype);
		else
			v5 = TDefP->TDFsize;
		
		Buffer1 += v5;
		
		if ( TDefP->TDFtype & 2 )
			v6 = _fwidth(v3, TDefP->TDFsize, TDefP->TDFtype);
		else
			v6 = TDefP->TDFsize;
		
		v3 += v6;
  }
}

#endif
