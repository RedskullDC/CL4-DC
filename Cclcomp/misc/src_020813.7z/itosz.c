#ifndef ITOSIZE_C
#define ITOSIZE_C

short _itosz(PAGE *PageBuffer, short N1_2idx)
{
	char *v2;
	short v3;

	//printf("_itosz(PAGE: x%08X, Index: x%02X (%4d), Pagetype = x%02X\n" ,PageBuffer,N1_2idx,N1_2idx,(PageBuffer->PageType & 0x40));
	if ( PageBuffer->PageType & 0x40 )	// variable record size
	{
		v2 = (char *)PageBuffer->TabStart_or_RecSize;
		v3 = SWAP_SHORT(&v2[2 * N1_2idx]);
		if ( N1_2idx )
			v3 = v3 - SWAP_SHORT(&v2[2 * (N1_2idx-1)]);
	}
	else
		v3 = (short)(int)PageBuffer->TabStart_or_RecSize;	// Fixed record size

	//printf("_itosz: returned x%02X (%4d)\n", v3,v3);
	return v3;
}

#endif
