#ifndef MSTOL_C
#define MSTOL_C

#include "DBdefs.h"
#include "cl4.h"

int mstol(int *a1)
{
	unsigned char *LUC = (unsigned char *)a1;
	//printf("mstol( *a1 = x%08X)\n" ,*a1);
	
	return (unsigned int)(*(LUC + 3) | (*(LUC + 2) << 8)) + ((unsigned int)(*(LUC + 1) | (*LUC << 8)) << 16);
}


#endif



