#ifndef GETPG_C
#define GETPG_C

#include "DBdefs.h"

void cdbfreepg(void)
{
	//printf("cdbfreepg()\n");
	if ( pbuf )
	{
		//printf("cdbfreepg: Freeing pbuf = x%08X, psize = %d\n", pbuf, psize);
		nfree(pbuf, 0);
		pbuf = 0;
		psize = 0;
	}
}

char* _getpg(DBinfo *DBptr)
{
	int RequiredPageSize; // esi@1

	RequiredPageSize = DBptr->DBpgsize + 16;	// Database pagesize in bytes
	//printf("RequiredPageSize = %d\n",RequiredPageSize);
	if ( psize < RequiredPageSize )
	{
		if ( pbuf )
			nfree(pbuf, 0);
		pbuf = ealloc(RequiredPageSize, 0);
		//printf("PageSize was %d\n", psize);
		psize = RequiredPageSize; 
	}
	//printf("CurrentPageBufSize now %d\n",RequiredPageSize);
	return pbuf;
}


#endif

