#ifndef CMPSTR_C
#define CMPSTR_C

#include "DBdefs.h"
#include "cl4.h"

bool cmpstr(char *a1, char *a2)
{
	char *v2;
	char *v3;
	bool Result;

	//printf("cmpstr(a1 = %s, a2 = %s)\n" ,a1, a2);

	v2 = a1;
	v3 = a2;

	Result = *v2 == 0;	// default response if !*v3.
	
	while ( *v3 )
	{
		if ( *v2++ != *v3++ )
			return false;
		Result = *v2 == 0;
	}
	return Result;
}

#endif
