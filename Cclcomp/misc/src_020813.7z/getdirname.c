#ifndef GETDIRNAME_C
#define GETDIRNAME_C

#include <sys/types.h>
#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include <pwd.h>
#include "DBdefs.h"
#include "cl4.h"

char	*myuser_0;		// not public in libcl4

char	*getdirname(char *a1)
{
	char *v1; // edi@2
	char *v2; // eax@2
	struct passwd *v3; // eax@10
	char *result; // eax@11
	char *i; // esi@15
	char v6; // ST1B_1@19
	char *v7; // edx@19
	char *v8; // esi@20
	char *ptr; // [sp+14h] [bp-14h]@14
	char v10; // [sp+1Bh] [bp-Dh]@6

	if ( *a1 == '~' )
	{
		v1 = a1 + 1;
		v2 = a1 + 1;
		if ( a1[1] && *v1 != '/' )
		{
			do
				++v1;
			while ( *v1 && *v1 != '/' );
		}
		v10 = *v1;
		*v1 = 0;
		if ( !*v2 )
		{
			if ( !myuser_0 )
				myuser_0 = gelogin();
			v2 = myuser_0;
		}
		v3 = getpwnam(v2);
		if ( v3 )
		{
			*v1 = v10;
			result = mstrcpy(v3->pw_dir, v1,0);
		}
		else
		{
			result = mstrcpy("", 0);
		}
	}
	else
	{
		if ( *a1 == '$' )
		{
			ptr = mstrcpy(a1, 0);
			if ( *ptr == '$' )
			{
				while ( 1 )
				{
					for ( i = ptr + 1; *i && *i != '/'; ++i )
						;
					v6 = *i;
					*i = 0;
					v7 = getevar(ptr + 1);
					*i = v6;
					result = a1;
					if ( !v7 )
						break;
					v8 = mstrcpy(v7, i,0);
					mfree_0(ptr);
					ptr = v8;
					if ( *v8 != '$' )
						goto LABEL_21;
				}
			}
			else
			{
LABEL_21:
				result = ptr;
			}
		}
		else
		{
			result = a1;
		}
	}
	return result;
}


#endif
