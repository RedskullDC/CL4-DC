#ifndef XTODOM_C
#define XTODOM_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

int xtodom(char *Dest, short FLDlen, unsigned short FLDtype, char *Src)
{
	int v4;
	double v5;
	unsigned short v6;
	short v7;
	int v8;
	double v10;
	int v12;
	short v13;
	unsigned int Negative;

//printf("xtodom() - FLDlen = %d, FLDtype = x%04X \n", FLDlen, FLDtype);
	v4 = FLDlen;
	v13 = 0;
	v5 = 0.0;
	v12 = 0;
	if ( FLDtype & 0x1C0 )
	{	
		v6 = (FLDtype & 0x1C0u) >> 6;
	}
	else
	{
		v6 = FLDtype & 0xE00;
		if ( FLDtype & 0xE00 )
			v6 = (FLDtype & 0xE00u) >> 9;
	}

//-----------------------

	v7 = v6 - 1;
	v8 = (v6 - 1);
	if ( v7 >= 0 )
	{
		Negative = (FLDtype >> 2) & 1;	// default assume that we are dealing with a negative value
		if ( v8 <= 0 && FLDlen <= 4 )
		{
			if ( FLDlen <= 2 )	// FLDlen = 1 or 2
			{
				v13 = *(short*)Src;
				if ( v13 >= 0 )	// Positive value?
					Negative = 0;	// was +ve
				if ( Negative )
					v13 = -v13;	 // abs value. for rounding purposes. reverse later if necessary
			}
			else				// FLDlen = 3 or 4
			{
				v12 = *(int*)Src;
				if ( v12 >= 0 )
					Negative = 0;
				if ( Negative )
					v12 = -v12;
			}
		}
		else
		{
			v5 = *(double*)Src;
			if ( v5 >= 0.0 )
				Negative = 0;
			else
				v5 = -v5;
		}

		if ( v8 > 0 )
		{
			if ( FLDtype & 0x1C0 )
				v10 = v5 * _dbias[v8];
			else
				v10 = _addexp(v5, 8 * v8);
			v5 = v10 + 0.5;
			if ( FLDlen > 2 )
			{
				if ( FLDlen <= 4 )
					v12 = (int)v5;
			}
			else
			{
				v13 = (short)v5;
			}
		}
    
		switch ( FLDlen )
		{
			case 1:
				*Dest = (char)v13;
				break;
			case 2:
				itoms((short*)Dest, v13);
				break;
			case 3:
				xitoms((int*)Dest, v12);
				break;
			case 4:
				ltoms((int*)Dest, v12);
				break;
			case 6:
				xltoms((long long*)Dest, v5);
				break;
			default:
				if ( FLDlen > 7 )
					dtoms((double*)Dest, v5);
				break;
		}
		if ( Negative )
			negate(Dest, FLDlen);
	}
	else
	{
		if ( FLDtype & 2 )
			v4 = cpyseq(Dest, Src, FLDlen);
		else
			cpybuf(Dest, Src, FLDlen);
	}
	return v4;
}

#endif
