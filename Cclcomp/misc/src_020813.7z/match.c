#ifndef MATCH_C
#define MATCH_C

#include "DBdefs.h"
#include "cl4.h"

// not public in libcl4 
bool Star(char *a1, char *a2)
{
	char *v2; // esi@1

	v2 = a1;
	while ( !wildmat(v2, a2) )
	{
		if ( *v2 )
		{
			++v2;
			if ( *v2 )
				continue;
		}
		return 0;
	}	
	return 1;
}

// not public in libcl4 
bool isregexp(char *a1)
{
	char *v1;
	int v2;
	char v3;

	v1 = a1;
	if ( !*a1 )
		return false;
	while ( *v1 >= 0 )
	{
		++v1;
		if ( !*v1 )
		return false;
	}
	v2 = *v1 & 0x7F;
	if ( v2 == 63 || (v2 > 63 ? (v3 = v2 == 91) : (v3 = v2 == 42), v3) )
		return true;
	else
		return false;
}

// not public in libcl4 
int wildmat(char *a1, char *a2)
{
	char *v2; // edi@1
	char *v3; // esi@1
	signed int v4; // edx@2
	int v5; // ecx@9
	int v6; // eax@12
	int result; // eax@17
	char *v8; // esi@18
	int v9; // ecx@26
	int v10; // eax@29
	signed int v11; // eax@33
	int v12; // ecx@37
	int v13; // eax@40
	signed int v14; // eax@45
	short v15; // [sp+14h] [bp-14h]@21
	signed short v16; // [sp+18h] [bp-10h]@23
	signed int v17;

	printf("wildmat(%s,%s)",a1,a2);
	v2 = a1;
	v3 = a2;
	if ( !*a2 )
		return *v2 == 0;
	while ( 1 )
	{
		v4 = *v3;
		if ( v4 == -65 )
		{
			if ( !*v2 )
				return 0;
			goto LABEL_50;
		}
		if ( v4 > -65 )
		{
			if ( v4 == -37 )
			{
				v15 = v3[1] == 94;
				if ( v3[1] == 94 )
					++v3;
				v17 = 256;
				v16 = 0;
				++v3;
				if ( !*v3 || *v3 == 93 )
				{
					result = 0;
					if ( v16 == v15 )
						return result;
					goto LABEL_50;
				}
				while ( 2 )
				{
					if ( *v3 == 45 )
					{
						++v3;
						v9 = *v2;
						if ( (*v2 - 65) <= 0x19u )
							v9 += 32;
						if ( (*v3 - 65) > 0x19u )
							v10 = *v3;
						else
							v10 = *v3 + 32;
						if ( v9 <= v10 )
						{
							v11 = (*v2 - 65) > 0x19u ? *v2 : *v2 + 32;
							if ( v11 >= v17 )
								goto LABEL_43;
						}
					}
					else
					{
						v12 = *v2;
						if ( (*v2 - 65) <= 0x19u )
							v12 += 32;
						if ( (*v3 - 65) > 0x19u )
							v13 = *v3;
						else
							v13 = *v3 + 32;
						if ( v12 == v13 )
LABEL_43:
							v16 = 1;
					}
					if ( (*v3 - 65) > 0x19u )
						v14 = *v3;
					else
						v14 = (*v3 + 32);
					v17 = v14;
					++v3;
					if ( !*v3 || *v3 == 93 )
					{
						result = 0;
						if ( v16 == v15 )
							return result;
						goto LABEL_50;
					}
					continue;
				}
			}
			if ( v4 == 92 )
				++v3;
			goto LABEL_9;
		}
		if ( v4 == -86 )
			break;
LABEL_9:
		v5 = *v2;
		if ( (*v2 - 65) <= 0x19u )
			v5 += 32;
		if ( (*v3 - 65) > 0x19u )
			v6 = *v3;
		else
			v6 = *v3 + 32;
		if ( v5 != v6 )
			return 0;
LABEL_50:
		++v2;
		++v3;
		if ( !*v3 )
			return *v2 == 0;
	}
	v8 = (v3 + 1);
	if ( *v8 )
		result = Star(v2, v8);
	else
		result = 1;
	return result;
}

int _match(char *src, EXPR *Expr, TDef *TDefPtr)
{
	TDef *tdef; // esi@1
	int v5; // edx@3
	size_t v7; // edi@11
	int v8; // eax@19
	short v9; // ax@25
	char *v11; // [sp+0h] [bp-448h]@17
	char *v12; // [sp+4h] [bp-444h]@17
	bool IsReg; // [sp+2Ch] [bp-41Ch]@9
	char dest[1036];

	//printf("_match(src = x%08X, EXPR = x%08X, tdef = x%08X, Operator = x%02X, ExprType = x%04X)\n", src, Expr, TDefPtr,Expr->Operator, Expr->Type);

	tdef = TDefPtr;
	if ( !Expr )
		return 1;
	
	if ( Expr->Operator == 1 )      //  Expr was an "OR" type join
	{
		//printf("_match : Op == 1\n");
		return ( _match(src, Expr->NextEXPR, TDefPtr) | _match(src, Expr->PrevEXPR, TDefPtr));
	}

	if ( Expr->Operator == 2 )		// Expr is actually a "join". Operator == 2 means an "AND" join.
	{
		//printf("_match : Op == 2\n");
		return ( _match(src, Expr->NextEXPR, TDefPtr) & _match(src, Expr->PrevEXPR, TDefPtr));
	}

	// 3 Operators bits: 
	// 0x08 == less than				'<'
	// 0x10 == equal to					'='
	// 0x20 == greater than				'>'

	// Mixed bit tests:
	// 0x18 == less than or equal		'<='
	// 0x30 == greater than or equal	'>='
	// 0x28 == not equal to				'<>'
	
	//                   GE L  
	//                   TQ T
	// operator bits : 0011 1000

	if ( Expr->Operator & 0x38 )                // Leave operator bits remaining: 0011 1000
	{											// This is a single expression.
		IsReg = isregexp(&Expr->ExprData);
		while ( TDefPtr->TDFentry )
		{
			v7 = tdef->TDFtype & 2 ? _fwidth(src, tdef->TDFsize, tdef->TDFtype) : tdef->TDFsize;
			//printf("_match - tdef->TDFentry = x%04X, Expr->Type x%04X, Operator = x%02X\n",tdef->TDFentry,Expr->Type,(Expr->Operator &0x38));
			if ( tdef->TDFentry == Expr->Type )
			{
				// we found a match on TDFentry and Expr-Type if we got here.
				if ( tdef->TDFtype & 2 && IsReg )
				{
					if ( tdef->TDFsize == v7 )
					{
						strncpy(dest, src, v7);
						dest[v7] = 0;
						v8 = wildmat(dest, &Expr->ExprData);
					}
					else
						v8 = wildmat(src, &Expr->ExprData);

					if ( v8 || Expr->Operator & 0x10 )	// wildmatch or equal to
					{
						v5 = 0;
						if ( v8 && Expr->Operator & 0x10 )
							v5 = 1;
						return v5;
					}
				}
				else
				{
					v9 = _cmpattrib(src, v7, &Expr->ExprData, Expr->ExprSize, tdef->TDFtype);
					//printf("_match - cmpattrib returned %d\n",v9); 
					v5 = 0;
					if ( (v9 || !(Expr->Operator & 0x10)) && (v9 >= 0 || !(Expr->Operator & 0x08)) && (v9 <= 0 || !(Expr->Operator & 0x20)) )
						return v5;
				}
				return 1;
			}
			src += v7;	// Keep moving through the buffer
			tdef++;
		}
	}
	return 1;	// no match exit
}

#endif



