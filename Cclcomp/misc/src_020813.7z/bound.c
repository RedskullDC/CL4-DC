#ifndef BOUND_C
#define BOUND_C

#include "DBdefs.h"
#include "cl4.h"
EXPR* _bound(EXPR *Expr, short Operator, TDef *Tdefp);

EXPR* _bound(EXPR *Expr, short Operator, TDef *Tdefp)
{
	EXPR *v3;
	EXPR *v4;
	short v5;
	EXPR *result;
	EXPR *v7;
	EXPR *v8;

	//printf("_bound( EXPR: x%08X,Operator: x%04X, TDef: x%08X)\n", Expr,Operator,Tdefp);
	v3 = Expr;                                    // possible for many levels of recursion to happen inside _bound() !!
	if ( !Expr )
		return 0;
  //-----------

	if ( Expr->Operator == 1 )
	{
		v7 = _bound(Expr->NextEXPR, Operator, Tdefp);  // Expr-Operator == 1: was an "OR" type join
		if ( !v7 || (v4 = _bound(Expr->PrevEXPR, Operator, Tdefp), (v3 = v4) == 0) )
			return 0;

		v5 = _cmpattrib(&v7->ExprData, v7->ExprSize, &v4->ExprData, v4->ExprSize, Tdefp->TDFtype);
		if ( v5 < 0 )
		{
			result = v7;
			if ( !(Operator & 0x20) )	// not greater than flag
				result = v3;
			return result;
		}
		if ( v5 <= 0 )
		{
			if ( v7->ExprSize < v3->ExprSize )
				return v7;
			return v3;
		}
		result = v7;
		if ( Operator & 0x20 )	// greater than
			result = v3;
		return result;
	}
	else if ( Expr->Operator == 2 )  // Expr is actually a "join". Operator == 2 means an "AND" join.
	{
		v8 = _bound(Expr->NextEXPR, Operator, Tdefp);
		if ( v8 || (v8 = _bound(Expr->PrevEXPR, Operator, Tdefp)) != 0 )
			return v8;
	}
	else             // Normal single Expr type record
	{
		if ( ((unsigned short)Operator | Expr->Operator) == Operator && Expr->Type == Tdefp->TDFentry )
			return v3;
	}
	return 0;
}

	// 3 Operators bits: 
	// 0x08 == less than				'<'
	// 0x10 == equal to					'='
	// 0x20 == greater than				'>'

	// Mixed bit tests:
	// 0x18 == less than or equal		'<='
	// 0x30 == greater than or equal	'>='
	// 0x28 == not equal to				'<>'
	
#endif
