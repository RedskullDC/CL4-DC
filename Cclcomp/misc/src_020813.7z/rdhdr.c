#ifndef RDHDR_C
#define RDHDR_C

#include "DBdefs.h"
#include "cl4.h"

short _rdhdr(short fd, DBinfo *DBptr)
{
  int v2; // edx@1
  short Version; // ax@3
  unsigned char buf[32]; // [sp+10h] [bp-38h]@2

	//printf("_rdhdr( fd = x%04X, DBptr = x%08X\n", fd,DBptr);

	v2 = lseek64(fd, 0LL, 0);
	if ( v2 >= 0 && readfull(fd, buf, 32) == 32 )
	{
		DBptr->DBnumtables = buf[13] | (buf[12] << 8);
		DBptr->DBpgsize = buf[3] | (buf[2] << 8);
		DBptr->DBtableaddress = mstol((int*)&buf[14]);
		DBptr->DBmaxtables = buf[21] | (buf[20] << 8);
		DBptr->DBvflag = buf[19] | (buf[18] << 8);
		DBptr->DBmaxpages = mstol((int*)&buf[4]);
		DBptr->DBfreeaddress = mstol((int*)&buf[8]);
		DBptr->DBversion = buf[1] | (buf[0] << 8);
		DBptr->DBSemaphore = 0;
		Version = DBptr->DBversion;
	}
	else
	{
		Version = -1;
	}
	return Version;
}

#endif

