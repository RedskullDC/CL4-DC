#ifndef CDBRINDEX_C
#define CDBRINDEX_C

#include "DBdefs.h"
#include "cl4.h"
void DumpPOS(POS* Pos);

short cdbrindex(POS *a1, short TDFentry)
{
	POS *pos; // eax@1
	short result; // ax@4

  	//printf("\ncdbrindex(x%08X,%d) Called. - " ,a1,TDFentry);
	pos = a1;
	if ( a1 && a1->ElementID )
	{
		while ( pos->ElementID != TDFentry )
		{
			++pos;
			if ( !pos->ElementID )
			{
				//printf("Returned %04X (%4d)\n",-1,-1);
				return -1;
			}
		}
		result = pos->BuffOffset; // found a match. return offset to caller
	}
	else
	{
		result = -1;
	}
	//printf("Returned %04X (%4d)\n",result,result);
	//DumpPOS(a1);

	return result;
}

#endif
