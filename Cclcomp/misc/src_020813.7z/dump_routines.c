#ifndef DUMP_ROUTINES_C
#define DUMP_ROUTINES_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

void putbuf(const void *ptr, size_t arg);
void putcount(short a1);
void putucount(unsigned short a1);
void puttext(char *ptr, size_t arg);
void dumpoe(ONESC *ptr);
void putftabs(FLDdesc *ptr, int Count);
void putdouble(double a1, short a2);
void putbits(short a1);
void putptabs(CLArrayPtr *a1);
void putenodes(CLArrayPtr *a1);
void putfloat(double a1, short a2);
void putLong(int ptr);
void putrtabs(CLArrayPtr *a1);
void putxtabs(CLArrayPtr *a1);
void putratabs(CLArrayPtr *a1);
void putxftabs(CLArrayPtr *a1);
void puttable(int ptr);
void putsftabs(CLArrayPtr *a1);
void putprtabs(CLArrayPtr *a1);
void putrdtabs(CLArrayPtr *a1);
void putkxtabs(CLArrayPtr *a1);
void putarrcount(short *ptr, short a2);
void putarrtds(int *ptr, int a2);
void putbtabs(short NumBTABs);
void dumpscr(TYPE24 *ptr);
void putbool(bool ptr);



void putbuf(const void *ptr, size_t arg)
{
     size_t v2; // eax@1

     *__errno_location() = 0;
     v2 = fwrite(ptr, 1u, arg, dp);
printf("putbuf arg = %d, v2 = %d [x%04X]\n",arg,v2,v2);
     if ( v2 != arg )
     {
          syserror("dumpenc: fwrite tried %u, did %u", arg, v2);
          mexit(1);
     }
}
void dumpscr(TYPE24 *ptr)
{
     TYPE24 *t24; // esi@1

     for ( t24 = ptr; t24; t24 = t24->NextT24 )
     {
          if ( tpenc )
          {
               putcount(t24->PT_start);
               putcount(t24->PT_end);
               putcount(t24->NextT24 != 0);     // bool to indicate further T24's follow
          }
          else
          {
               putbuf(t24, 8u);
          }
     }
}

void putbool(bool ptr)
{
     short v1; // ax@3

     if ( tpenc )
     {
          if ( tpenc )
               v1 = 0x44u;
          else
               v1 = 0;
          xtodom((char *)&ptr, 4u, v1, (char *)&ptr);
     }
     putbuf(&ptr, 4u);
}

void putbtabs(short NumBTABs)
{
    BTAB *btb; // esi@2
    signed int i; // [sp+8h] [bp-10h]@2

    putcount(NumBTABs);
    if ( tpenc )
	{
        btb = btab;
        for ( i = 0; i < NumBTABs; ++btb )
		{
            putbool(btb->field_0);
            putcount(btb->EndLine);
            putcount(btb->fmts);
            putcount(btb->StartLine);
            putcount(btb->TTno);
            putcount(btb->Scrs);
            putcount(btb->field_10 != 0);
            putcount(btb->On_delete != 0);
            putcount(btb->On_exit != 0);
            putcount(btb->On_excep != 0);
            putcount(btb->On_entry != 0);
            putbuf(btb->Maintain, 7u);
            putbuf(btb->BlockName, 0x15u);
			++i;
		}
    }
    else
    {
        putbuf(btab, 72 * NumBTABs);
		#ifdef DEBUG_DUMP
		DumpBlock((char*)btab, 72 * NumBTABs);
		#endif
	}
}

void putarrtds(int *ptr, int a2)
{
     int *v2; // esi@2
     int i; // edi@2

     if ( tpenc )
     {
          v2 = ptr;
          for ( i = 0; i < a2; ++v2 )
          {
               puttable(*v2);
               ++i;
          }
     }
     else
     {
          putbuf(ptr, 4 * a2);
     }
}
void putarrcount(short *ptr, short a2)
{
     short *v2; // esi@2
     signed int i; // edi@2

     if ( tpenc )
     {
          v2 = ptr;
          for ( i = 0; i < a2; ++v2 )
          {
               putcount(*v2);
               ++i;
          }
     }
     else
     {
          putbuf(ptr, 2 * a2);
     }
}

void putkxtabs(CLArrayPtr *a1)
{
     KXTAB *v1; // esi@2
     int i; // edi@2
     int v3; // [sp+8h] [bp-10h]@1

     v3 = a1->NextElement;
     putucount(a1->NextElement);
     if ( tpenc )
     {
          v1 = (KXTAB *)a1->TableAddr;
          for ( i = 0; i < v3; ++v1 )
          {
               putbits(v1->field_0);
               putucount(v1->WhereEXP);
               putcount(v1->NumTTs);
               putcount(v1->NumKeyFields);
               putcount(v1->NumDataFields);
               putcount(v1->KeySize);
               putcount(v1->RecSize);
               puttable(v1->TTno);
               puttext(v1->TableName, 0);
               ++i;
          }
     }
     else
     {
          putbuf(a1->TableAddr, v3 << 6);
     }
}
void putrdtabs(CLArrayPtr *a1)
{
     RDTAB *v1; // esi@2
     int i; // edi@2
     int v3; // [sp+8h] [bp-10h]@1

     v3 = a1->NextElement;
     putucount(a1->NextElement);
     if ( tpenc )
     {
          v1 = (RDTAB *)a1->TableAddr;
          for ( i = 0; i < v3; ++v1 )
          {
               putcount(v1->field_0);
               putucount(v1->field_2);
               puttable(v1->TTno);
               putucount(v1->NextRD);
               ++i;
          }
     }
     else
     {
          putbuf(a1->TableAddr, 12 * v3);
     }
}
void putprtabs(CLArrayPtr *a1)
{
     PRTAB *v1; // esi@2
     int i; // edi@2
     int v3; // [sp+8h] [bp-10h]@1

     v3 = a1->NextElement;
     putucount(a1->NextElement);
     if ( tpenc )
     {
          v1 = (PRTAB *)a1->TableAddr;
          for ( i = 0; i < v3; ++v1 )
          {
               putucount(v1->field_0);
               putucount(v1->field_2);
               putucount(v1->field_4);
               putucount(v1->field_6);
               putucount(v1->NextPR);
               ++i;
          }
     }
     else
     {
          putbuf(a1->TableAddr, 10 * v3);
		  #ifdef DEBUG_DUMP
  		  DumpBlock(a1->TableAddr, 10 * v3);
		  #endif
     }
}
void putsftabs(CLArrayPtr *a1)
{
    SFTAB *v1; // esi@2
    int i; // edi@2
    int v3; // [sp+8h] [bp-10h]@1

    v3 = a1->NextElement;
    putucount(a1->NextElement);
    if ( tpenc )
	{
        v1 = (SFTAB *)a1->TableAddr;
        for ( i = 0; i < v3; ++v1 )
		{
            putbits(v1->field_0);
            putucount(v1->field_2);
            putucount(v1->field_4);
            putucount(v1->field_6);
			++i;
		}
    }
    else
	{
        putbuf(a1->TableAddr, 8 * v3);
		#ifdef DEBUG_DUMP
  		DumpBlock(a1->TableAddr, 8 * v3);
		#endif
	}
}

void puttable(int ptr)
{
     short v1; // ax@3

     if ( tpenc )
     {
          if ( tpenc )
               v1 = 68;
          else
               v1 = 0;
          xtodom((char *)&ptr, 4u, v1, (char *)&ptr);
     }
     putbuf(&ptr, 4u);
}

void putxftabs(CLArrayPtr *a1)
{
     XFTAB *v1; // esi@2
     int i; // edi@2
     int v3; // [sp+8h] [bp-10h]@1

     v3 = a1->NextElement;
     putucount(a1->NextElement);
     if ( tpenc )
     {
          v1 = (XFTAB *)a1->TableAddr;
          for ( i = 0; i < v3; ++v1 )
          {
               puttable(v1->TTno_to);
               puttable(v1->TTno_from);
               ++i;
          }
     }
     else
     {
          putbuf(a1->TableAddr, 8 * v3);
  		  #ifdef DEBUG_DUMP
   		  DumpBlock(a1->TableAddr, 8 * v3);
		  #endif
     }
}
void putratabs(CLArrayPtr *a1)
{
     RATAB *v1; // esi@2
     int i; // edi@2
     int v3; // [sp+8h] [bp-10h]@1

     v3 = a1->NextElement;
     putucount(a1->NextElement);
     if ( tpenc )
     {
          v1 = (RATAB *)a1->TableAddr;
          for ( i = 0; i < v3; ++v1 )
          {
               putcount(v1->RangeType);
               putucount(v1->RangeFrom);
               putucount(v1->RangeTo);
               putucount(v1->StringOffset);
               ++i;
          }
     }
     else
     {
          putbuf(a1->TableAddr, 12 * v3);
 		  #ifdef DEBUG_DUMP
   		  DumpBlock(a1->TableAddr, 12 * v3);
		  #endif
     }
}

void putrtabs(CLArrayPtr *a1)
{
     int v1; // edi@1
     RTAB *rt; // esi@2
     int i; // [sp+8h] [bp-10h]@2

     v1 = a1->NextElement;
     putucount(a1->NextElement);
     if ( tpenc )
     {
          rt = (RTAB *)a1->TableAddr;
          for ( i = 0; i < v1; ++rt )
          {
               putbits(rt->field_0);
               putbits(rt->field_2);
               putucount(rt->WhereEXP);
               puttable(rt->TTno);
               putucount(rt->field_C);
               putucount(rt->field_E);
               putucount(rt->NextRT);
               ++i;
          }
     }
     else
     {
          putbuf(a1->TableAddr, 20 * v1);
  		  #ifdef DEBUG_DUMP
		  DumpBlock(a1->TableAddr, 20 * v1);
		  #endif
     }
}

void putxtabs(CLArrayPtr *a1)
{
     int v1; // edi@1
     XTAB *xt; // esi@2
     int i; // [sp+8h] [bp-10h]@2

     v1 = a1->NextElement;
     putucount(a1->NextElement);
     if ( tpenc )
     {
          xt = (XTAB *)a1->TableAddr;
          for ( i = 0; i < v1; ++xt )
          {
               putbits(xt->Flags);
               putbits(xt->Attr);
               putbits(xt->ScrAttrib);
               putbits(xt->field_32);
               putcount(xt->field_6);
               putcount(xt->Width);
               putcount(xt->width);
               putcount(xt->PCol);
               putcount(xt->PLine);
               putcount(xt->ACol);
               putcount(xt->ALine);
               putcount(xt->C_X);
               putcount(xt->C_Y);
               putcount(xt->onesc != 0);        // bool
               putucount(xt->RangeID);
               putucount(xt->VarExpNo);
               putucount(xt->widthEXP);
               putucount(xt->PCol_exp);
               putucount(xt->PLine_exp);
               putucount(xt->ACol_exp);
               putucount(xt->ALine_exp);
               putucount(xt->Prompt_exp);
               ++i;
          }
     }
     else
     {
          putbuf(a1->TableAddr, 52 * v1);
  		  #ifdef DEBUG_DUMP
   		  DumpBlock(a1->TableAddr, 52 * v1);
		  #endif
     }
}

void putLong(int ptr)
{
     short v1; // ax@3

     if ( tpenc )
     {
          if ( tpenc )
               v1 = 0x44u;
          else
               v1 = 0;
          xtodom((char *)&ptr, 4u, v1, (char *)&ptr);
     }
     putbuf(&ptr, 4u);
}

void putfloat(double a1, short a2)
{
     short v2; // ax@3
     int ptr; // [sp+18h] [bp-10h]@5
     float Src; // [sp+1Ch] [bp-Ch]@1

     Src = a1;
     if ( tpenc )
     {
          if ( tpenc )
               v2 = a2;
          else
               v2 = 0;
          xtodom((char *)&ptr, 4u, v2, (char *)&Src);
     }
     putbuf(&ptr, 4u);
}

void putenodes(CLArrayPtr *a1)
{
     int v1; // edi@1
     ENTAB *entab; // esi@2
     int i; // [sp+18h] [bp-10h]@2

     v1 = a1->NextElement;
     putucount(a1->NextElement);
     if ( tpenc )
     {
          entab = (ENTAB *)a1->TableAddr;
          for ( i = 0; i < v1; ++entab )
          {
               putucount(entab->entype);
               if ( entab->entype != 1 && entab->entype != 2 )
               {
                    switch ( entab->entype )
                    {
                         case 4:
                              putfloat(*(float *)&entab->TTno, 260);
                              break;
                         case 8:
                              putLong(*(int *)&entab->TTno);
                              break;
                         case 0x10:
                              putbuf(&entab->TTno, 4u);
                              break;
                    }
               }
               else
               {
                    putcount(entab->TTno);
                    putcount(entab->RecNo);
               }
               putucount(entab->Dest);
               putucount(entab->Src);
               ++i;
          }
     }
     else
     {
          putbuf(a1->TableAddr, 12 * v1);
     }
}

void putptabs(CLArrayPtr *a1)
{
     PTAB *v1; // esi@2
     int i; // edi@2
     int v3; // [sp+8h] [bp-10h]@1

     v3 = a1->NextElement;
     putucount(a1->NextElement);
     if ( tpenc )
     {
          v1 = (PTAB *)a1->TableAddr;
          for ( i = 0; i < v3; ++v1 )
          {
               putucount(v1->SrcLineNo);
               putcount(v1->OpCode);
               putucount(v1->Operand);
               putucount(v1->TABno);
               ++i;
          }
     }
     else
     {
          putbuf(a1->TableAddr, 8 * v3);
  		  #ifdef DEBUG_DUMP
  		  DumpBlock(a1->TableAddr, 8 * v3);
		  #endif

     }
}

void putdouble(double a1, short a2)
{
     short v2; // ax@3
     double ptr; // [sp+18h] [bp-10h]@1

     ptr = a1;
     if ( tpenc )
     {
          if ( tpenc )
               v2 = a2;
          else
               v2 = 0;
          xtodom((char *)&ptr, 8u, v2, (char *)&ptr);
     }
     putbuf(&ptr, 8u);
}

void putbits(short a1)
{
     short v1; // ax@3
     short ptr; // [sp+12h] [bp-6h]@1

     ptr = a1;
     if ( tpenc )
     {
          if ( tpenc )
               v1 = 0x40u;
          else
               v1 = 0;
          xtodom((char *)&ptr, 2u, v1, (char *)&ptr);
     }
     putbuf(&ptr, 2u);
}
void putftabs(FLDdesc *ptr, int Count)
{
    FLDdesc *v2; // esi@2
    int i; // edi@2

    if ( tpenc )
	{
        v2 = ptr;
        for ( i = 0; i < Count; ++v2 )
		{
            putbits(v2->TDFtype);
            putbits(v2->FLDstat);
            putcount(v2->FLDelemID);
            putcount(v2->FLDlen);
            putcount(v2->FLDtype);
            putcount(v2->field_15);
			++i;
		}
    }
    else
    {
		putbuf(ptr, 24 * Count);
		#ifdef DEBUG_DUMP
		DumpBlock((char*)ptr, 24 * Count);
		#endif
	}
}
void dumpoe(ONESC *ptr)
{
     ONESC *onesc; // esi@1

     for ( onesc = ptr; onesc; onesc = onesc->NextESC )
     {
          if ( tpenc )
          {
               putcount(onesc->field_0);
               putcount(onesc->BlockNo);
               putcount(onesc->KeyNumber);
               putcount(onesc->NextESC != 0);   // bool to indicate more OnEsc's follow
          }
          else
          {
               putbuf(onesc, 0x10u);
          }
     }
}
void puttext(char *ptr, size_t arg)
{
     size_t v2; // esi@1
     char *v3; // edi@2
     short v4; // ecx@2
     char v5; // zf@4

     v2 = arg;
     if ( !arg )                 // If no size specified, calc the zero-terminated length
     {
          v3 = ptr;
          v4 = -1;
          do
          {
               if ( !v4 )
                    break;
               v5 = *v3++ == 0;
               --v4;
          }
          while ( !v5 );
          v2 = ~v4;
          putcount(~v4);                 // put two bytes of length
     }
     putbuf(ptr, v2);
}

void putcount(short a1)
{
     short VarType; // ax@3
     short ptr; // [sp+12h] [bp-6h]@1

     ptr = a1;
     if ( tpenc )
     {
          if ( tpenc )
               VarType = 0x44u;
          else
               VarType = 0;
          xtodom((char *)&ptr, 2u, VarType, (char *)&ptr);
     }
     putbuf(&ptr, 2u);
}

void putucount(unsigned short a1)
{
     short v1; // ax@3
     unsigned short ptr; // [sp+12h] [bp-6h]@1

     ptr = a1;
     if ( tpenc )
     {
          if ( tpenc )
               v1 = 0x40u;
          else
               v1 = 0;
          xtodom((char *)&ptr, 2u, v1, (char *)&ptr);
     }
     putbuf(&ptr, 2u);
}


#endif
