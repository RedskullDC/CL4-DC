#ifndef INDEX_POS_C
#define INDEX_POS_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

void _ipos(DPOS *dpos, int PageNo, short Depth, TDinfo *TDptr)
{
	int PageNo2; // esi@1
	short v5; // di@1
	PAGE *v6; // eax@2

//printf("_ipos - PageNo = %d\n",PageNo);
	PageNo2 = PageNo;
	dpos->field_8 = 0;
	dpos->NumEntries = 0;
	
	v5 = Depth - 1;
	while ( v5 > 0 )
	{
		v6 = _indexpg(TDptr, PageNo2);
		dpos->field_8 = PageNo2;
		PageNo2 = mstol(v6->DataStart);
		dpos->NumEntries = 1;
		--v5;
	}
	
	dpos->PageNo = PageNo2;
	dpos->field_4 = 0;
}


#endif
