#ifndef NEWEXP_C
#define NEWEXP_C

#include "DBdefs.h"

EXPR*	newexpr(short Type, short Operator, char *ExprData, size_t ExprSize)
{
	EXPR *Expr; // eax@1

	Expr = (EXPR *)alloc(ExprSize + 16, 0);				// Expression = variable length struct. 16 + expr size
	Expr->NextEXPR = 0;
	Expr->PrevEXPR = 0;
	Expr->Operator = Operator;
	Expr->Type = Type;
	Expr->ExprSize = ExprSize;
	cpybuf(&Expr->ExprData, ExprData, ExprSize);		// Data is copied to Offset 0x0E (14)
	*(char*)(&Expr->ExprData + ExprSize) = 0;			// Terminate with a ZERO

	return Expr;
}

#endif

