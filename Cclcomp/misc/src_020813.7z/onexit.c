#ifndef ONEXIT_C
#define ONEXIT_C

#include "DBdefs.h"
#include "cl4.h"

void* cdbonexit(void *a1)
{
  return a1;
}

#endif

