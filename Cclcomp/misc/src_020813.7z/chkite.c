#ifndef CHECK_ITEMS_C
#define CHECK_ITEMS_C

#include "DBdefs.h"
#include "cl4.h"
//#define _LARGEFILE64_SOURCE

void _chkitems(NODE *NodeP, short NumEntries)
{
	short v2;
	NODE_1 *N1p;
	NODE_2 *N2p;

	if ( NodeP->RecsInPage < NumEntries + NodeP->NumEntries )
	{
		v2 = (short)(NodeP->RecsInPage + NumEntries + 2);
		
		N1p = (NODE_1 *)ealloc(8 * v2, 0);
		cpybuf((char *)N1p, (char *)NodeP->NODE1ptr, 8 * NodeP->RecsInPage);
		nfree(NodeP->NODE1ptr, 0);
		NodeP->NODE1ptr = N1p;
		
		N2p = (NODE_2 *)ealloc(4 * (v2 + 1), 0);
		cpybuf((char *)N2p, (char *)NodeP->NODE2ptr, 4 * (NodeP->RecsInPage + 1));
		nfree(NodeP->NODE2ptr, 0);
		NodeP->NODE2ptr = N2p;
		
		NodeP->RecsInPage = v2;
  }
}

#endif
