#ifndef FWIDTH_C
#define FWIDTH_C

short _fwidth(char *a1, short TDFsize, short TDFtype)
{
	short v3; 

	if ( TDFtype & 2 && (v3 = scnbuf(a1, TDFsize, 0), v3 < TDFsize))  // &2 == variable size
		return (v3 + 1);	// if char* , check actual string length
	else
		return TDFsize;		// Numeric
}

#endif
