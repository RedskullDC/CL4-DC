#ifndef LEPRINT_C
#define LEPRINT_C

short leprint(void)
{
    ENTAB *v14; // eax@81
    PRTAB *v17; // edx@88
    FLDdesc *fld; // esi@80

    short *v1; // edx@5
     
    short ExpNo; // cx@16
	register short PRno;
    short v2; // eax@14
    int v4; // eax@19
    int v7; // eax@38
    int v12; // edi@80
    short v13; // ecx@81
    short v16; // ax@84
    signed int v22; // [sp+18h] [bp-20h]@7
    int TDno; // [sp+1Ch] [bp-1Ch]@7
    short a1; // [sp+20h] [bp-18h]@5
    int v25; // [sp+24h] [bp-14h]@80
    PRTAB* pr; // [sp+28h] [bp-10h]@3

	if ( symbol == 930 )	// <CR>. Error, print needs at least 1 arg
    {
		loaderr(7, sym);	// "unexpected end of line"
        return 0;
	}
    a1 = getprmem();
    allprpt(a1, &pr);
    v1 = &symbol;
    if ( symbol == 930 )	// should be unreachable, tested for 930 above
    {
		dallprpt(&pr);
        return a1;
	}
    while ( *v1 )
    {
		v22 = 0;
        TDno = 0;
printf("leprint Symbol = %d, [%s]\n",symbol, sym);

		switch (symbol)
		{
		case 2210:		// ????
		case 2200:		// 2200 = numeric constant eg 
		case 2220:		// 2220 = string literal eg. 'Simple String'
			v2 = loadsym(sym);
            if ( v2 == 1340 )                // 1340 = reserved system string name
            {
				pr->field_6 = loadresv(sym);
                symbol = getsym();
			}
            else
            {
				ExpNo = loadexp(0, 1);
                if ( !ExpNo )
				{
					dallprpt(&pr);	// error_exit
					return 0;
				}
				pr->field_0 = ExpNo;
			}
			break;

		case 2230:		// 2230 = Variable or Table Name
			if ( nxtch() != '.' )	// if a ".", then we expect a fieldname to follow
		    {
				v4 = findtd(sym, -1);
	            if ( v4 > 0 )		// This is a table variable
	            {
					TDno = v4;
	                symbol = getsym();
	                break;
				}
			}
	        ExpNo = loadexp(0, 1);
	        if ( !ExpNo )
			{
				dallprpt(&pr);	// error_exit
				return 0;
			}
			pr->field_0 = ExpNo;
	        pr->field_4 = 0x0400u;	// normal variable flag
	        v22 = 1;
			break;
		default:
			switch ( symbol )
            {
				case 770:                   // "nl"  <newline>
					pr->field_6 = 0x0004;
                    break;
				case 150:                   // "cl" clear line
					pr->field_6 = 0x0001;
                    break;
				case 520:                   // "ff"  <form feed>
					pr->field_6 = 0x0002;
                    break;
				case 250:                   // "cr"
					pr->field_6 = 0x1000u;
                    break;
				case 405:                   // "eof"   <end of file>?
					pr->field_6 = 0x2000u;
                    break;
				default:
					ExpNo = loadexp(0, 1);
                    if ( !ExpNo )
					{
						dallprpt(&pr);	// error_exit
						return 0;
					}
					pr->field_0 = ExpNo;
                    break;
			}
            if ( pr->field_6 )
                symbol = getsym();
			break;
		}

//--------------
printf("leprint#125 Symbol = %d, [%s]\n",symbol, sym);

		if ( symbol != 180 )                  // "," comma
        {
			pr->field_4 |= 0x800u;
            goto LABEL_76;
		}
        v7 = nxtch();
        if ( v7 == ' ' || v7 == '\n' )
        {
			pr->field_4 |= 0x800u;
            symbol = getsym();
            goto LABEL_76;
		}
        symbol = getsym();
        if ( syml == 1 )
        {
			switch (sym[0])
			{
			case 'c':			// centred
				symbol = 170;
				break;
			case 'l':			// left-aligned
			case '^':
				symbol = 780;
				break;
			case 'r':			// right-aligned
			case '$':
				symbol = 340;
				break;
			}
		}
printf("leprint#157 Symbol = %d, [%s]\n",symbol, sym);
		if ( symbol == 780 || symbol == 170 || symbol == 340 ) // field justification
        {
			if ( !TDno )					// normal variable, already set above
				pr->field_4 = 0x400u;
               
			if ( symbol == 340 )			// right-aligned
				pr->field_4 |= 0x2000;
               
			else if ( symbol == 170 )       // centred
				pr->field_4 |= 0x1000;
               
			else if ( symbol == 780 )       // left-aligned
				pr->field_4 |= 0x4000;
               
			symbol = getsym();
            goto LABEL_76;
		}

		// we are looking for a 1-3 digit number at this point
		if ( symbol == 2200 || symbol == 2210)
		{
			pr->field_4 = __strtol_internal(sym, 0, 10, 0);
	        symbol = getsym();
			goto LABEL_76;
		}
		if ( symbol == 930 )	// shouldn't be reachable, test for '\n' above
			goto LABEL_76;

		ExpNo = loadexp(0, 1);
        if ( !ExpNo )
		{
			dallprpt(&pr);	// error_exit
			return 0;
		}
		pr->field_2 = ExpNo;
        pr->field_4 = 0;

//================================
LABEL_76:
        if ( v22 && yflag )
			prdatefield(pr->field_0, 0, pr);
		if ( TDno )	// True if we want to print all records in the table 
        {
			v25 = pr->field_4 & 0xFFFF83FF;
            fld = ttab[TDno].TTfields;
            v12 = 0;
            while ( fld->FLDelemID )
            {
				v13 = getenmem();
				v14 = v13 ?(ENTAB *)&enarr.TableAddr[12 * (v13 - 1)] : 0;
				v14->TTno	= TDno;
                v14->RecNo	= v12;
                v14->entype = 1;
                pr->field_0 = v13;
                
				pr->field_4 &= 0x7C00u;
                if ( v25 )
					v16 = v25 | pr->field_4;
				else
					v16 = pr->field_4 | 0x0400;
                pr->field_4 = v16;

                if ( fld[1].FLDelemID )
                {
					//*** getprmem() can change pr ***
					//pr->NextPR = getprmem();
					PRno = getprmem();
					pr->NextPR = PRno;
                    v17 = (PRTAB *)(pr->NextPR ? &prarr.TableAddr[10 * (pr->NextPR - 1)] : 0);
                    if ( !v17 )
						__assert_fail("pf != ((void *)0)", "leprint.c", 245, "leprint");
                    v17->field_4 = pr->field_4;
                    pr = v17;
				}
                ++v12;
                ++fld;
			}
		}

		if ( symbol != 930 )
        {
			//*** getprmem() can change pr ***
			//pr->NextPR = getprmem();
			PRno = getprmem();
			pr->NextPR = PRno;
            v17 = (PRTAB *)(pr->NextPR ? &prarr.TableAddr[10 * (pr->NextPR - 1)] : 0);
            pr = v17;
            if ( !v17 )
				__assert_fail("pf != ((void *)0)", "leprint.c", 255, "leprint");
		}
        v1 = &symbol;
        if ( symbol == 930 )
		{
			dallprpt(&pr);
	        return a1;
		}
	}
    dallprpt(&pr);
    return 0;
}

#endif
