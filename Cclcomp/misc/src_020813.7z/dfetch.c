#ifndef DFETCH_C
#define DFETCH_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

short _dfetch(char *Dest, DPOS *dpos, TDinfo *TDptr)
{
	PAGE *v3; // eax@6
	NODE *v4; // edx@14
	short v5; // ax@16
	NODE_1 *node1; // eax@16
	short v9; // [sp+18h] [bp-10h]@11

	printf("_dfetch(Dest : x%08X, DPOS : x%08X, TDptr :x%08X)\n",Dest,dpos,TDptr);

	if ( TDptr->TDNodePtr && TDptr->TDNodePtr->PageNo != dpos->PageNo )
	{
		relnode(TDptr->TDNodePtr);
		TDptr->TDNodePtr = 0;
	}
	if ( dpos->PageNo )
		goto LABEL_21;
	if ( dpos->field_8 )
	{
		v3 = _indexpg(TDptr, dpos->field_8);
		if ( !dpos->NumEntries )
			dpos->NumEntries = v3->NumEntries + 1;
		--dpos->NumEntries;
		dpos->PageNo = mstol(&v3->DataStart[4 * dpos->NumEntries]);
		if ( !dpos->NumEntries )
			dpos->field_8 = mstol(&v3->field_12);
	}
	if ( dpos->PageNo )
	{
LABEL_21:
		if ( !TDptr->TDNodePtr )
			TDptr->TDNodePtr = getnode(TDptr, dpos->PageNo, 0);
		v4 = TDptr->TDNodePtr;
		if ( !dpos->field_4 )
			dpos->field_4 = v4->NumEntries;
		v5 = dpos->field_4 - 1;
		dpos->field_4 = v5;
		node1 = &v4->NODE1ptr[v5];
		v9 = cpybuf(Dest, node1->Data, node1->Size);
		if ( !dpos->field_4 )
		{
			relnode(TDptr->TDNodePtr);
			TDptr->TDNodePtr = 0;
			dpos->PageNo = 0;
		}
	}
	else
	{
		v9 = 0;
	}
	return v9;
}


#endif
