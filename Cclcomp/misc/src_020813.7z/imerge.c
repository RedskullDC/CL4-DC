#ifndef IMERGE_C
#define IMERGE_C

#include "DBdefs.h"
#include "cl4.h"

void _imerge(SALLOCBUF *SAp, TDinfo *TDptr)
{
	SALLOCBUF *i; // edi@1

	for ( i = SAp; i; i = i->NextSA )
	{
		relnode(TDptr->TDNodePtr);
		TDptr->TDNodePtr = 0;
		_ipos((DPOS*)&i->field_C, i->field_4, i->field_8, TDptr);
		i->field_1C = _ifetch((char*)&i->field_20,(DPOS*)&i->field_C, TDptr);
	}
}

#endif

