#ifndef LOADVARS_C
#define LOADVARS_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "lvars.h"

VARTREE *mktree(VARTREE *a1, const char *s1, int a3, int a4)
{
	VARTREE *v4; // esi@1
	short v5; // dx@3

	v4 = a1;
	if ( a1 )
	{
		v5 = strncmp(s1, a1->VarName, a3 + 1);
		if ( !v5 )
			__assert_fail("0", "gettnode.c", 0x6Au, "mktree");
		if ( v5 >= 0 )
		{
			if ( v5 > 0 )
				a1->VarNext = mktree(a1->VarNext, s1, a3, a4);
		}
		else
		{
			a1->VarPrev = mktree(a1->VarPrev, s1, a3, a4);
		}
	}
	else
	{
		v4 = (VARTREE *)getmem(16);
		v4->VarName = getmem(a3 + 1);
		cpybuf(v4->VarName, (char *)s1, a3);
		v4->field_0 = a4;
	}
	return v4;
}

VARTREE *dogettnode(VARTREE *a1, const char *s1, int a3, int a4)
{
  VARTREE	*v4; // edi@1
  VARTREE	*result; // eax@2
  short		v6; // ax@3
  short		v7; // dx@7

  v4 = a1;
  if ( a1 )
  {
    v7 = strncmp(s1, a1->VarName, a3 + 1);
    if ( v7 )
    {
      if ( v7 >= 0 )
      {
        if ( v7 > 0 )
          a1->VarNext = dogettnode(a1->VarNext, s1, a3, a4);
      }
      else
      {
        a1->VarPrev = dogettnode(a1->VarPrev, s1, a3, a4);
      }
    }
    else
    {
      last_fnd = a1->field_0;
      ++tnodewasfound;
    }
  }
  else
  {
    result = 0;
    if ( !a4 )
      return result;
    v4 = (VARTREE *)getmem(16);
    v4->VarName = getmem(a3 + 1);
    cpybuf(v4->VarName, (char *)s1, a3);
    v6 = last_var++;
    last_fnd = v6;
    v4->field_0 = v6;
    if ( last_fnd < res_v_max )
    {
      if ( (unsigned char)(*s1 - 97) <= 0x19u )
        __assert_fail("!('a' <= (*w) && (*w) <= 'z')", "gettnode.c", 0x8Eu, "dogettnode");
      rtroot = mktree(rtroot, s1, a3, last_fnd);
    }
  }
  return v4;
}

VARTREE *gettnode(VARTREE *a1, char *arg, int a3, int a4)
{
  VARTREE *result; // eax@5
  char s1[128]; // [sp+20h] [bp-88h]@2

	tnodewasfound = 0;
	if ( alllower(arg) && (strcpy(s1, arg), alltoupper(s1), dogettnode(rtroot, s1, a3, 0), tnodewasfound) )
	{
		if ( !noWarnings )
		{
			eprint("\"%s\", line %4d - ", FileTree->FileName, (unsigned short)ll);
			eprint("warning: [%s] - replace with", arg);
			eprint(" [%s]\n", s1);
		}
		result = a1;
	}
	else
	{
		result = dogettnode(a1, arg, a3, a4);
	}
	return result;
}

char *getmem(int MemSize)
{
  int Required; // eax@1

  Required = MemSize;
  if ( MemSize & 1 )
    Required = MemSize + 1;
  if ( Required & 2 )
    Required += 2;                              // round up to nearest 4 bytes
  return (char *)mmalloc(Required);
}

FLDdesc *getvars(int Varnum)
{
	//printf("getvars(%d)\n",Varnum);
	return ( Varnum < Nvars ) ? &ttab->TTfields[Varnum] : 0;
}

FLDdesc *getvarmem(void)
{
  short v0; // cx@3
  int v1; // edi@3

  if ( !Nvars )
    ttab->TTfields = (FLDdesc *)mmalloc(0);
  v0 = Nvars++;
  v1 = v0;
  ttab->TTfields = (FLDdesc *)mrealloc(ttab->TTfields, 24 * v0, 24 * Nvars);
  return &ttab->TTfields[v1];
}

void loadvars(void)
{
	FLDdesc *v0; // esi@1
	FLDdesc *fld; // edi@4
	int v3; // eax@7

	//res_v_max = 62;
	res_v_max = sizeof(lvars)/sizeof(FLDdesc) - 1;
	v0 = lvars;
	while ( v0->FLDname )
	{
		if ( getvars(last_var) )
			__assert_fail("getvars(last_var) == ((void *)0)", "loadvars.c", 105, "loadvars");

		fld = getvarmem();
		if ( fld != getvars(last_var) )
			__assert_fail("vv == getvars(last_var)", "loadvars.c", 107, "loadvars");

		if ( v0->FLDtype == 'C' )
			v3 = v0->FLDlen + 1;
		else
			v3 = 8;
		
		v0->FLDdata = getmem(v3);
		cpybuf((char*)fld,(char*)v0, sizeof(FLDdesc));
		troot = gettnode(troot, v0->FLDname, lenstr(v0->FLDname), 1);
		++v0;
	}
	if ( last_var != res_v_max )
		__assert_fail("last_var == res_v_max", "loadvars.c", 112, "loadvars");

}
#endif
