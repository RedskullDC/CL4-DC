#ifndef CLVERS_C
#define CLVERS_C

#include <stdio.h>
#include "DBdefs.h"
#include "cl4.h"

// removed the isClDemo test.

char	clv_0[48];
char*	getclver(void)
{
	sprintf(clv_0, "[Linux2.4-libc2.3] %d.%d.%d", 4, 4, 4);
	return clv_0;
}

#endif
