#ifndef NEXTCHAR_C
#define NEXTCHAR_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

int getnch()
{
  int NextChar; // edx@3

  while ( 1 )
  {
    NextChar = getch();
    if ( NextChar != -1 )
      break;
    if ( !FileTree->field_C )
      break;
    fclose(FileTree->PrevFILE);
    mfree_0(FileTree->FileName);
    FileTree = FileTree->field_C;
    mfree_0(FileTree->field_10);
    MainFile = FileTree->PrevFILE;
    ll = FileTree->LastLine;
  }
  return NextChar;
}


#endif
