#ifndef GETIDENT_C
#define GETIDENT_C

short getident(char *FieldName, int *TTno, char *FieldType)
{
	int v3; // eax@5
    short v4; // eax@8
    short FieldNo; // ax@9
    char v7; // al@11
    signed int WholeTable; // [sp+2Ch] [bp-7Ch]@3
    char TableName[32]; // [sp+30h] [bp-78h]@2
    char v13[32]; // [sp+50h] [bp-58h]@2
    char FieldName2[128]; // [sp+70h] [bp-38h]@2

	if ( !symbol )
        return -1;                      // -1 == ERROR

	cdbcpystr(TableName, FieldName, 0);
    cdbcpystr(v13, FieldName, 0);           // not actually used. Debug code?
    FieldName2[0] = 0;
    symbol = getsym();
    if ( symbol == 1080 )                   // "." (decimal point)
    {
		WholeTable = 0;
        symbol = getsym();
        cdbcpystr(FieldName2, sym, 0);
        cdbcpystr(v13, v13, ".", sym, 0);   // v13 isn't actually used below....
    }
    else
    {
		WholeTable = 1;                     // if no ".", we want to include *all* fields from this table
	}
    v3 = findtd(TableName, -1);
    *TTno = v3;
    if ( v3 < 0 )                           // can't find this table amongst the open tables
    {
        loaderr(14, TableName);				// "table not open"
        return -1;							// -1 == ERROR
	}
    if ( !WholeTable )
    {
		FieldNo = findfno(*TTno, FieldName2);
        v4 = FieldNo;
        if ( FieldNo >= 0 )
        {
			v7 = ttab[*TTno].TTfields[FieldNo].FLDtype;
            *FieldType = v7;
            if ( v7 != 'S' && v7 != 'K' )
            {
				symbol = getsym();
                return v4;					// Return the FieldNo in this case
			}
		    loaderr(24, FieldName2);		// "invalid operation on 'set' or 'key' field"
		}
        else
	        loaderr(8, FieldName2);			// "invalid field name or number"

		return -1;							// -1 == ERROR
	}
    return -*TTno;                          // Return the *negative* TD no if whole Record
	
	// Will be in the <= -3 if a user table.
	// Safe to use -1 as an error indicator
}
#endif
