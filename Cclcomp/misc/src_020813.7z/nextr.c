#ifndef NEXTREC_C
#define NEXTREC_C

#include "DBdefs.h"
#include "cl4.h"
NODE_1* _stepfwd(TDinfo *TDptr);
char* DumpShortBits(short Input, char Output[20]);

int _nxtr(int TDNo, char *WorkArea, int SkipRecs, POS *Pos, EXPR *SelectExpr)
{
	TDinfo *TDptr;
	int v8;
	NODE_1 *Node1Ptr;
	int v11;

	//printf("_nxtr( TDno: x%04X (%3d),WorkArea = %s,SkipRecs = %d, POS = x%08X, EXPR: x%08X)\n", TDNo,TDNo,WorkArea,SkipRecs,Pos,SelectExpr);

	TDptr = _chktd(TDNo);
	v8 = check_bup_sem(TDptr->TDDBinfo);
	if ( v8 )
		derror(v8, 0, TDptr);
	
	v8 = 0;	// not really necessary, since above check means v8 = ZERO anyway

	//printf("_nxtr: field_0: x%04X ( %s )\n",TDptr->field_0,DumpShortBits(TDptr->field_0,Buff));
	
	if ( (TDptr->field_0 & 0x0210) != 0x0010 )
	{
		if ( TDptr->field_0 & 0x0200 )
		{
			relnode(TDptr->TDNodePtr);
			TDptr->TDNodePtr = 0;
			TDptr->field_0 &= 0xFDFFu;
		}
		if ( TDptr->field_0 & 0x02 )
			return _picknxt(TDptr, WorkArea, SkipRecs, Pos);
    
		if ( !TDptr->KeyBuf1 )
			newseq(TDptr);
		
		if ( Pos )
			cdbrindex(Pos, 0);	// pointless code?

		TDptr->Key2Size = 0;
		v11 = 0;
		if ( SkipRecs > 0 )
		{
			while ( 1 )
			{
				while ( 1 )
				{
					Node1Ptr = _stepfwd(TDptr);
					if ( Node1Ptr )
						break;
					// if !Node1Ptr, we are past end of records
					TDptr->field_0 |= 0x0010u;
LABEL_25:
					if ( !(TDptr->field_0 & 0x0010) )
					{
						++v8;
						//printf("_nxtr: V11 = %d, SkipRecs = %d\n",v8, SkipRecs);
						if ( v8 < SkipRecs )
							continue;
					}
					if ( !v8 )
						relseq(TDptr);
					return v8;
				}
				//------------
				if ( _match(Node1Ptr->Data, SelectExpr, TDptr->TableDefs) )
				{
					//printf("_nxtr: match == true\n");
					// found a record which matches expression, jump out
					break;
				}
				//printf("_nxtr: match == false\n");
				if ( _beyond(SelectExpr, 0x18u, Node1Ptr->Data, TDptr->TableDefs) ) // 0x18 == "Less than or equal"
				{
					// if true, there are more records left, but they don't satisfy our expression!
					//printf("_nxtr: beyond == true\n");
					TDptr->field_0 |= 0x10u;
					if ( !v8 )
						relseq(TDptr);
					return v8;
				}
			}
			if ( !TDptr->Key2Size )
			{
				TDptr->Key2Size = cpybuf(TDptr->KeyBuf2, Node1Ptr->Data, TDptr->TDKeySize);
				TDptr->field_42 = 1;
			}
			if ( SkipRecs == 1 ) // if not skipping records, save to workarea
				tuptor(WorkArea, Pos, Node1Ptr->Data, TDptr->TableDefs);

			if ( Node1Ptr )
				goto LABEL_25;
			TDptr->field_0 |= 0x10u;
		}
		if ( !v8 )
			relseq(TDptr);
	}
	return v8;
}

// HACK! These should call through xenter()

int nxtr(int TDNo, char *WorkArea, POS *Pos, EXPR *Expr)
{
  return _nxtr(TDNo, WorkArea, 1, Pos, Expr);
}

// same as nxtr()
int nextr(int TDNo, char *WorkArea, POS *Pos, EXPR *Expr)
{
    return _nxtr(TDNo, WorkArea, 1, Pos, Expr);
}

// Pos = 0.  Assume no data re-positioning in output buffer
int getnxt(int TDno, char *WorkArea, EXPR *Expression)
{
  return _nxtr(TDno, WorkArea, 1, 0, Expression);
}

// nextset allows SkipRecs value to be specified
int nextset(int TDno, char *WorkArea, int SkipRecs, POS *Pos, EXPR *SelectExpr)
{
  return _nxtr(TDno, WorkArea, SkipRecs, Pos, SelectExpr);
}

#endif
