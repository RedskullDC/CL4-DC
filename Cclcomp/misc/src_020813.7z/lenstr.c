#ifndef LENSTR_C
#define LENSTR_C

int lenstr(char *a1)
{
  char *i; // eax@1

  for ( i = a1; *i; ++i )
    ;
  //printf("Length = %d \n",i-a1);
  return i - a1;
}

#endif
