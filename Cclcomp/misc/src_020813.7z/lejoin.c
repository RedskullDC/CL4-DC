#ifndef LEJOIN_C
#define LEJOIN_C

int lejoin(short PTno, int join)
{
    PTAB  *ptab; // esi@1
    ENTAB *v12; // edx@30
    ENTAB *entb;
    XTAB  *xtb;
	RTAB  *rtb;

    short v5; // si@10
    short v7; // ax@17
    short v8; // dx@22
    short v9; // si@24
    short v11; // cx@27
    int v20; // [sp+0h] [bp-38h]@2
    char *v21; // [sp+4h] [bp-34h]@2
    short RTno; // [sp+14h] [bp-24h]@13
    int TDno; // [sp+1Ch] [bp-1Ch]@13
	char	FLDtype;

    ptab = PTARR(getptabp(PTno - 1));
    allxtpt(ptab->TABno, &xtb);
    if ( ptab->OpCode != 1 )	// accept field
    {
          loaderr(20, sym);		// "previous field not accept field"
          dallxtpt(&xtb);
          return 0;
	}
    symbol = getsym();
    if ( symbol != 2230 )
    {
        if ( symbol == 930 )
			loaderr( 7, sym);		// "unexpected end of line"
		else
			loaderr(33, sym);		// "unexpected symbol"
        dallxtpt(&xtb);
        return 0;
	}
    v5 = getenmem();
    if ( !gettfexp(v5) )
	{
		dallxtpt(&xtb);
        return 0;
	}
	if ( xtb->RangeID )
    {
		loaderr(18, sym);			// "cannot join and range check"
        dallxtpt(&xtb);
        return 0;
	}
    
	RTno = getrtmem();
    allrtpt(RTno, &rtb);
    rtb->field_C = v5;
    rtb->field_E = xtb->VarExpNo;
    if ( gettf(v5, &TDno, &FLDtype) < 0 )
    {
        __assert_fail("fno >= 0", "lejoin.c", 62, "lejoin");
	}
    rtb->TTno = TDno;

	if (join)		// Join == 1 join, 0 nojoin
		rtb->field_2 = 0x40u;
	else
		rtb->field_2 = 1;

    xtb->RangeID = RTno;
    
	v7 = xtb->Flags | 0x0100;
    if ( join )
		v7 = xtb->Flags | 0x0010;
    xtb->Flags = v7;
    
	dallxtpt(&xtb);
    if ( symbol == 800 )                       // "lock"
    {
		symbol = getsym();
        xtb->Flags |= 0x20u;
        rtb->field_0 |= 0x400u;
    }
    
	if ( symbol == 1720 )                      // where
    {
		symbol = getsym();
        v8 = loadexp(1, 1);
        if ( !v8 )
        {
			dallrtpt(&rtb);
            return 0;
        }
        rtb->WhereEXP = v8;
        
		v9 = getenmem();
        allenpt(v9, &entb);
        entb->TTno = 2;
        entb->entype = 2;
        entb->Src = rtb->WhereEXP;
        entb->Dest = getenmem();
        rtb->WhereEXP = v9;
        dallenpt(&entb);

		entb = rtb->WhereEXP ? (ENTAB *)&enarr.TableAddr[12 * (rtb->WhereEXP - 1)] : 0;

		allenpt(entb->Dest, &entb);
        entb->TTno = 16;
        entb->entype = 2;
//----------------------------
		entb->Dest = getenmem();
		v11 = gettf(rtb->field_C, &TDno, &FLDtype);
        if ( v11 < 0 )
            __assert_fail("fno >= 0", "lejoin.c", 106, "lejoin");

		v12 = entb->Dest ? (ENTAB *)&enarr.TableAddr[12 * (entb->Dest - 1)] : 0;
        v12->TTno = TDno;
        v12->RecNo = v11;
		v12->entype = 1;
//-----------------------------
		entb->Src = getenmem();
        
		v11 = gettf(rtb->field_E, &TDno, &FLDtype);
        if ( v11 < 0 )
			__assert_fail("fno >= 0", "lejoin.c", 115, "lejoin");

		v12 = entb->Src ? (ENTAB *)&enarr.TableAddr[12 * (entb->Src - 1)] : 0;
		v12->TTno = TDno;
		v12->RecNo = v11;
		v12->entype = 1;

		dallenpt(&entb);
	}
    dallrtpt(&rtb);
    if ( symbol != 930 )
    {
		loaderr(33, sym);
		return 0;
	}
    return 1;
}

#endif
