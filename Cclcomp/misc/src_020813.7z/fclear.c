#ifndef CDBFCLEAR_C
#define CDBFCLEAR_C

#include "DBdefs.h"
#include "cl4.h"

int cdbfclear(char *Buff, short TDFsize, short TDFtype)
{
    char *v3; // edx@1
    short v4; // cx@2

    *Buff = 0;
    v3 = Buff + 1;
    if ( !(TDFtype & 2) )
    {
        v4 = TDFsize - 1;
        while ( v4 > 0 )
        {
			*v3++ = 0;
            --v4;
        }
    }
    return v3 - Buff;
}

#endif
