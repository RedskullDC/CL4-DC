#ifndef LEFORMAT_C
#define LEFORMAT_C

int leformat(short *a3, int a4)
{
     BTAB *v3; // esi@6
     short v4; // edi@6
     short v6; // ST00_2@18
     short v7; // ax@18
     short v8; // ST00_2@19
     short v9; // ax@19
     short v10; // si@20
     size_t MaxLen; // [sp+18h] [bp-60h]@6
     PTAB *ptab; // [sp+1Ch] [bp-5Ch]@18
     char v17[8192]; // [sp+20h] [bp-58h]@6

	symbol = getsym();
    if ( symbol != 2230 )                   // 2230 must be a string literal?
    {
		if ( symbol == 930 )
			loaderr(2, sym);				// "missing block name"
		else
			loaderr(33, sym);				// "unexpected symbol"
		return 0;
    }
    MaxLen = fixbname(v17, sym);
    v3 = btab;
    v4 = 0;
    
	if ( !v3->BlockName[0] )
		goto LABEL_11;
    while ( !cmpbuf(v3->BlockName, v17, MaxLen) )
    {
        v4++;
        v3++;
        if ( !v3->BlockName[0] )
			goto LABEL_11;
    }
    if ( !v3->BlockName[0] )
	{
LABEL_11:
		if ( no_btabs > v4 )
			__assert_fail("i >= no_btabs", "leformat.c", 41, "leformat");

		newbtab();
        if ( no_btabs <= v4 )
			__assert_fail("i < no_btabs", "leformat.c", 44, "leformat");

		cdbcpystr(btab[v4].BlockName, v17, 0);
	}
//----------------------
    if ( !a4 )
    {
		v6 = (*(int*)a3)++;
        v7 = getptabp(v6);
        ptab = PTARR(v7);
        ptab->OpCode = 950;
    }
    v8 = (*(int*)a3)++;
    v9 = getptabp(v8);
    allptpt(v9, &ptab);
    ptab->OpCode = 600;
    ptab->Operand = v4;
    ptab->SrcLineNo = lla;
    symbol = getsym();
    if ( symbol == 2230 )
    {
		v10 = getenmem();
        if ( !gettfexp(v10) )
        {
			loaderr(8, sym);	// "invalid field name or number"
            dallptpt(&ptab);
            return 0;
		}
        ptab->TABno = v10;
        symbol = getsym();
	}
    dallptpt(&ptab);
    return 1;
}

#endif
