#ifndef LEREAD_C
#define LEREAD_C

short leread(int InOut)
{
    short v1; // ax@1
 	register short PRno;
    int v2; // eax@4
    unsigned char v3; // cf@7
    unsigned char v4; // zf@7
    char *v5; // esi@8
    signed int v6; // ecx@8
    char *v7; // edi@8
    short v8; // si@12
    short v9; // dx@12
    short *v10; // edx@22
    short ENno; // esi@27
    FLDdesc *fld; // edi@26
    ENTAB *v13; // eax@27
    PRTAB *v14; // eax@31
    short v15; // si@36
    short v17; // dx@47
    short v18; // dx@50
    signed int v20; // [sp+8h] [bp-30h]@1
    signed int v21; // [sp+14h] [bp-24h]@11
    short v22; // [sp+18h] [bp-20h]@1
    int TDno; // [sp+1Ch] [bp-1Ch]@25
    int i; // [sp+20h] [bp-18h]@26
    PRTAB *prtab; // [sp+24h] [bp-14h]@22
    SFTAB *sftab; // [sp+28h] [bp-10h]@1

    v20 = (unsigned short)symbol;
    v22 = getsfmem();
    allsfpt(v22, &sftab);
    v1 = getsym();
    symbol = v1;
    if ( v1 != 2230 && v1 != 2220 )
    {
		if ( symbol == 930 )
			v2 = 50;                         // "missing file/pipe name"
		else
			v2 = 51;                         // "invalid file/pipe name"
		loaderr(v2, sym);
        dallsfpt(&sftab);
        return 0;
	}
    v3 = (unsigned short)symbol < 2220u;
    v4 = symbol == 2220;
    if ( symbol != 2220 )
		goto LABEL_62;
	v5 = sym;
    v6 = 7;
    v7 = "tables";                             // looks like some nice undocumented "tables" modifier!!
    do
    {
		if ( !v6 )
			break;
		v3 = *v5 < (unsigned char)*v7;
        v4 = *v5++ == *v7++;
        --v6;
	}
    while ( v4 );
    v21 = 1;
    if ( !(v3 | v4) != v3 )
    {
LABEL_62:
		v21 = 0;
        v8 = loadexp(0, 1);
        v9 = 0;
        if ( !v8 )
			return v9;
		sftab->field_4 = v8;
	}


//-------------------------------     
// "read" handler

	if ( v20 == 540 )                          // read
    {
		if ( symbol != 930 )
        {
			sftab->field_2 = getprmem();
            allprpt(sftab->field_2, &prtab);
            v10 = &symbol;
            if ( symbol != 930 )
            {
				while ( *v10 == 2230 )      // while string literal
                {
					if ( nxtch() == '.' || (TDno = findtd(sym, -1), TDno <= 0) )// read single field
                    {
						v15 = getenmem();
						if ( !gettfexp(v15) )
						{                    
							dallsfpt(&sftab);
							dallprpt(&prtab);
							return 0;
						}
						prtab->field_0 = v15;
					}
                    else                   // read all fields in a table
                    {
						fld = ttab[TDno].TTfields;
                        for ( i = 0; fld->FLDelemID; ++fld )
                        {
							ENno = getenmem();
							v13 = ENno ? (ENTAB *)&enarr.TableAddr[12 * (ENno - 1)] : 0;
							v13->TTno = TDno;
                            v13->RecNo = i;
                            v13->entype = 1;
                            prtab->field_0 = ENno;
                            if ( fld[1].FLDelemID )
                            {
								//*** getprmem() can change prtab! ***
								//prtab->NextPR = getprmem();
								PRno = getprmem();
								prtab->NextPR = PRno;
								v14 = prtab->NextPR ? (PRTAB *)&prarr.TableAddr[10 * (prtab->NextPR - 1)] : 0 ;
								prtab = v14;
							}
                            ++i;
						}
                        symbol = getsym();
					}
                    if ( symbol != 930 )
                    {
						//*** getprmem() can change prtab! ***
						//prtab->NextPR = getprmem();
						PRno = getprmem();
						prtab->NextPR = PRno;
						v14 = prtab->NextPR ? (PRTAB *)&prarr.TableAddr[10 * (prtab->NextPR - 1)] : 0;
						prtab = v14;
					}
					v10 = &symbol;
                    if ( symbol == 930 )
					{
						dallprpt(&prtab);
			            sftab->field_0 = 1;
						goto LABEL_56;
					}
				}
                loaderr(56, sym);           // "invalid in read statement"
                dallsfpt(&sftab);
                dallprpt(&prtab);
                return 0;
			}
            dallprpt(&prtab);
            sftab->field_0 = 1;
            goto LABEL_56;
		}
        loaderr(7, sym);                      // "unexpected end of line"
        return 0;
	}
//--------------------
	
	if ( v20 <= 540 )                          // "read"
	{
		if ( v20 == 440 )                     // "close"
        {
			v18 = 0x20u;
            if ( !v21 )
				v18 = 0x08u;
			sftab->field_0 = v18;
            symbol = getsym();
		}
        goto LABEL_56;
	}
    if ( v20 == 560 || v20 == 1230 )           // 560 = "write", 1230 = ???
    {
		if ( symbol == 930 )
        {
			loaderr(7, sym);				// "unexpected end of line"
			return 0;
		}
		sftab->field_0 = 2;
        v17 = leprint();
        if ( !v17 )
        {
			dallsfpt(&sftab);
            return 0;
		}
        sftab->field_2 = v17;
        goto LABEL_56;
	}
LABEL_56:
    if ( InOut )
		sftab->field_0 |= 0x0040u;
	dallsfpt(&sftab);
    return v22;
}

#endif
