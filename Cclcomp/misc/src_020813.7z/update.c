#ifndef UPDATE_C
#define UPDATE_C

#include "DBdefs.h"
#include "cl4.h"

bool _update(TDinfo *TDptr, char *WorkArea, POS *Pos, short a4, short *a5)
{
	short v5; // ax@2
	int v6; // esi@2
	NODE *NodePtr;
	int v8;
	int PID;
	int v10;
	short v11;
	bool result; // bool?
	char *RecBuffer; // [sp+2Ch] [bp-5Ch]@1
	int v14; // [sp+30h] [bp-58h]@1
	bool v15; // [sp+34h] [bp-54h]@1
	short PutMode; 
	int PageList[6];
	short N1_2idx;

	//printf("_update(TDptr: x%08X,WorkArea: x%08X,POS: x%08X, a4: x%02X, a5: x%08X)\n" ,TDptr,WorkArea,Pos,a4,a5);

	// bitfields in a4.
	// ZERO = delete record
	PutMode = a4;
	v14 = 0;
	v15 = 0;
	RecBuffer = ealloc(TDptr->TDRecSize, 0);
	TDptr->KeyDefSize = rtokey(TDptr->TDKeyDefs, WorkArea, Pos, TDptr->TableDefs);
	//printf("_update : KeyDefSize = %d\n",TDptr->KeyDefSize);
	while ( 1 )
	{
		while ( 1 )
		{
			emark(TDptr->TDDBinfo, TDptr->TDindexOff);
			v5 = _getpath(PageList, TDptr);
			v6 = v5;
			//printf("_update : _getpath returned = %d\n",v5);
			if ( v5 )
				break;
			if ( !PutMode )
				goto LABEL_33;
			if ( v14 )
				break;
			v14 = _locktbl(TDptr->TDDBinfo, TDptr->TDindexOff, 1);
			if ( !v14 )
				goto LABEL_32;
		}
		if ( v5 <= 0 || _lockpg(TDptr->TDDBinfo, PageList[v5 - 1], 2) )
			break;
LABEL_32:
		ewait(TDptr->TDDBinfo, TDptr->TDindexOff);
	}
//----------------
  
	if ( !v6 )
	{
		NodePtr = freshnode(TDptr, 0);
		N1_2idx = 0;
		goto LABEL_22;
	}

//----------------

	NodePtr = getnode(TDptr, PageList[v6 - 1], 0);
	v8 = _scanpg((PAGE*)NodePtr, TDptr, &N1_2idx, 1);	// scanpg takes NODE or PAGE structure.
	v15 = v8;
	if ( PutMode != 1 )
	{
		if ( v8 )
		{
			if ( PutMode == 0 )
			{
				delpage(NodePtr, N1_2idx);
				goto LABEL_22;
			}
			if ( v8 )
				goto LABEL_18;
		}
		if ( PutMode == 0 )
		{
			if ( v8 )
			{
LABEL_18:
				if ( PutMode == 2 )
				{
					PID = mstol((int *)(NodePtr->NODE1ptr[N1_2idx].Data + 129));
					if ( PID == getpid() )
						v15 = v15 == 0;
				}
			}
			_lockpg(TDptr->TDDBinfo, NodePtr->PageNo, 0);
			relnode(NodePtr);
			goto LABEL_33;
		}
	}
LABEL_22:
//-------------------
	if ( PutMode == 2 )
	{
		//printf("_update: calling rtotup()\n");
		v10 = rtotup(RecBuffer, WorkArea, Pos, TDptr->TableDefs);
		addpage(NodePtr, N1_2idx,RecBuffer, v10);
	}
	else
	{
		if ( v15 )
		{
			if ( PutMode == 1 )
			{
				v11 = _uptuple(RecBuffer, NodePtr->NODE1ptr[N1_2idx].Data, WorkArea, Pos, TDptr->TableDefs, a5);
				modpage(NodePtr, N1_2idx, RecBuffer, v11);
			}
		}
		else
		{
			if ( PutMode )
			{
				v10 = rtotup(RecBuffer, WorkArea, Pos, TDptr->TableDefs);
				addpage(NodePtr, N1_2idx,RecBuffer, v10);
			}
		}
	}
//-------------------
	if ( !_balance(TDptr, NodePtr, PageList, v6) )
		goto LABEL_32;
	if ( v14 )
		_locktbl(TDptr->TDDBinfo, TDptr->TDindexOff, 0);

LABEL_33:
	ewake(TDptr->TDDBinfo, TDptr->TDindexOff);
	nfree(RecBuffer, 0);
	result = v15;
	if ( PutMode == 2 )
		result = v15 == 0;
	return result;
}

#endif
