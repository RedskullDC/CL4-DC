#ifndef NEWTABS_C
#define NEWTABS_C

#include "DBdefs.h"
#include "cl4.h"

void newdtab(void)
{
	int v0; // edx@2

	//printf("newdtab() - no_dtabs = %d\n",no_dtabs + 1 );

	if ( no_dtabs )
		v0 = no_dtabs + 1;
	else
		v0 = 0;
	dtab = ( DBase *)mrealloc(dtab, 12 * v0, 12 * (no_dtabs + 2));
	++no_dtabs;
}

void newttab(void)
{
	int v0; // edx@2

	//printf("newttab() - no_ttabs = %d\n",no_ttabs + 1 );
	if ( no_ttabs )
		v0 = no_ttabs + 1;
	else
		v0 = 0;
	ttab = (TDesc *)mrealloc(ttab, 80 * v0, 80 * (no_ttabs + 2));
	++no_ttabs;
}

#endif
