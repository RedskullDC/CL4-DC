#ifndef LEOPEN_C
#define LEOPEN_C

void newfile()
{
    int v0;
	
	v0 = no_files++;
    _files = (FCB *)mrealloc(_files, 28 * v0, 28 * no_files);
}

short leopen(int a1)
{
    short SFno; // ax@1
    signed int symb; // edi@3
    short v3; // ax@3
    char *StrVal; // esi@9
    short v6; // dx@12
    FCB *fcb; // edx@15
    short FCBno; // esi@15
    char v9; // zf@26
    short v13; // [sp+18h] [bp-20h]@12
    short v14; // [sp+18h] [bp-20h]@40
    short v15; // [sp+1Ch] [bp-1Ch]@1
    SFTAB *sft; // [sp+20h] [bp-18h]@1
    int TDno; // [sp+24h] [bp-14h]@13
    char FLDtype; // [sp+2Bh] [bp-Dh]@13

	SFno = getsfmem();
    v15 = SFno;
	
	sft = SFno ? (SFTAB *)&sfarr.TableAddr[8 * (SFno - 1)] : 0;
	
	symb = (unsigned short)symbol;
    v3 = getsym();
    symbol = v3;
    if ( v3 != 2230 && v3 != 2220 )
    {
		if ( symbol == 930 )
			loaderr(50, sym);                         // "missing file/pipe name"
		else
			loaderr(51, sym);                         // "invalid file/pipe name"
		return 0;
    }
    StrVal = (char *)mmalloc(syml + 1);
    cdbcpystr(StrVal, sym, 0);
    if ( symbol == 2230 && nxtch() != '.' )
		isdef(StrVal);
	
	v13 = loadexp(0, 1);
    v6 = 0;
    if ( v13 )
    {
		gettf(v13, &TDno, &FLDtype);
        if ( FLDtype != 'C' )
        {
			loaderr(51, StrVal);				// "invalid file/pipe name"
            return 0;
		}
        mfree_0(StrVal);
        fcb = _files;
        FCBno = 0;
		while ( no_files > FCBno && fcb->field_0 );
		{
			FCBno++;
            fcb++;
		}
        
		if ( no_files == FCBno )
		{
			newfile();
            if ( no_files <= FCBno )
				__assert_fail("fpno < no_files", "leopen.c", 0x47u, "leopen");
			fcb = &_files[FCBno];
		}
        
		sft->field_4 = v13;

		switch (symb)
		{
		case 430:						// openapp
			fcb->field_0 = 0x0004u;
            sft->field_0 = 0x0014u;
			break;
		case 1120:						// popenio
			fcb->field_0 = 0x0003u;
            sft->field_0 = 0x0013u;
			break;
		case 530:						// openout
		case 1150:						// popenout
			fcb->field_0 = 0x0002u;
			sft->field_0 = 0x0012u;
			break;
		case 460:						// openin
		case 1110:						// popenin
			fcb->field_0 = 0x0001u;
            sft->field_0 = 0x0011u;
			break;
		}

		if ( a1 )
        {
			fcb->field_0 |= 0x0040u;
            sft->field_0 |= 0x0040u;
		}
		v14 = loadexp(0, 1);
        v6 = 0;
        if ( v14 )
        {
			gettf(v14, &TDno, &FLDtype);
            if ( FLDtype == 'C' )
            {
				sft->field_6 = v14;
                return v15;
			}
			loaderr(55, sym); // "file name / pipe command must be charac"..
			return 0;
		}
        return v6;
	}
    return v6;
}


#endif
