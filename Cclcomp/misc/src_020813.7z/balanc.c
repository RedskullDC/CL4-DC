#ifndef BALANCE_C
#define BALANCE_C

#include "DBdefs.h"
#include "cl4.h"

// *not* public in libcl4
void undo(DBinfo *DBptr)
{
	int *v1;
	int *v2;
	int SpareLen;

	printf("undo( DBptr: x%08X)\n", DBptr);

	v1 = DBptr->SpareList;
	v2 = DBptr->PageList3;
	SpareLen = length(DBptr->SpareList);
	if ( SpareLen + length(DBptr->PageList3) <= 32 )
	{
		for ( ; *v1; ++v1 )
			;
	}
	else
	{	
		_mkfree(DBptr, v1);
	}
	while (*v2)
	{
		*v1++ = *v2++;
	}
	*v1 = 0;
	_rmlock(DBptr, DBptr->PageList2);
	DBptr->PageList3[0] = 0;
	DBptr->PageList2[0] = 0;
}

// *not* public in libcl4
void putchange(DBinfo *DBptr)
{
	int *v1; // esi@1
	int *v2; // edi@1
	int v3; // ST08_4@1

	printf("putchange( DBptr: x%08X [ %s ])\n", DBptr, DBptr->DBname);

	v1 = DBptr->PageList1;
	v2 = DBptr->PageList2;
	v3 = length(DBptr->PageList1);
	if ( v3 + length(DBptr->PageList2) <= 15 )
	{
		for ( ; *v1; ++v1 )
			;
	}
	else
	{
		_rmlock(DBptr, v1);
		_mkfree(DBptr, v1);
	}
	while (*v2)
	{
		*v1++ = *v2++;
	}
	*v1 = 0;
	DBptr->PageList3[0] = 0;
	DBptr->PageList2[0] = 0;
}

// *not* public in libcl4
int length(int *PageList)
{
	int *i;

	for ( i = PageList; *i; ++i )
		;
	return i - PageList;
}

int _balance(TDinfo *TDptr, NODE *Node, int *PageList, short Depth)
{
	int v4;
	int v5;
	int *v6;
	int v7;
	NODE *Node2; 
	char **v9; 
	char **v10;
	short v12;
	char **a5;
	char **a5a;
	char **a5b;
	char *ptr;
	signed int v17;
	char* v18[11];	// 0 -> 7 are valid
	short N1_2idx;

	//printf("_balance( TDptr: x%08X, NODE: x%08X )\n", TDptr,Node);

	v17 = 1;

	ptr = ealloc(8 * TDptr->TDKeySize, 0);
	v5 = TDptr->TDKeySize;
	v4 = 0;
	do
	{
		v18[v4] = &ptr[v5 * v4];    // Array of 8 KeySizeBuffers
		v4++;
	}
	while ( v4 <= 7 );
  
	//-------

	a5 = v18;
	v6 = &PageList[Depth];
	while ( 1 )
	{
		if ( v6 == PageList )
		{
			if ( Depth > 5 )
				derror(15, 0, TDptr);
			putnode(TDptr, Node);
			v12 = Depth + 1;
			v7 = Node->PageNo;
			_whead(TDptr->TDDBinfo, TDptr->TDindexOff, v7, v12);
			goto LABEL_33;
		}
		--v6;
		if ( v6 == PageList && !Node->NumEntries && (!(TDptr->field_0 & 0x20) || Depth != 1) )
		{
			_addlist(TDptr->TDDBinfo->PageList2, Node->PageNo);
			v12 = Depth - 1;
			v7 = Node->NODE2ptr->PageNo;
			_whead(TDptr->TDDBinfo, TDptr->TDindexOff, v7, v12);
			goto LABEL_33;
		}
		if ( Node->DataEnd <= TDptr->TDDBinfo->DBpgsize && (v6 == PageList || TDptr->HalfPageSize <= Node->DataEnd) )
		{
			putnode(TDptr, Node);
			_lockpg(TDptr->TDDBinfo, Node->PageNo, 0);
			goto LABEL_33;
		}
		if ( v6 == PageList )
		{
			Node2 = freshnode(TDptr, 2);
			N1_2idx = 0;
			goto LABEL_25;
		}
		if ( !_lockpg(TDptr->TDDBinfo, *(v6 - 1), 2) )
			break;
		Node2 = getnode(TDptr, *(v6 - 1), 2);
		if ( _scanpg((void*)Node2, TDptr, &N1_2idx, 1) )
			++N1_2idx;
		if ( Node2->NODE2ptr[N1_2idx].PageNo != Node->PageNo )
			derror(19, 0, TDptr);
LABEL_25:
		v9 = v18;
		if (a5 != &v18[8])	// [8] is past end of the list
			v9 = a5;
		a5a = v9;
		if ( TDptr->Rec_plus_DB < Node->DataEnd || !_spread(TDptr, Node, Node2, N1_2idx, v9) )
		{
			a5b = a5a + 2;
			v10 = v18;
			if (a5b != &v18[8])	// [8] is past end of the list
				v10 = a5b;
			a5a = v10;
			if ( !_split(TDptr, Node, Node2, N1_2idx, v10) )
			{
				_lockpg(TDptr->TDDBinfo, *(v6 - 1), 0);
				Node = Node2;
				goto LABEL_33;
			}
		}
		a5 = a5a + 2;
		Node = Node2;
	}

// Done, if all ok, put changes to DB

	v17 = 0;
LABEL_33:
	nfree(ptr, 0);
	if ( v17 )
	{
		putchange(TDptr->TDDBinfo);
	}
	else
	{
		_lockpg(TDptr->TDDBinfo, Node->PageNo, 0);
		undo(TDptr->TDDBinfo);       // error somewhere, back out any changes
	}
	relnode(Node);
	return v17;
}


#endif

