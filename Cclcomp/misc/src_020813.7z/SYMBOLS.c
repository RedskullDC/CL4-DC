#ifndef SYMBOLS_C
#define SYMBOLS_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include <ctype.h>      // for islower() and toupper() functions
#include "DBdefs.h"
#include "cl4.h"
#include "reserved.h"

short loadsym(char *Symbol)
{
	ReservedWord *v1; // edi@2
    ReservedWord *Rsv; // esi@3
    short v3; // dx@3
    ReservedWord *v5; // [sp+8h] [bp-10h]@2

    if ( *Symbol )
    {
		v5 = reswords;
        v1 = &reswords[202];
        while ( v5 <= v1 )
		{
			Rsv = &v5[(((v1 - v5) >> 31) + v1 - v5) >> 1];// simple tree search to speed things up
			v3 = strcmp(Symbol, Rsv->Word);
            if ( v3 >= 0 )
            {
				if ( v3 <= 0 )
					return (short)Rsv->Rsv;
				v5 = Rsv + 1;
            }
            else
				v1 = Rsv - 1;
		}
	}
    return -1;
}

short loadresv(char *Symbol)
{
     ReservedWord *v1; // edi@2
     ReservedWord *Rsv; // esi@3
     short v3; // dx@3
     ReservedWord *v5; // [sp+8h] [bp-10h]@2

	if ( *Symbol )
    {
		v5 = rvwords;
        v1 = &rvwords[11];
        while ( v5 <= v1 )
        {
			Rsv = &v5[(((v1 - v5) >> 31) + v1 - v5) >> 1];
			v3 = strcmp(Symbol, Rsv->Word);
            if ( v3 >= 0 )
            {
				if ( v3 <= 0 )
					return (short)Rsv->Rsv;
				v5 = Rsv + 1;
			}
            else
				v1 = Rsv - 1;
		}
	}
    return 0;
}

short getsym(void)
{
     short result; // ax@8
     const char *v3; // edx@37
     long double v4; // fst6@54
     int NextChar; // [sp+14h] [bp-24h]@1
     char QuoteChar; // [sp+27h] [bp-11h]@60
     char *v10; // [sp+28h] [bp-10h]@7

     inLit = 0;
     NextChar = c;
	//printf("getsym : 316 NextChar = %c\n",NextChar);

     if ( !symbol )
     {
          fwrite("unexpected end of file\n", 1u, 0x17u, stderr);
          fflush(stderr);
          exit(1);
     }
     if ( symbol == 930 )                       // NewLine
     {
          ++ll;
          ++lla;
          if ( codeb )
          {
               fprintf(stderr, "\r%d", (unsigned short)ll);	// last line
               fflush(stderr);
          }
     }
     v10 = sym;

     if ( !NextChar )
     {
          NextChar = getnch();
          if ( NextChar == -1 )
               return 0;
     }
	
	// ignore white space and comment lines till next alpha character

	//while ((*v7)[NextChar] & 0x2000 && NextChar != '\n' || NextChar == '#' && !esc_char )
	while (isspace(NextChar) && NextChar != '\n' || NextChar == '#' && !esc_char )
    {
		if ( NextChar == '#' )	// we found a comment line/ ignore everything till after next <CR>
        {
            while ( NextChar != '\n' )
            {
				NextChar = _IO_getc(MainFile);
                if ( NextChar == -1 )
				{
	                c = -1;
			        return -1;
				}
                if ( NextChar == '\\' )      // Line continue character. Bump line counters
                {
					NextChar = _IO_getc(MainFile);
                    if ( NextChar == '\n' )
                    {
						++ll;
                        ++lla;
                        NextChar = _IO_getc(MainFile);
                    }
				}
                if ( NextChar == -1 )
				{
					c = -1;
				    return -1;
				}
			}
 		}
        else
        {
			NextChar = getnch();
            if ( NextChar == -1 )
				return 0;
        }
	}
//--------------------
	//if ((*v7)[NextChar] & 0x0400 || NextChar == '_' )
	if (isalpha(NextChar) || NextChar == '_' )
    {
		while ( 1 )
        {
			*v10++ = NextChar;	// copy source buffer into sym[]
            NextChar = getnch();
            if ( NextChar == -1 )
				return 0;

               //v2 = (*v7)[NextChar];
               //if ( !(v2 & 0x0400) && !(v2 & 0x0800) && NextChar != '_' )
			if ( !(isalpha(NextChar)) && !(isdigit(NextChar)) && NextChar != '_' )
            {
				*v10 = 0;	// terminate the sym string
                if ( NextChar == ':' )      // Program LABEL:
                {
					*v10++ = ':';
                    *v10 = 0;
                    symbol = 720;			// we found a program label  "LABEL:"
                    syml = strlen(sym);
                    NextChar = getnch();
                    if ( NextChar == -1 )
						return 0;
                    c = NextChar;
                    return symbol;
				}
                symbol = loadsym(sym);
                if ( symbol < 0 )           // not in reserved words. 2230 = variable/table name
					symbol = 2230;
				syml = strlen(sym);
                c = NextChar;
				return symbol;
			}
		}
	}
//--------------
	// look for a numeric value, may start with a '-'
	if (isdigit(NextChar) || NextChar == '-' )
    {

		symbol = 0;
        while ( 1 )
        {
			if ( NextChar != '.' )
				goto LABEL_43;
			while ( 1 )
            {
				symbol = 2210; // floating point literal	eg:	456.4323
LABEL_43:
                *v10++ = NextChar;
                NextChar = getnch();
                if ( NextChar == -1 )	// EOF
					return 0;
				
				if (isdigit(NextChar))
					break;

				if ( NextChar != '.' )
                {
					// we hit a character which wasn't a number or decimal place
					*v10 = 0;
                    if ( symbol ) //true if already set to 2210
					{
						syml = strlen(sym);
						c = NextChar;
						return symbol;
					}
					if ( sym[0] != '-' || sym[1] ) // can only be true if a digit immediately followed a '-'
                    {
						if ( strlen(sym) <= 9 || (v4 = __strtod_internal(sym, 0, 0), v4 <= 2147483647.0) && v4 >= -2147483647.0 )
							symbol = 2200;		// Integer literal, and within range limits
						else
							symbol = 2210;		// floating point literal
					}
					// at this point we have a '-' 
                    else if ( NextChar == '=' )
                    {
						*v10++ = '=';
                        *v10 = 0;
                        NextChar = getnch();
                        if ( NextChar == -1 )
							return 0;
						symbol = 1560;		// "-="
    				}
					else
						symbol = 1580;		// "-"
LABEL_128:
                    syml = strlen(sym);
                    c = NextChar;
                    return symbol;
				}
			}
		}
	}
//---------
	if ( NextChar == '\'' || NextChar == '"' )		// looking for a string literal here
	{
		inLit = 1;
		QuoteChar = NextChar;	// Save the quote char we found to look for a match
		NextChar = getnch();
		if ( NextChar == -1 )
			return 0;

		while ( NextChar != QuoteChar || esc_char )
		{
			if ( NextChar == '\n' && !esc_char )	// this allows a <CR> to end a string without a matching quote
				break;
			*v10++ = NextChar;
			NextChar = getnch();
			if ( NextChar == -1 )
				return 0;
		}
		if ( NextChar != QuoteChar || (NextChar = getnch(), result = 0, NextChar != -1) )
		{
			*v10 = 0;
			symbol = 2220;				// string literal
            syml = strlen(sym);
            c = NextChar;
            return symbol;
		}
		return result;
	}
	else	// everything else!
	{
		v10 = sym;
		switch (NextChar)
		{
		case '*':
			*v10++ = '*';
            NextChar = getnch();
            if ( NextChar == -1 )
				return 0;
			if ( NextChar == '*' )
            {
				*v10++ = '*';
                symbol = 1170;              // "**"
                NextChar = getnch();
                if ( NextChar == -1 )
					return 0;
				if ( NextChar == '=' )
				{
					*v10++ = '=';
                    symbol = 1160;         // "**="
                    break;	//goto LABEL_85;
				}
                *v10 = 0;
                syml = strlen(sym);
                c = NextChar;
                return symbol;
			}
            if ( NextChar != '=' )
            {
				symbol = 890;               // "*"
                *v10 = 0;
                syml = strlen(sym);
                c = NextChar;
                return symbol;
			}
            *v10++ = '=';
            symbol = 880;                    // "*="
			break;	//goto LABEL_85;

		case '<':
			*v10++ = '<';
            NextChar = getnch();
            if ( NextChar == -1 )
				return 0;
			if ( (unsigned int)(NextChar - 61) > 1 )
				symbol = 1840;    // "<"
			else
            {
				*v10++ = NextChar;
                symbol = 1830;        // "<=", "le"
				if ( NextChar != '=' )
					symbol = 1850;   // "<>", "ne"
                NextChar = getnch();
                if ( NextChar == -1 )
					return 0;
			}
            *v10 = 0;
            syml = strlen(sym);
            c = NextChar;
            return symbol;
			break;

		case '&':
			*v10++ = '&';
            NextChar = getnch();
            if ( NextChar == -1 || NextChar == '&' && (*v10++ = '&', NextChar = getnch(), NextChar == -1) )
				return 0;
			*v10 = 0;
            symbol = 80;      // "&" , "&&", "and"
			syml = strlen(sym);
			c = NextChar;
			return symbol;
			break;

		case ('|'):
			*v10++ = '|';
            NextChar = getnch();
            if ( NextChar == -1 || NextChar == ('|') && (*v10++ = '|', NextChar = getnch(), NextChar == -1) )
				return 0;
			*v10 = 0;
            symbol = 1040;    // "|", "||", "or"		"or" is caught in first block by loadsim
			syml = strlen(sym);
			c = NextChar;
			return symbol;
			break;

		case '+':
			*v10++ = '+';
            NextChar = getnch();
            if ( NextChar == -1 )
				return 0;
			if ( NextChar == '=' )
            {
				*v10++ = '=';
                NextChar = getnch();
                if ( NextChar == -1 )
					return 0;
				symbol = 40; // "+="
			}
            else
				symbol = 50; // "+"
			*v10 = 0;
            syml = strlen(sym);
            c = NextChar;
            return symbol;
			break;

		case '/':
			*v10++ = '/';
            NextChar = getnch();
            if ( NextChar == -1 )
				return 0;
			if ( NextChar == '=' )
            {
				*v10++ = '=';
                NextChar = getnch();
				if ( NextChar == -1 )
					return 0;
				symbol = 320;	// "/="
			}
            else
				symbol = 330;	// "/"
			*v10 = 0;
            syml = strlen(sym);
            c = NextChar;
            return symbol;
			break;
		
		case '%':
			*v10++ = '%';
            NextChar = getnch();
            if ( NextChar == -1 )
				return 0;
            if ( NextChar == '=' )
            {
				*v10++ = '=';
                NextChar = getnch();
                if ( NextChar == -1 )
					return 0;
				symbol = 850;// %="
			}
            else
                symbol = 860;// "%"
			*v10 = 0;
            syml = strlen(sym);
            c = NextChar;
            return symbol;
			break;

		case '>':
			*v10++ = '>';
            NextChar = getnch();
            if ( NextChar == -1 )
				return 0;
			if ( NextChar != '=' )
            {
				symbol = 1820;              // ">", "gt"
                *v10 = 0;
                syml = strlen(sym);
                c = NextChar;
                return symbol;
			}
            *v10++ = '=';
            symbol = 1810;                   // ">=", "ge"
			break;	//goto LABEL_85;

		default:							// default handler
			//printf("getsym : 628 NextChar = x%02X %c\n",NextChar, NextChar);
            *v10++ = NextChar;
            *v10 = 0;
            symbol = loadsym(sym);			// examine list of pre-defined symbols
			//printf("getsym : 632 symbol = %d\n",symbol);
            NextChar = getnch();
            if ( NextChar == -1 )
				return 0;
			syml = strlen(sym);
			c = NextChar;
			return symbol;
			break;
		}

// general exit routine
LABEL_85:
		NextChar = getnch();
        if ( NextChar == -1 )
			return 0;
		*v10 = 0;
        syml = strlen(sym);
		//DumpBlock(sym,syml + 1);
        c = NextChar;
        return symbol;
	}
}
#endif
