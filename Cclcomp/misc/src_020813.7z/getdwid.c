#ifndef GETDWID_C
#define GETDWID_C

#include "DBdefs.h"
#include "cl4.h"

int getdwid(FLDdesc *FLDptr)
{
	Qlen *QLptr; // eax@2
	signed int result; // eax@3

	//printf("getdwid(FLDptr = %08X)\n" ,FLDptr);

	if ( FLDptr->FLDqlen && (QLptr = FLDptr->FLDqlen, QLptr->Qdeflen) )
	{
		result = QLptr->Qdeflen;
	}
	else
	{
		switch ( FLDptr->FLDtype )
		{
		case 'C':
			result = FLDptr->FLDlen;	// strings are naturally variable
			break;
		case 'B':						// byte
			result = 4;
			break;
		case 'I':						// short int
			result = 6;
			break;
		case 'N':						// normal int
			result = 9;
			break;
		case 'D':						// date
			result = defDateWidth;
			break;
		case 'T':						// time
			result = 5;	// 'hh:mm'
			break;
		case 'G':						// float/double
		case 'R':
			result = 10;
			break;
		case 'K':						// Sub/Key records are not displayable!!!
		case 'S':
			result = 0;
			break;
		default:						// everything else
			result = 14;
			break;
		}
	}
	return result;
}
#endif
