#ifndef TUPTOREC_C
#define TUPTOREC_C

#include "DBdefs.h"
#include "cl4.h"

void tuptor(char *dest,POS *Pos, char *src,TDef *TDefptr)
{
	short v4;
	TDef *v5;
	char *i; 
	short v7;
	short v8;
	char* dump;

	dump = dest;
	v5 = TDefptr;
	for ( i = src; v5->TDFentry; ++v5 )
	{
		if ( Pos )	// POS tables allow fields to be re-positioned in target data area.
		{
			v8 = cdbrindex(Pos, v5->TDFentry);
			if ( v8 >= 0 )		// Possible to not have a POS record for each field!
			{
				v4 = domtox(&dest[v8], i, v5->TDFsize, v5->TDFtype);
			}
			else	// We don't want this field! Bump to next one
			{
				if ( v5->TDFtype & 2 ) // string variable
					v4 = _fwidth(i, v5->TDFsize, v5->TDFtype);
				else
					v4 = v5->TDFsize;
			}
			i += v4;
		}
		else	// No Pos record, just save record to Memory in same order as on disk
		{
			if ( v5->TDFtype & 2 ) // string variable
				v7 = _fwidth(i, v5->TDFsize, v5->TDFtype);
			else
				v7 = v5->TDFsize;
			i += cpybuf(dest, i, v7);
			dest += v5->TDFsize;
		}
	}
}

short rtotup(char *dest, char *src, POS *Pos, TDef *TDefptr)
{
	TDef *v4;
	char *i;
	short v6;
	short v7;
	int v8;

	v4 = TDefptr;
	for ( i = dest; v4->TDFentry; ++v4 )
	{
		if ( Pos )
		{
			v7 = cdbrindex(Pos, v4->TDFentry);
			if ( v7 >= 0 )
				v8 = xtodom(i, v4->TDFsize, v4->TDFtype, &src[v7]);
			else
				v8 = cdbfclear(i, v4->TDFsize, v4->TDFtype);
			i += v8;
		}
		else
		{
			if ( v4->TDFtype & 2 )
				v6 = _fwidth(src, v4->TDFsize, v4->TDFtype);
			else
				v6 = v4->TDFsize;
			i += cpybuf(i, src, v6);
			src += v4->TDFsize;
		}
	}
	return (short) (i - dest);
}

#endif
