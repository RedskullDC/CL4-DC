#ifndef LTOMS_C
#define LTOMS_C

int* ltoms(int* a1, int a2)
{
	*a1 = M_INT(a2);
	//printf("ltoms(a2 = x%08X) returns x%08X\n",a2,*(int*)a1);
	return a1;
}                  // Long to Micro$oft conversion

#endif
