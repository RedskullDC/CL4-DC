#ifndef CHECKOELIST_C
#define CHECKOELIST_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

void chkoelist(ONESC *a1)
{
     ONESC *i; // edi@1
     BTAB *bt; // esi@2
     short v3; // si@4
     short v4; // ax@4
     PTAB *ptab; // eax@4
     XTAB *xtab; // edx@7
     short v7; // ax@8
     size_t MaxLen; // [sp+14h] [bp-14h]@2
     short CurrBTno; // [sp+18h] [bp-10h]@2

     for ( i = a1; i; i = i->NextESC )
     {
          MaxLen = (signed short)(lenstr(i->BlockName) + 1);
          bt = btab;
          CurrBTno = 0;
          if ( no_btabs > 0 )
          {
               while ( !cmpbuf(i->BlockName, bt->BlockName, MaxLen) )
               {
                    ++CurrBTno;
                    ++bt;
                    if ( no_btabs <= CurrBTno )
                         goto LABEL_12;
               }
               v3 = bt->StartLine;
               v4 = getptabp(v3);
               ptab = PTARR(v4);
               if ( ptab->OpCode != 950 )
               {
                    while ( 1 )
                    {
                         if ( ptab->OpCode == 1 )
                         {
                              if ( ptab->TABno )
                              {
                                   xtab = (XTAB *)&xtarr.TableAddr[52 * ptab->TABno];
                                   if ( xtab[-1].Flags & 8 )
                                        break;
                              }
                         }
                         ++v3;
                         v7 = getptabp(v3);
                         ptab = PTARR(v7);
                         if ( ptab->OpCode == 950 )
                              goto LABEL_9;
                    }
                    xtab[-1].Flags &= 0xFFF7u;
               }
LABEL_9:
               i->BlockNo = CurrBTno;
          }
LABEL_12:
          if ( no_btabs == CurrBTno )
               loaderr(74, i->BlockName);
     }
}
#endif
