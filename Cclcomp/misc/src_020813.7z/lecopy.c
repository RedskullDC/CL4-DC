#ifndef LECOPY_C
#define LECOPY_C

short lecopy(void)
{
	int v0; // eax@3
    int TTno; // eax@6
    signed int v4; // eax@11
    short a1; // [sp+14h] [bp-14h]@6
    XFTAB *xft; // [sp+18h] [bp-10h]@6

	symbol = getsym();
    if ( symbol != 2230 )		// expect string literal (destination table alias)
    {
		if ( symbol == 930 )
			loaderr(40, sym);	// "missing table/alias"
		else
			loaderr(39, sym);	// "invalid table/alias"
		return 0;
    }
	a1 = getxfmem();
    allxfpt(a1, &xft);
    
	// get destination table
	TTno = findtd(sym, -1);	// look for the table/alias
    xft->TTno_to = TTno;
    if ( TTno < 0 )
	{
		loaderr(14, sym);	// "table not open"
        dallxfpt(&xft);
        return 0;
	}
    symbol = getsym();
    if ( symbol != 550 )                       // from
    {
		loaderr(38, sym); // "expected 'from'"
        dallxfpt(&xft);
        return 0;
    }

    symbol = getsym();
    if ( symbol != 2230 )                      // expecting a string literal to follow (source table/alias)
    {
		if ( symbol == 930 )
			loaderr(40, sym);	// "missing table/alias"
        else
			loaderr(39, sym);	// "invalid table/alias"
		dallxfpt(&xft);
        return 0;
    }
	// all ok, look for source table
    TTno = findtd(sym, -1);
    xft->TTno_from = TTno;
    if ( TTno < 0 )
    {
        loaderr(14, sym);	// "table not open"
        dallxfpt(&xft);
        return 0;
    }
    dallxfpt(&xft);
    symbol = getsym();
    return a1;	// exit_success
}


#endif
