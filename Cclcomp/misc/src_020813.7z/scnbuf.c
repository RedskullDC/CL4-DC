#ifndef SCANBUFF_C
#define SCANBUFF_C

#include "DBdefs.h"
#include "cl4.h"

short scnbuf(char *a1, short TDfsize, char Value)
{
	int v3;
	char *i;

	v3 = TDfsize;
	for ( i = a1; v3; --v3 )
	{
		if ( *i == Value )
			break;
		++i;
	}
	return (short)(i - a1);
}

#endif
