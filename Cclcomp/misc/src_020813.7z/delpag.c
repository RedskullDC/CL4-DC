#ifndef DELPAGE_C
#define DELPAGE_C

#include "DBdefs.h"
#include "cl4.h"

int delpage(NODE *Node, short N1_2idx)
{
	NODE_1 *N1p; // edx@1
	NODE_1 *v3; // esi@1
	NODE_1 *v4; // edi@1
	NODE_2 *N2p; // edx@1
	int v7; // [sp+0h] [bp-Ch]@1

	//delpage() can either delete regular data or Page Index data.

	//printf("delpage(NODE: x%08X,N1_2idx: %d)\n" ,Node,N1_2idx);

	N1p = Node->NODE1ptr;
	v3 = &N1p[N1_2idx];
	v7 = Node->field_16 + v3->Size;
	v4 = &N1p[Node->NumEntries];
	for ( N2p = &Node->NODE2ptr[N1_2idx + 1]; v3 < v4; N2p++ )
	{
		v3->Data	= v3[1].Data;
		v3->Size	= v3[1].Size;
		N2p->PageNo = N2p[1].PageNo;
		v3++;
	}
	Node->DataEnd -= v7;
	--Node->NumEntries;
	return v7;
}

#endif
