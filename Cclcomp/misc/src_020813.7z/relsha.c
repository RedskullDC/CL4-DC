#ifndef RELSHARE_C
#define RELSHARE_C

#include "DBdefs.h"
#include "cl4.h"
//#define _LARGEFILE64_SOURCE

void _relshare(DBinfo *DBptr)
{
	;	// Do Nothing on linux
}

#endif
