#ifndef CLOSEDB_C
#define CLOSEDB_C

void closedb(int a1)
{
	int v1; // edi@1
    TDesc *TTptr; // esi@4
    short v3; // di@12
    DBase *v4; // esi@12
    int ErrorNo; // edx@15

    v1 = 0;
    if ( no_ttabs )
    {
		if ( !a1 )
			ulockall();
		for ( TTptr = &ttab[no_ttabs - 1]; TTptr >= ttab; --TTptr )
        {
			if ( TTptr->TDrecsize && TTptr->TableAlias[0] != '>' )
            {
				if ( TTptr->TTrtd != -1 )
                {
					v1 = rtdget(TTptr);
                    release(v1);
				}
                TTptr->TableName[0] = 0;
                if ( v1 == no_ttabs - 1 )
					--no_ttabs;
			}
		}
        v3 = 0;
        v4 = dtab;
        while ( no_dtabs > v3 )
        {
			if ( v4->FullDBname && v4->DBno >= 0 )
			{
				ErrorNo = cldbclose(v4->DBno);
                if ( ErrorNo != v4->DBno )
					dberror(ErrorNo, v4->DBno, -1);
				v4->FullDBname = (char *)mfree_0(v4->FullDBname);
			}
            ++v4;
            ++v3;
		}
	}
}
#endif
