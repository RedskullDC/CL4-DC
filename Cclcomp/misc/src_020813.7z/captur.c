#ifndef CAPTURE2_C
#define CAPTURE2_C

#include "DBdefs.h"
#include "cl4.h"
//#define _LARGEFILE64_SOURCE

// not public in libcl4
int findspace(unsigned char *Buffer, short a2, int *PageList, short a4, int a5)
{
	unsigned char*	v5;
	unsigned char* v10; 
	int v6;
	signed int v7;
	short v9; 
	int *v11; 

	v9 = a4;
	v5 = Buffer;

	v11 = PageList;
	v10 = &Buffer[a2];
	while ( v5 < v10 && v9 > 0 )
	{
		if ( *v5 != 0xFF )	// all bits allocated = 0xFF
		{
			v6 = a5;
			v7 = 0x80u;		// bit mask to test  1000 0000    >> 
			while ( v7 && v9 > 0 )
			{
				if ( !(v7 & *v5) )
				{
					*v11 = v6 + 8 * (v5 - Buffer);	// 1 bit per page
					*v5 |= v7;	// mark page as "in use"
					++v11;
					--v9;
				}
				++v6;
				v7 >>= 1;
			}
		}
		++v5;
	}
	return (v11 - PageList);	// Pages found, (may not match number requested!)
}

// not public in libcl4
int getspare(DBinfo *DBptr)
{
	unsigned int v1;
	short v3;
	int v4;
	short v5;
	int v6;
	off64_t v8;
	int *PageList;
	int i;
	int v11;
	short v12;
	short ErrorCode;
	short v14;
	char v15[2072];

	ErrorCode = 0;
	v14 = (1 << (8 - (DBptr->DBmaxpages & 7))) - 1;
	v1 = (DBptr->DBmaxpages + 7) >> 3;
	if ( !_lockmap(DBptr, 1) )
		derror(18, DBptr, 0);
	PageList = DBptr->SpareList;
	v8 = DBptr->DBfreeaddress;
	if ( DBptr->DBversion == 1767 )
		v8 *= DBptr->DBpgsize;
	v6 = lseek64(DBptr->DBfilehandle, v8, 0);
	if ( v6 < 0 )
	{
		_lockmap(DBptr, 0);
		derror(24, DBptr, 0);
	}
	v3 = _nspare;	// default _nspare value is 20
	if ( _nspare > 32 )
		v3 = 32;
	v12 = v3;
	for ( i = 0; v1 && v12 > 0; v1 -= v4 )
	{
		v4 = 2048;
		if ( v1 < 2049 )
			v4 = v1;
		if ( readfull(DBptr->DBfilehandle, v15, v4) != v4 )
		{
			_lockmap(DBptr, 0);
			derror(24, DBptr, 0);
		}
		if ( v1 == v4 )
			v15[v1 - 1] |= v14;
		v5 = findspace(v15, v4, PageList, v12, i);
		v11 = v5;
		if ( v5 > 0 )
		{
			if ( v1 == v4 )
				v15[v1 - 1] &= ~v14;
			v6 = lseek64(DBptr->DBfilehandle, -v4, 1);
			if ( v6 < 0 || write(DBptr->DBfilehandle, v15, v4) != v4 )
			{
				_lockmap(DBptr, 0);
				derror(31, DBptr, 0);
			}
			PageList += v11;
			v12 -= v11;
		}
		i += 8 * v4;
	}

	_lockmap(DBptr, 0);
	if ( ErrorCode )
		derror(ErrorCode, DBptr, 0);
	return (PageList - DBptr->SpareList); // Number of pages allocated
}

int _capture(DBinfo *DBptr)
{
	int *SpareList; // esi@1
	int PageNo; // edx@3

	//printf("_capture(DBptr: x%08X)\n" ,DBptr);

	SpareList = DBptr->SpareList;
	if ( !DBptr->SpareList[0] )
		SpareList[getspare(DBptr)] = 0;
	for ( PageNo = *SpareList; *SpareList; *(SpareList - 1) = *SpareList )
		++SpareList;
	return PageNo;
}


#endif
