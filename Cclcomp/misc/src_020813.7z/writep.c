#ifndef WRITEPAGE_C
#define WRITEPAGE_C

#include "DBdefs.h"

bool _writepg(DBinfo *DBptr, char *Buffer, unsigned int PageNo)
{
	int v3;
	bool v7;

	//printf("_writepg(DBptr: x%08X,Buffer: x%08X,PageNo x%04X (%4d)\n" ,DBptr,Buffer,PageNo,PageNo);

	v7 = false;
	v3 = lseek64(DBptr->DBfilehandle, PageNo * DBptr->DBpgsize, 0);
	if ( v3 >= 0 )
	{
		v3 = write(DBptr->DBfilehandle, Buffer, DBptr->DBpgsize) == DBptr->DBpgsize;
		if ( v3 )
			v7 = true;
	}
	if ( !v7 )
		printf("_writepg: num=[%d]\n", PageNo);
	return v7;
}
#endif
