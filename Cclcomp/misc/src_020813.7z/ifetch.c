#ifndef INDEX_FETCH_C
#define INDEX_FETCH_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

short _ifetch(char *Dest, DPOS *dpos, TDinfo *TDptr)
{
	NODE *Node; // edx@2	
	PAGE *v4; // esi@6
	NODE *v5; // esi@12
	short v6; // ax@12
	NODE_1 *node1; // eax@12
	short v9; // [sp+18h] [bp-10h]@9

printf("_ifetch(Dest : x%08X, DPOS : x%08X, TDptr :x%08X)\n",Dest,dpos,TDptr);

	if ( TDptr->TDNodePtr )
	{
		Node = TDptr->TDNodePtr;
		if ( Node->PageNo != dpos->PageNo )
		{
			relnode(Node);
			TDptr->TDNodePtr = 0;
		}
	}
	if ( dpos->PageNo )
		goto LABEL_17;

	if ( dpos->field_8 )
	{
		++fcount;	// fetch count? Only ever accessed from here.
		v4 = _indexpg(TDptr, dpos->field_8);
		dpos->PageNo = mstol(&v4->DataStart[4 * dpos->NumEntries++]);
		if ( v4->NumEntries < dpos->NumEntries )
		{
			dpos->field_8 = mstol(&v4->field_16);
			dpos->NumEntries = 0;
		}
	}
//-----------------------------------  
	if ( dpos->PageNo )
	{
LABEL_17:
		if ( !TDptr->TDNodePtr )
			TDptr->TDNodePtr = getnode(TDptr, dpos->PageNo, 0);
		v5 = TDptr->TDNodePtr;
		v6 = dpos->field_4;
		dpos->field_4 = v6 + 1;
		node1 = &v5->NODE1ptr[v6];
		v9 = cpybuf(Dest, node1->Data, node1->Size);
		if ( v5->NumEntries <= dpos->field_4 )
		{
			relnode(TDptr->TDNodePtr);
			TDptr->TDNodePtr = 0;
			dpos->PageNo = 0;
			dpos->field_4 = 0;
		}
	}
	else
	{
		v9 = 0;
	}
	return v9;
}

#endif
