#ifndef LEBLOCK_C
#define LEBLOCK_C

void leblock(int *LineNo)
{
    BTAB *bt; // [sp+18h] [bp-60h]@2
    PTAB *ptab; // [sp+1Ch] [bp-5Ch]@44
    ONESC *v4; // esi@22

	short v1; // esi@2
    int ErrorCode; // esi@26
    short v18; // ax@53
    size_t BlkNameLen; // [sp+14h] [bp-64h]@2
    char BlockName[32]; // [21] would do

    symbol = getsym();
	printf("leblock : 31 symbol = %d\n",symbol);
    if ( symbol != 2230 )                      // string literal
    {
		loaderr(2, sym);                      // "missing block name"
        goto LABEL_24;	// but continue processing anyway??!?
    }
    BlkNameLen = fixbname(BlockName, sym);
    bt = btab;
    v1 = 0;
    while ( btab->BlockName[0] && no_btabs > v1 )
    {
		if ( cmpbuf(bt->BlockName, BlockName, BlkNameLen) )	// look for an already defined block with same name
			break;
		bt++;
		v1++;
    }
    cur_block = v1;
	if ( no_btabs == v1 )	// good, we didn't find a match on our blockname
    {
		newbtab();
		bt = &btab[v1];
        if ( no_btabs <= (signed short)v1 )
			__assert_fail("i < no_btabs", "leblock.c", 0x2Cu, "leblock");
    }
    if ( !bt->BlockName[0] )
		cdbcpystr(bt->BlockName, BlockName, 0);
    if ( bt->StartLine || bt->EndLine )
		loaderr(81, sym);                     // "duplicate block name"
    else
		bt->StartLine = *(short *)LineNo;
	symbol = getsym();

	if ( symbol == 1010 )                      // look for on_exit handler
    {
		printf("leblock : 51 symbol = %d\n",symbol);
		symbol = getsym();
		if ( symbol == 2230 )                    // string literal == {on_exit : block_name}
		{
			v4 = (ONESC *)getmem(16);
		    v4->BlockName = getmem(fixbname(BlockName, sym));
		    cdbcpystr(v4->BlockName, BlockName, 0);
		    bt->On_exit = v4;
		    symbol = getsym();
		}
		else
		{
			if ( symbol == 930 )			// newline = ERROR. was expecting a blockname to follow the "{"
				loaderr(2, sym);            // "missing block name"
			else
				loaderr(33, sym);           // "unexpected symbol"
			return;
		}
	}
//-------------------
	while ( 1 )
    {
LABEL_24:
		while ( symbol == 930 )				// "\n"  end of line
			symbol = getsym();

		ErrorCode = 0;
		switch (symbol)
		{
		case 570:								// getfile
			if ( !legetf())
				ErrorCode = 1;
			break;

		case 750:								// ldefine = 750, define == 290
		case 290:
			printf("leblock : 118, calling ledefine() symbol = %d\n",symbol);
			if ( !ledefine(symbol == 750) )		// symbol == 750 if local define
				ErrorCode = 1;
			break;

		case 830:								// maintain
			if ( !lemaint(&btab[cur_block]))
				ErrorCode = 1;
			break;

		case 630:								// 630 = "head"
			symbol = getsym();
		    allptpt(getptabp((*LineNo)++), &ptab);
		    ptab->OpCode = 3;
			ptab->SrcLineNo = lla;
			v18 = lehdtxt();
			if ( !v18 )
				ErrorCode = 1;
			ptab->TABno = v18;
			dallptpt(&ptab);
			break;
			
		case 510:									// format
			if ( !leformat((short *)LineNo, 0))
				ErrorCode = 1;
			break;

		case 120:									// "break"
			allptpt(getptabp((*LineNo)++), &ptab);
	        ptab->OpCode = 950;
	        ptab->SrcLineNo = lla;
	        dallptpt(&ptab);
	        symbol = getsym();
	        if ( symbol != 930 )
			{
				loaderr(33, sym);		// "unexpected symbol" - should be no arguments after break on the line
				ErrorCode = 1;
			}
			break;

		case 1360:											// "}"  end of block terminator
			btab[cur_block++].EndLine = *(short*)LineNo;

			allptpt(getptabp((*LineNo)++), &ptab);
            ptab->OpCode = 950;	// "break"
            dallptpt(&ptab);

			allptpt(getptabp((*LineNo)++), &ptab);
            ptab->OpCode = 999;	// "end"
            ptab->SrcLineNo = lla;
            dallptpt(&ptab);
            return;						// exit_success
			break;
			
		case 0:												// no symbol!!  Error condition
			loaderr(6, sym);	// "unexpected end of file"
			return;
			break;

		default:
			printf("leblock : 147, calling loadstate()\n"); 
            if ( !loadstate(LineNo) )
				ErrorCode = 1;
			break;
		}
		if ( comp_abort )
			return;			// error_exit
		
		if ( ErrorCode )	// We found an error condition. Keep reading till we hit NewLine or EOF
        {
			while ( symbol && symbol != 930 )
				symbol = getsym();
		}
	}
}

#endif
