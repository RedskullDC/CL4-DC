#ifndef TABLEGLOBAL_C
#define TABLEGLOBAL_C

#include "DBdefs.h"
#include "cl4.h"

// _tbl[3005] is not public in libcl4!

short nr2td(TDinfo *TDptr)
{
	short TDno; // eax@1

	TDno = 0;
	while ( _tbl[TDno] != TDptr )
	{
		TDno++;
		if ( TDno > 3003 )
			return -1;
	}
	return TDno;
}

int _shuttd(DBinfo *DBptr)
{
	short TDno; // esi@1
	int result; // eax@5

	TDno = 3;
	do
	{
		if ( _tbl[TDno] )
		{
			if ( _tbl[TDno]->TDDBinfo == DBptr )
				release(TDno);
		}
		result = TDno + 1;
		TDno++;
	}
	while ( TDno <= 3003 );
	return result;
}

TDinfo* _rmtd(int TDno)
{
	TDinfo *v1; // ecx@1

	v1 = 0;
	if ( (unsigned int)(TDno - 3) <= 3000 )
	{
		v1 = _tbl[TDno];
		_tbl[TDno] = 0;
	}
	return v1;
}

signed int _nxttd(TDinfo *TDptr)
{
	short TDno; // edx@1

	TDno = 3;
	do
	{
		if ( !_tbl[TDno] )
		{
			_tbl[TDno] = TDptr;
			return TDno;
		}
		TDno++;
	}
	while ( TDno <= 3003 );
	return -1;
}

TDef* tblrow(unsigned int TDno)
{
	TDinfo *TDptr; // eax@2
	TDef *result; // eax@3

	if ( TDno <= 3003 && ((TDptr = _tbl[TDno]) != 0) )
		return TDptr->TableDefs;
	else
		return 0;
}

TDinfo* _chktd(unsigned int TDno)
{
	//printf("_chktd(%3d)\n", TDno);
	if ( TDno > 3003 || !_tbl[TDno] )
		derror(35, 0, 0);
	return _tbl[TDno];
}


#endif
