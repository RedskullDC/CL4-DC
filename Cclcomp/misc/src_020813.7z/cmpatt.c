#ifndef CMPATTRIBUTE_C
#define CMPATTRIBUTE_C

#include "DBdefs.h"
#include "cl4.h"

short _cmpattrib(char *src, short TDFsize, char *Buffer, short TDFsize2, short TDFtype)
{
	char *v5; // eax@2
	short v6; // eax@2
	short v7; // ax@11
	unsigned int v8; // esi@11
	unsigned char v9; // esi@17
	unsigned char v10; // ecx@17
	unsigned char v11; // eax@19
	char v12; // edx@21
	short v13; // esi@30
	short v14; // ax@30
	signed int v16; // [sp+14h] [bp-424h]@1
	bool v17; // [sp+18h] [bp-420h]@1
	short v18; // [sp+1Ch] [bp-41Ch]@8
	char dest[1048]; // [sp+20h] [bp-418h]@12

	//printf("_cmpattrib(src = x%08X, TDFsize = %d, Buffer = x%08X, TDFsize2 = %d, TDFtype = x%04X)\n",src,TDFsize,Buffer,TDFsize2,TDFtype );

	v16 = 0;
	v17 = 0;
	if ( TDFtype & 0x4000 )
	{
		v5 = src;			// swap src<->dest values 
		src = Buffer;
		Buffer = v5;
		v6 = TDFsize;
		TDFsize = TDFsize2;
		TDFsize2 = v6;
	}

	if ( TDFtype & 4 && TDFsize && TDFsize2 && (*Buffer ^ *src) < 0 )
	{
		if ( *src >= 0 )
			v18 = 1;
		else
			v18 = -1;
		//printf("_cmpattrib: v18 = %d\n",v18);
	}
	else
	{
		if ( TDFtype & 2 && (v7 = getwpos(Buffer, TDFsize2), v8 = v7, v7 >= 0) )
		{
			strncpy(dest, src, TDFsize);
			dest[TDFsize] = 0;
			if ( TDFsize2 <= v8 )
				v8 = TDFsize2;
			TDFsize2 = v8;
			v16 = 1;
			v18 = owildmat(dest, Buffer, TDFtype);
		}
		else
		{
			v18 = 0;
			while ( TDFsize && TDFsize2 )
			{
				v9 = *src;
				v10 = *Buffer;
				v18 = (v9 - v10);
				//printf("cmpattr_1: TDF1 %d , TDF2 %d, v9 = %d, v10 = %d, v18 = %d\n",TDFsize,TDFsize2,v9,v10,v18);
				if ( v9 != v10 )
				{
					if ( !(TDFtype & 8) )
						break;
					v11 = v9 + 0x20;
					if ((v9 - 0x41u) > 0x19)
						v11 = v9;
					//printf("cmpattr_1: v11 = %d x%02X [%c]\n",v11,v11,v11);
					v12 = v10 + 0x20;
					if ((v10 - 0x41u) > 0x19)
						v12 = v10;
					//printf("cmpattr_1: v12 = %d x%02X [%c]\n",v12,v12,v12);
					v12 = v11 - v12;
					//printf("cmpattr_1: v11 - v12 = %d\n",v12);
					v18 = v12;
					if ( v12 )
						break;
				}
				if ( TDFtype & 2 && !v9 )
					break;
				v17 = (v9 - 48) <= 9;
				++src;
				++Buffer;
				TDFsize2--;
				TDFsize--;
			}
		}
	}
	if ( !v16 )
	{
		if ( TDFtype & 0x10 )
		{
			v13 = numsz(src, TDFsize);
			v14 = numsz(Buffer, TDFsize2);
			if ( v13 != v14 )
			{
				if ( v17 || v13 && v14 )
					v18 = v13 - v14;
			}
		}
	}
	return v18;
}

#endif
