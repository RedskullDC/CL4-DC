#ifndef PRINT_MISC_C
#define PRINT_MISC_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

void eprint(const char *format, ...)
{
	va_list va;

	//printf("eprint() called\n");
	va_start(va, format);
	if ( !fp_1 )
		fp_1 = stderr;
	vfprintf(fp_1, format, va);
	fflush(fp_1);
	va_end(va);	// keep va macros happy

}

void print(const char *format, ...)
{
	va_list va; // [sp+24h] [bp+Ch]@1

	va_start(va, format);
	vfprintf(stdout, format, va);
	fflush(stdout);
  	va_end(va);	// keep va macros happy

}

//	***	not called by libcl4 ***
void oprint(FILE *s, const char *format, ...)
{
	va_list va; // [sp+28h] [bp+10h]@1

	va_start(va, format);
	vfprintf(s, format, va);
	va_end(va);	// keep va macros happy

}

/*
Both these functions are not called in libcl4:

cgiprint()
dprint()

*/

#endif
