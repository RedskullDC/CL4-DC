#ifndef LEEOP_C
#define LEEOP_C

int leeop(int a1)
{
     short v1; // ax@2
     ONESC **v2; // edi@3
     ONESC *v3; // eax@5
     ONESC *v4; // eax@5
     ONESC *v5; // eax@9
     int v6; // eax@11
     int result; // eax@13
     short v8; // ax@14
     char v9[32]; // [sp+20h] [bp-58h]@14

     if ( a1 )
     {
          v1 = getptabp(a1 - 1);
          PTARR(v1);
     }
     v2 = &oelist;
     if ( oelist )
     {
          if ( oelist->NextESC )
          {
               while ( 1 )
               {
                    v3 = *v2;
                    v2 = &v3->NextESC;
                    v4 = v3->NextESC;
                    if ( !v4 )
                         break;
                    if ( !v4->NextESC )
                         goto LABEL_7;
               }
          }
          else
          {
LABEL_7:
               if ( *v2 )
                    v2 = &(*v2)->NextESC;
          }
     }
     v5 = (ONESC *)getmem(16);
     *v2 = v5;
     v5->KeyNumber = 49;
     symbol = getsym();
     if ( symbol == 2230 )
     {
          v8 = fixbname(v9, sym);
          (*v2)->BlockName = getmem(v8);
          cdbcpystr((*v2)->BlockName, v9, 0);
          symbol = getsym();
          result = 1;
     }
     else
     {
          if ( symbol == 930 )
               v6 = 2;
          else
               v6 = 33;
          loaderr(v6, sym);
          result = 0;
     }
     return result;
}

#endif
