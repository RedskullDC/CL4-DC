#ifndef RESTRICT_C
#define RESTRICT_C

#include "DBdefs.h"
#include "cl4.h"

int getwpos(char *Buffer, short Size)
{
	int v2; // edx@1
	char *v3; // eax@1
	char v4; // dl@4
	int result; // eax@7

	//printf("getwpos( Buffer: x%08X , Size: x%04X (%d)\n", Buffer, Size, Size);

	v2 = Size;
	v3 = Buffer;
	//DumpBlock(Buffer,Size);

	if ( !Size || !*Buffer )
		return -1;
	while ( *v3 >= 0 )
	{
		++v3;
		--v2;
		if ( !v2 || !*v3 )
			return -1;
	}
	v4 = *v3;
	
	// Not sure what these particular signature bytes mean.....
	// Wildcard chars?

	// if ( *v3 == 170 || v4 == 191 || v4 == 219 )
	// if ( *v3 == 0xAAu || v4 == 0xBFu || v4 == 0xDBu )
	//  if ( *v3 == '�' || v4 == '+' || v4 == '�' )

	if ( v4 == -86 || v4 == -65 || v4 == -37 )
		result = v3 - Buffer;	// wildcard found at Buffer offset
	else
		result = -1;	// -1 means wildcard not found
	//printf("getwpos: result = %d\n",result);
	return result;
}
// ** Not public in libcl4 **
short xkey(char *KeyBuf, EXPR *Expr, short Operator, TDef *TdefPtr)
{
	TDef *TDFp;
	EXPR *v5;
	EXPR *v6;
	short v7;
	short v9;
	char *dest;

	dest = KeyBuf;
	*KeyBuf = 0;
	TDFp = TdefPtr;
	
	while ( TDFp->TDFentry && TDFp->TDFtype & 1 )	// &1 = Keyfield
	{
		v5 = _bound(Expr, Operator, TDFp);
		v6 = v5;
		if ( !v5 || TDFp->TDFtype & 2 && getwpos(&v5->ExprData, v5->ExprSize) >= 0 )
			break;
		v9 = v6->ExprSize;
		v7 = v9;
		if ( v9 > TDFp->TDFsize )
			v7 = TDFp->TDFsize;
		dest += cpybuf(dest, &v6->ExprData, v7);
		if ( TDFp->TDFsize > v9 )
		{
			if ( !(TDFp->TDFtype & 2) || *(dest - 1) )
				break;
		}
		++TDFp;
	}
	return dest - KeyBuf;
}

// ** Not public in libcl4 **
short _restrict(int TDNo, EXPR *Expression)
{
	TDinfo *TDptr; 
	short result;

	//printf("_restrict( TDno: x%04X (%3d), EXPR: x%08X)\n", TDNo,TDNo,Expression);
	TDptr = _chktd(TDNo);
	relseq(TDptr);
	TDptr->KeyDefSize = 0;
  
	TDptr->field_0 &= 0xFDEF;
	if ( TDptr->field_0 & 0x0002 )
		TDptr->field_0 |= 0x1000;

	if ( TDptr->field_0 & 0x0008 )
	{
		newseq(TDptr);
		TDptr->Key1Size = xkey(TDptr->KeyBuf1, Expression, 0x30u, TDptr->TableDefs);
		TDptr->field_3A = 1;
		TDptr->Key2Size = xkey(TDptr->KeyBuf2, Expression, 0x18u, TDptr->TableDefs);
		TDptr->field_42 = 2;
		result = 0;
		if ( TDptr->Key1Size || TDptr->Key2Size )
			result = 1;
	}
	else
	{
		result = 0;
	}
	return result;
}

// HACK!!  Should call through xenter()

short cdbrestrict(int TDno,EXPR *Expr)
{
  return _restrict(TDno, Expr);
}

#endif
