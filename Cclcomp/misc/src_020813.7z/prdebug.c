#ifndef PRDEBUG_C
#define PRDEBUG_C

// print function ID
void prtfid(unsigned short ENTABno)
{
     const char *v3; // eax@60
     char *v5; // edx@94
     const char *v10; // eax@136
     const char *v11; // eax@145
     const char *v13; // eax@180
     FLDdesc *fld; // edi@191
     TDesc *v17; // edx@201
     char *Table; // eax@202

     int v1; // edx@5
     int OpCode; // eax@7
     int v4; // edx@91
     int v6; // eax@94
     unsigned int v9; // edi@131
     int v12; // eax@146
     int v14; // esi@190
     int v19; // [sp+0h] [bp-28h]@122
     int v20; // [sp+0h] [bp-28h]@139
     int v21; // [sp+0h] [bp-28h]@178
     int v22; // [sp+4h] [bp-24h]@145
     char *v23; // [sp+4h] [bp-24h]@180
     ENTAB *entab; // [sp+18h] [bp-10h]@1

	entab = ENTABno ? (ENTAB *)&enarr.TableAddr[12 * (ENTABno - 1)] : 0;
	if ( !entab )
		return;

	fflush(stdout);
    if ( entab->entype != 2 )                  // Expression Type
		goto LABEL_130;
	v1 = entab->TTno & 0xFC00;

	if ((unsigned int)(v1 - 1) <= 0x4FFF || v1 - 0x8C00u <= 0x1400 )
    {
		printf("[%d]", ENTABno);
        OpCode = entab->TTno & 0xFC00;
		switch (OpCode)
		{
			case 0x3800:
				printf(" CHR ");
				break;
			case 0x5800:
				printf("(-)");
				break;
			case 0x9400:
				printf(" RADIANS ");
				break;
			case 0x9C00:
				printf(" TRIM ");
				break;
			case 0xA000:
				printf(" GETCGI ");
				break;
			case 0x9800:
				printf(" EXP ");
				break;
			case 0x8C00:
				printf(" GETXML ");
				break;
			case 0x9000:
				printf(" DEGREES ");
				break;
			case 0x8000:
				printf(" SETENV ");
				break;
			case 0x4400:
				printf(" LOG10 ");
				break;
			case 0x4C00:
				printf(" ACOS ");
				break;
			case 0x5000:
				printf(" ATAN ");
				break;
			case 0x4800:
				printf(" ASIN ");
				break;
			case 0x3C00:
				printf(" SRAND ");
				break;
			case 0x4000:
				printf(" GETENV ");
				break;
			case 0x1C00:
				printf(" UCASE ");
				break;
			case 0x2800:
				printf(" DAY ");
				break;
			case 0x3000:
				printf(" ASIZE ");
				break;
			case 0x3400:
				printf(" ASC ");
				break;
			case 0x2C00:
				printf(" GETARG ");
				break;
			case 0x2000:
				printf(" LCASE ");
				break;
			case 0x2400:
				printf(" SLEN ");
				break;
			case 0x0C00:
				printf(" LOG ");
				break;
			case 0x1400:
				printf(" COS ");
				break;
			case 0x1800:
				printf(" TAN ");
				break;
			case 0x1000:
				printf(" SIN ");
				break;
			case 0x0400:
				printf(" NOT ");
				break;
			case 0x0800:
				printf(" SQRT ");
				break;
			default:
				printf(" unop: ?%o? ", entab->TTno);
				break;
		}
	}

//-------------
	if ( entab->entype == 2 )                  // All string functions follow
	{
		v4 = entab->TTno & 0xFC00;
		if ( v4 - 0x5001u <= 0x3BFE || v4 - 0xC801u <= 0xBFF || v4 - 0xF001u <= 0x7FF )
        {
			v5 = 0;	// default to print nothing

            v6 = entab->TTno & 0xFC00;

			switch (v6)
			{
				case 0x8400:
					v5 = "SKEY";
					break;
				case 0xD000:
					v5 = "SREP";
					break;
				case 0xD400:
					v5 = "SCONV";
					break;
				case 0xF400:
					v5 = "SCAT";
					break;
				case 0x8800:
					v5 = "SFMT";
					break;
				case 0xCC00:
					v5 = "SUBSTR";
					break;
				case 0x7400:
					v5 = "SDEL";
					break;
				case 0x7800:
					v5 = "SMULT";
					break;
				case 0x7C00:
					v5 = "SWORD";
					break;
				case 0x6C00:
					v5 = "MATCH";
					break;
			}
			if ( v5 )
			{
                printf(" %s(", v5);
                prtfid(entab->Dest);
                putchar(',');
                prtfid(entab->Src);
                putchar(')');
				return;
			}
		}
		if ( entab->entype == 2 )
		{
            v6 = entab->TTno & 0xFC00;
			if ( v6 == 0xB800 )
			{
				printf(" random() ");
            }
            else if (v6 == 0xBC00)
			{
				printf(" keyready() ");
			}
		}
	}

//-----------------------
LABEL_130:
	prtfid(entab->Dest);	// recursion
    if ( entab->entype != 2 )
    {
		if ( entab->entype == 8 )
        {
			v23 = *(char **)&entab->TTno;
            printf("~%ld~", v23);
            goto LABEL_207;
		}
        if ( entab->entype == 0x10 )
        {
			v23 = (char *)&entab->TTno;
            printf("~%s~", v23);
            goto LABEL_207;
		}
        if ( entab->entype == 0x04 )
        {
			printf("~%f~", *(float *)&entab->TTno);
            goto LABEL_207;
		}
        if ( entab->entype == 0x20 )
        {
			putchar(',');
		    goto LABEL_207;
		}

		if ( entab->entype != 1 )
			__assert_fail("((tf)->entype == 0x1)", "prdebug.c", 0xAEu, "prtfid");
		
		v14 = entab->TTno;
        if ( entab->TTno )
			fld = &ttab[v14].TTfields[entab->RecNo];
		else
			fld = getvars(entab->RecNo);
		
		if ( v14 )
        {
			v17 = &ttab[v14];
            if ( v17->TableAlias[0] )
				Table = v17->TableAlias;
			else
				Table = v17->TableName;
			printf("%s.%s", Table, fld->FLDname);
            printf("[%c] ", fld->FLDtype);
	        goto LABEL_207;
		}
        if ( fld->FLDstat & 4 )
        {
			prstr(fld->FLDname);
			if ( *fld->FLDname != '\'' )
            {
				printf("[%c] ", fld->FLDtype);
		        goto LABEL_207;
			}
			_IO_putc('\'', stdout);
			printf("[%c] ", fld->FLDtype);
			goto LABEL_207;
		}
        else
        {
			if ( fld->FLDtype != 'C' )
            {
				prstr(fld->FLDname);
				printf("[%c] ", fld->FLDtype);
				goto LABEL_207;
			}
            _IO_putc('\'', stdout);
            prstr((char *)fld->FLDdata);
			_IO_putc('\'', stdout);
			printf("[%c] ", fld->FLDtype);
			goto LABEL_207;
		}
	}

//----------------     
	v9 = ((unsigned int)entab->TTno >> 9) & 1;
    if ( ((unsigned int)entab->TTno >> 9) & 1 )
		printf(" (");
	else
		putchar(' ');

	if ( entab->TTno & 0x3F )
    {
		printf("[%d]", ENTABno);
        switch ( entab->TTno & 0x1FF )
        {
               case 0x01:
		            printf("OR");
				    goto LABEL_176;
               case 0x02:
		            printf("AND");
				    goto LABEL_176;
               case 0x08:
		            putchar('<');
					goto LABEL_176;
               case 0x14:
		            printf("like");
				    goto LABEL_176;
               case 0x10:
		            putchar('=');
					goto LABEL_176;
               case 0x18:
		            printf("<=");
				    goto LABEL_176;
               case 0x20:
		            putchar('>');
					goto LABEL_176;
               case 0x28:
		            printf("<>");
				    goto LABEL_176;
               case 0x30:
		            printf(">=");
				    goto LABEL_176;
               default:
					printf(" relop: ?%o?", entab->TTno);
					goto LABEL_176;
		}
	}
    
	printf("[%d]", ENTABno);
    
	v12 = entab->TTno & 0xFC00;
    if ( v12 == 0x6000 )
    {
   		putchar('*');
		goto LABEL_176;
	}
    if ( v12 > (signed int)0x6000u )
    {
		if ( v12 != 0x6800 )
        {
			if ( v12 > (signed int)0x6800u )
            {
				if ( v12 == 0xAC00 )
				{
					putchar('[');
					goto LABEL_176;
				}
			}
            else
            {
				if ( v12 == 0x6400 )
                {
					putchar('/');
					goto LABEL_176;
				}
			}
            goto LABEL_171;
		}
        printf("%%");
        goto LABEL_176;
	}
	
	if ( v12 == 0x5800 )
    {
		if ( entab->Src )
			putchar('-');
		else
			printf("(-)");
		goto LABEL_176;
	}
	
	if ( v12 <= (signed int)0x5800u )
    {
		if ( v12 != 0x5400 )
			goto LABEL_171;
		putchar('+');
        goto LABEL_176;
	}
    if ( v12 == 0x5C00 )
    {
		printf("**");
        goto LABEL_176;
	}

LABEL_171:
    if ( entab->TTno & 0x0100 )
    {
		prresv(entab->RecNo);
        goto LABEL_176;
	}
    if ( entab->Src )
    {
		printf(" op: ?%o?", entab->TTno);
	}

LABEL_176:
    if ( v9 )
		printf(") ");
	else
		putchar(' ');

LABEL_207:
    prtfid(entab->Src);
    
	if ( entab->entype == 2 && (unsigned short)(entab->TTno & 0xFC00) == 0xAC00 )
	{
        putchar(']');
		return;
	}
}

void prtree(VARTREE *a1, int Depth)
{
     if ( a1 )
     {
          prtree(a1->VarPrev, Depth + 1);
          printf("%3d %s\n", Depth, a1->VarName);
          prtree(a1->VarNext, Depth + 1);       // Recursion here
     }
}

void prvars(int ShowTree)
{
     FLDdesc *fld; // esi@3
     short VarNum; // edi@3
     char FLDtype; // eax@8
     char v4; // zf@10
     char VarName[32]; // [sp+30h] [bp-88h]@5

	if ( ShowTree )
    {
		prtree(troot, 0);
        return;
	}

	VarNum = 0;
    while ( (fld = getvars(VarNum),fld) )
    {
		if ( fld->FLDelemID )
			sprintf(VarName, "%s[%d]", fld->FLDname, fld->FLDelemID);// ElemID used as Array Size
		else
			sprintf(VarName, "%s", fld->FLDname);
		
		FLDtype = fld->FLDtype;
        printf("%3d %-20s [%c] %d", VarNum, VarName, FLDtype, fld->FLDlen);
        fflush(stdout);
        
		if ( !(fld->FLDstat & 0x0004) )          // true if variable is not assigned a value at compile time
		{
			switch (FLDtype)
			{
			case 'C':
				printf("\t('%s')", (char*)fld->FLDdata);
				break;
	
			case 'I':
			case 'N':
			case 'B':
				printf("\t(%ld)", (signed int)*(double *)fld->FLDdata);
				break;
	
			default:
				printf("\t(%f)", *(double *)fld->FLDdata);
				break;
			}
		}
		putchar('\n');
        VarNum++;
	}
	return;
}

void prtds()
{
	short count;
    short	v6; // edi@28

    void *v0; // esp@1
    short v1; // dx@2
    PTAB *pt; // eax@3
    TYPE24 *v5; // esi@28
    TDesc *TTptr; // esi@32
    int v8; // [sp+0h] [bp-48h]@1
    char *v9; // [sp+4h] [bp-44h]@17
    int v13; // [sp+14h] [bp-34h]@17
    int *BTCOUNT; // [sp+2Ch] [bp-1Ch]@1
    BTAB *bt; // [sp+38h] [bp-10h]@8

    BTCOUNT = (int*) alloca(4 * no_btabs);

    count = 0;					// pointless really, alloca clear memory
    while ( no_btabs > count )
		BTCOUNT[count++] = 0;

	count = 0;
    while((pt = PTARR(getptabp(count)), pt->OpCode))
    {
		if ( pt->OpCode == 720 || pt->OpCode == 600 )	// look for 'do' or 'format' OpCodes
			++BTCOUNT[pt->Operand];
		count++;
	}
    
	puts("\n<-- block name -->   <mode>  <td> <start>  <end> <calls>");
    count = 0;
    bt = btab;
	while ( bt->BlockName[0])
    {
		if ( bt->On_delete )
			++BTCOUNT[count];             // multiple use of some variables. Names partially meaningless.
		if ( bt->On_exit )
			++BTCOUNT[count];
		if ( bt->On_excep )
			++BTCOUNT[count];
		if ( bt->On_entry )
			++BTCOUNT[count];
        
        printf("%-20.20s  %-5.5s  %3d   %5d  %5d   calls=%5d",bt->BlockName, bt->Maintain,bt->TTno,bt->StartLine, bt->EndLine, BTCOUNT[count]);
        if ( count && !BTCOUNT[count] )
			print(" block not called");

		if ( bt->On_delete )
            printf("  on_delete %s (%d) ", bt->On_delete->BlockName, bt->On_delete->BlockNo);
        if ( bt->On_exit )
            printf("  on_exit %s (%d) ", bt->On_exit->BlockName, bt->On_exit->BlockNo);
        if ( bt->On_excep )
            printf("  on_exception %s (%d) ", bt->On_excep->BlockName, bt->On_excep->BlockNo);
        if ( bt->On_entry )
            printf("  on_entry %s (%d) ", bt->On_entry->BlockName, bt->On_entry->BlockNo);
        putchar('\n');
//---------------------------          
		v5 = bt->TYPE24;
        v6 = 0;
        while ( v5 )
		{
            printf("scr%d(%d-%d) ", v6, v5->PT_start,v5->PT_end);
            v6++;
			v5 = v5->NextT24;
        }
        printf("scrs(%d), fmts(%d)\n", bt->Scrs,bt->fmts);
		bt++;
		count++;
	}
//==============================
	puts("\ntd <- database -> <- table name -> < alias >  <status>");
    TTptr = ttab;
    
	count = 0;
    while ( no_ttabs > count )
    {
		if ( TTptr->TableName[0] )
        {
            printf("%2d %-14.14s %-14.14s   %-10.10s ", count, dtab[TTptr->DBnumber].FullDBname, TTptr->TableName, TTptr->TableAlias);
            if ( TTptr->TDlocked & 0x0001 )
				printf("lock ");
			if ( TTptr->TDlocked & 0x0080)
				printf("lockr ");
			if ( TTptr->TDlocked & 0x0002 )
				printf("put ");
			if ( TTptr->TDlocked & 0x0004 )
				printf("get ");
			if ( TTptr->TDlocked & 0x0100 )
				printf("getn/p ");
			if ( TTptr->TDlocked & 0x0008 )
				printf("getk ");
			if ( TTptr->TDlocked & 0x8000 )
				printf("del ");
			if ( TTptr->TDlocked & 0x0010 )
				printf("hask ");
			if ( TTptr->TDlocked & 0x4000 )
				printf("hass ");
			if ( TTptr->TDlocked & 0x0020 )
				printf("avail ");
			if ( TTptr->TDlocked & 0x0040 )
				printf("flock ");
			if ( TTptr->TDlocked & 0x0200 )
				printf("create ");
			if ( TTptr->TDlocked & 0x0400 )
				printf("unique ");
			if ( !(TTptr->TDlocked & 0x0800) )
				printf("not_open ");
			putchar('\n');
		}
        count++;
        TTptr++;
	}
}

void prrt(unsigned short RTno)
{
    RTAB *v1; // esi@1

	v1 = RTno ? (RTAB *)&rtarr.TableAddr[20 * (RTno - 1)] : 0;
    if ( v1 )
    {
		putchar(' ');
        prtfid(v1->field_E);
        prrt(v1->NextRT);                     // some lovely recursion
	}
}

void prpf(unsigned short PRno)
{
    PRTAB *prtab; // esi@1
    signed int v2; // eax@5
    const char *v3; // eax@12
    int v4; // eax@20
    const char *v5; // eax@27
    int v6; // [sp+4h] [bp-14h]@27

	prtab = PRno ? (PRTAB *)&prarr.TableAddr[10 * (PRno - 1)] : 0;
    if ( prtab )
    {
          if ( !prtab->field_6 )
          {
               prtfid(prtab->field_0);
LABEL_19:
               if ( !prtab->field_4 )
               {
                    if ( prtab->field_2 )
                    {
                         putchar(',');
                         prtfid(prtab->field_2);
                    }
                    else
                    {
                         putchar(' ');
                    }
                    goto LABEL_36;
               }
               v4 = prtab->field_4 & 0x7C00;
               if ( v4 == 0x1000 )
               {
                    v6 = prtab->field_4 & 0xFFFF83FF;
                    v5 = ",%dc ";
               }
               else
               {
                    if ( v4 > (signed int)0x1000u )
                    {
                         if ( v4 == 0x2000 )
                         {
                              v6 = prtab->field_4 & 0xFFFF83FF;
                              v5 = ",%dr ";
                         }
                         else
                         {
                              if ( v4 != 0x4000 )
                                   goto LABEL_31;
                              v6 = prtab->field_4 & 0xFFFF83FF;
                              v5 = ",%dl ";
                         }
                    }
                    else
                    {
                         if ( v4 != 0x800 )
                         {
LABEL_31:
                              v6 = prtab->field_4;
                              v5 = ",%d ";
                              goto LABEL_32;
                         }
                         v6 = prtab->field_4 & 0xFFFF83FF;
                         v5 = ",%dx ";
                    }
               }
LABEL_32:
               printf(v5, v6);
LABEL_36:
               prpf(prtab->NextPR);
               return;
          }
          v2 = prtab->field_6;
          if ( v2 == 2 )
          {
               v3 = "ff";
          }
          else
          {
               if ( v2 > 2 )
               {
                    if ( v2 == 4 )
                    {
                         v3 = "nl";
                    }
                    else
                    {
                         if ( v2 != 4096 )
                              goto LABEL_17;
                         v3 = "cr";
                    }
               }
               else
               {
                    if ( v2 != 1 )
                    {
LABEL_17:
                         prresv(prtab->field_6);
                         goto LABEL_19;
                    }
                    v3 = "cl";
               }
          }
          printf(v3);
          goto LABEL_19;
     }
}

// Show Redisplay Info
void prrd(unsigned short RDno)
{
     RDTAB *rdtab; // esi@1

     rdtab = RDno ? (RDTAB *)&rdarr.TableAddr[12 * (RDno - 1)] : 0;
     if ( rdtab )
     {
          if ( rdtab->TTno <= 0 )
               prtfid(rdtab->field_2);
          else
               printf("%s", ttab[rdtab->TTno].TableName);
          putchar(' ');
          prrd(rdtab->NextRD);                  // Recursion here
     }
}

void prcolrow(unsigned short a1)
{
     char *v1; // eax@3
     const char *v2; // eax@5
     int v3; // eax@6
     char *v4; // [sp+4h] [bp-14h]@5

     if ( a1 == 0x1000 )                        // a1 = bitmask
     {
          v1 = "c";
          goto LABEL_5;
     }
     if ( a1 != 0x2000 )
     {
          v3 = a1 & 0x7E00;
          if ( (a1 & 0x7E00) != 0x800 )
          {
               if ( v3 <= (signed int)0x800u )
               {
                    if ( v3 != 0x200 )
                    {
                         if ( v3 != 0x400 )
                         {
LABEL_20:
                              v4 = (char *)(a1 & 0x1FF);
                              v2 = "%d";
                              goto LABEL_21;
                         }
LABEL_18:
                         v4 = (char *)(a1 & 0x1FF);
                         v2 = "<%d";
                         goto LABEL_21;
                    }
LABEL_17:
                    v4 = (char *)(a1 & 0x1FF);
                    v2 = ">%d";
                    goto LABEL_21;
               }
               if ( v3 == 0x2000 )
                    goto LABEL_18;
               if ( v3 <= (signed int)0x2000u )
               {
                    if ( v3 != 0x1000 )
                         goto LABEL_20;
                    goto LABEL_17;
               }
               if ( v3 != 0x4000 )
                    goto LABEL_20;
          }
          v4 = (char *)(a1 & 0x1FF);
          v2 = "=%d";
          goto LABEL_21;                        // multiple use of V5!!!!
     }
     v1 = "r";
LABEL_5:
     v4 = v1;
     v2 = "%s";
LABEL_21:
     printf(v2, v4);
}


// Print a screen accept definition
void prxt(XTAB *xtab, int HeadText)
{
     const char *v2; // eax@6
     const char *v3; // eax@15
     const char *v4; // eax@33
     short VarNum; // ax@47
     FLDdesc *fld; // esi@50
     const char *v7; // eax@56
     RTAB *rtab; // esi@72
     char *v9; // eax@74
     RATAB *ratab; // esi@82
     signed int v11; // eax@84
     const char *v12; // eax@90
     int TTno; // [sp+14h] [bp-14h]@47
     int v14; // [sp+1Bh] [bp-Dh]@47

     if ( !xtab )
          return;
     prtfid(xtab->VarExpNo);
     putchar(' ');
     if ( xtab->widthEXP )
          prtfid(xtab->widthEXP);
     else
          printf("%d", xtab->width);
     if ( xtab->Flags & 4 )                     // display only
     {
          v2 = ",d";
     }
     else
     {
          if ( !(xtab->Flags & 0x0400))     // required
               goto LABEL_10;
          v2 = ",r";
     }
     printf(v2);
LABEL_10:
     printf(" at ");
     if ( xtab->PCol_exp )
          prtfid(xtab->PCol_exp);
     else
          prcolrow(xtab->PCol);
     if ( xtab->ScrAttrib )
     {
          switch ( xtab->ScrAttrib )
          {
               case 1:
                    v3 = ",f";
                    goto LABEL_22;
               case 2:
                    v3 = ",s";
                    goto LABEL_22;
               case 4:
                    v3 = ",u";
                    goto LABEL_22;
               case 0x20:
                    v3 = ",r";
                    goto LABEL_22;
               case 0x10:
                    v3 = ",B";
                    goto LABEL_22;
               case 8:
                    v3 = ",b";
                    goto LABEL_22;
               case 0x3F:
                    v3 = ",n";
LABEL_22:
                    printf(v3);
                    break;
               default:
                    printf(",%o", xtab->ScrAttrib);
                    break;
          }
     }
     putchar(' ');
     if ( xtab->PLine_exp )
          prtfid(xtab->PLine_exp);
     else
          prcolrow(xtab->PLine);
     putchar(' ');
     if ( !HeadText )                           // true if this is an accept field. Show the Answer Col/Line values
     {
          if ( xtab->ACol_exp )
               prtfid(xtab->ACol_exp);
          else
               prcolrow(xtab->ACol);
          if ( xtab->Attr )
          {
               switch ( xtab->Attr )
               {
                    case 1:
                         v4 = ",f";
                         goto LABEL_40;
                    case 2:
                         v4 = ",s";
                         goto LABEL_40;
                    case 4:
                         v4 = ",u";
                         goto LABEL_40;
                    case 0x20:
                         v4 = ",r";
                         goto LABEL_40;
                    case 0x10:
                         v4 = ",B";
                         goto LABEL_40;
                    case 8:
                         v4 = ",b";
                         goto LABEL_40;
                    case 0x3F:
                         v4 = ",n";
LABEL_40:
                         printf(v4);
                         break;
                    default:
                         printf(",%o", xtab->ScrAttrib);
                         break;
               }
          }
          putchar(' ');
          if ( xtab->ALine_exp )
               prtfid(xtab->ALine_exp);
          else
               prcolrow(xtab->ALine);
          putchar(' ');
     }
     prtfid(xtab->Prompt_exp);
     if ( !HeadText )
     {
          VarNum = gettf(xtab->VarExpNo, &TTno, (char *)&v14);
          if ( VarNum < 0 )
               __assert_fail("fno >= 0", "prdebug.c", 0x133u, "prxt");
          if ( TTno )
               fld = &ttab[TTno].TTfields[VarNum];
          else
               fld = getvars(VarNum);
          if ( xtab->Flags & 8 )
               printf(" FDF");
          if ( xtab->Flags >= 0 )
          {
               if ( fld->FLDstat >= 0 )
                    goto LABEL_60;
               v7 = " key";
          }
          else
          {
               printf(" tkey");
               if ( !(xtab->Flags & 0x40) )
                    goto LABEL_60;
               v7 = " LKF";
          }
          printf(v7);
LABEL_60:
          if ( fld->FLDstat & 8 )
               printf(" result");
          if ( xtab->Flags & 0x0200 )
               printf(" num");
          if ( xtab->Flags & 2 )
               printf(" date");
          if ( xtab->Flags & 0x0800 )
               printf(" time");
          if ( xtab->Flags & 1 )
               printf(" char");
          if ( xtab->Flags & 0x110 )
          {
               if ( xtab->RangeID )
                    rtab = (RTAB *)&rtarr.TableAddr[20 * (xtab->RangeID - 1)];
               else
                    rtab = 0;
               v9 = "no_join";
               if ( xtab->Flags & 0x10 )
                    v9 = "join";
               printf("\n\t\t%s ", v9);
               if ( xtab->Flags & 0x20 )
                    printf("lock ");
               prtfid(rtab->field_C);
               printf(" = ");
               prtfid(rtab->field_E);
               if ( rtab->WhereEXP )
               {
                    printf(" where ");
                    prtfid(rtab->WhereEXP);
               }
               goto LABEL_98;
          }
          if ( !xtab->RangeID )
          {
LABEL_98:
               if ( xtab->Width )
                    printf(" vw=%d", xtab->Width);// visible width?
               return;
          }
          printf("\n\t\trange ");
          if ( xtab->RangeID )
               ratab = (RATAB *)&raarr.TableAddr[12 * xtab->RangeID - 12];
          else
               ratab = 0;
          v11 = ratab->RangeType;
          if ( v11 == 2 )
          {
               v12 = " NEGATIVE ";
          }
          else
          {
               if ( v11 > 2 )
               {
                    if ( v11 != 6 )
                    {
LABEL_94:
                         prtfid(ratab->RangeFrom);
                         if ( !(xtab->Flags & 1) )
                         {
                              printf(" to ");
                              prtfid(ratab->RangeTo);
                         }
                         goto LABEL_96;
                    }
                    v12 = " NAME ";
               }
               else
               {
                    if ( v11 != 1 )
                         goto LABEL_94;
                    v12 = " POSITIVE ";
               }
          }
          printf(v12);
LABEL_96:
          if ( ratab->StringOffset )
               printf(" '%s'", &strarr.StringTable[ratab->StringOffset - 1]);
          goto LABEL_98;
     }
}

void prkx(KXTAB *kxtab)
{
     int *TTcount; // esi@1
     short *i; // esi@3
     short *j; // esi@5
     short *k; // esi@7

     printf("[%s] tds: ", kxtab->TableName);
     for ( TTcount = kxtab->TTlist; *TTcount; ++TTcount )
          printf("%d ", *TTcount);
     printf("\n\t\tkey doms: ");
     for ( i = kxtab->KeyElemIDs; *i; ++i )
          printf("%d ", *i);
     printf("\n\t\tkey ty: ");
     for ( j = kxtab->TkeyTy; *j; ++j )
          printf("%#o ", *j);
     printf("\n\t\tdata doms: ");
     for ( k = kxtab->DataElemIDs; *k; ++k )
          printf("%d ", *k);
     printf(
          "\n\t\tntds=%d, nkeys=%d, ndata=%d, ks=%d, rs=%d\n",
          kxtab->NumTTs,
          kxtab->NumKeyFields,
          kxtab->NumDataFields,
          kxtab->KeySize,
          kxtab->RecSize);
     printf("\t\twhere ");
     prtfid(kxtab->WhereEXP);
}

// Show an assignment expression
void prcalc(ENTAB *ent)
{
     int v1; // eax@3
     char *v2; // edx@3
     char v3; // zf@7
     const char *v4; // eax@16
     char *v5; // [sp+4h] [bp-14h]@16

     if ( ent )
     {
          prtfid(ent->Dest);
          if ( ent->entype != 2 )               // 2 = calculation assignment. Other is string assighnment?
          {
               printf(" = ");
LABEL_22:
               prtfid(ent->Src);
               return;
          }
          v1 = ent->TTno & 0xFC00;
          v2 = "*=";
          if ( v1 != 0xE000 )
          {
               if ( v1 > (signed int)0xE000u )
               {
                    v2 = "%=";
                    if ( v1 != 0xE800 )
                    {
                         if ( v1 > (signed int)0xE800u )
                         {
                              v2 = "**=";
                              v3 = v1 == 0xEC00;
                         }
                         else
                         {
                              v2 = "/=";
                              v3 = v1 == 0xE400;
                         }
LABEL_13:
                         if ( !v3 )
                              v2 = "<UNKNOWN>";
                         goto LABEL_15;
                    }
               }
               else
               {
                    v2 = "+=";
                    if ( v1 != 0xD800 )
                    {
                         if ( v1 > (signed int)0xD800u )
                         {
                              v2 = "-=";
                              v3 = v1 == 0xDC00;
                         }
                         else
                         {
                              v2 = "=";
                              v3 = v1 == 0xA800;
                         }
                         goto LABEL_13;
                    }
               }
          }
LABEL_15:
          if ( ent->TTno & 0x0200 )
          {
               v5 = v2;
               v4 = " (%s) ";
          }
          else
          {
               if ( ent->TTno & 0x40 )
               {
                    v5 = v2;
                    v4 = " %s RND ";
               }
               else
               {
                    v5 = v2;
                    v4 = " %s ";
               }
          }
          printf(v4, v5);
          goto LABEL_22;
     }
}

void prpipe(SFTAB *sftab)
{
     int v1; // eax@2
     int v2; // eax@4
     const char *v3; // eax@9
     int v4; // eax@13
     int v5; // eax@24

     if ( sftab )
     {
          v1 = sftab->field_0;
          if ( !(v1 & 0x10) )
          {
               if ( sftab->field_0 & 8 )
               {
                    v3 = "close ";
               }
               else
               {
                    v5 = sftab->field_0 & 0xFFBF;
                    if ( v5 == 1 )
                    {
                         v3 = "read ";
                    }
                    else
                    {
                         if ( v5 == 2 )
                              v3 = "write ";
                         else
                              v3 = "r/w????? ";
                    }
               }
               goto LABEL_29;
          }
          if ( v1 & 0x40 )
          {
               v2 = v1 & 0xFFFFFFAF;
               if ( v2 == 2 )
               {
                    v3 = "popenout ";
               }
               else
               {
                    if ( v2 > 2 )
                    {
                         if ( v2 == 3 )
                         {
                              v3 = "popenio ";
                              goto LABEL_29;
                         }
                    }
                    else
                    {
                         if ( v2 == 1 )
                         {
                              v3 = "popenin ";
                              goto LABEL_29;
                         }
                    }
                    v3 = "popen?? ";
               }
          }
          else
          {
               v4 = sftab->field_0 & 0xFFEF;
               if ( v4 == 2 )
               {
                    v3 = "openout ";
               }
               else
               {
                    if ( v4 > 2 )
                    {
                         if ( v4 == 4 )
                         {
                              v3 = "openapp ";
                              goto LABEL_29;
                         }
                    }
                    else
                    {
                         if ( v4 == 1 )
                         {
                              v3 = "openin ";
                              goto LABEL_29;
                         }
                    }
                    v3 = "open?? ";
               }
          }
LABEL_29:
          printf(v3);
          prtfid(sftab->field_4);
          if ( sftab->field_6 )
          {
               prtfid(sftab->field_6);
          }
          else
          {
               if ( sftab->field_2 )
                    prpf(sftab->field_2);
          }
     }
}

void prset(PTAB *ptb)
{
     int OpCode; // esi@1
     short Operand; // edi@1
     const char *v3; // eax@2
     const char *v4; // eax@6
     char *v5; // eax@24
     char *v6; // eax@28
     char *v7; // eax@31
     char *v8; // eax@34
     char *v9; // eax@37
     char *v10; // eax@40
     char *v11; // eax@43
     char *v12; // eax@46
     char *v13; // eax@49
     char *v14; // eax@52
     char *v15; // eax@55
     char *v16; // eax@58
     char *v17; // eax@61
     char *v18; // eax@64
     char *v19; // eax@67
     char *v20; // eax@70
     char *v21; // eax@73
     char *v22; // eax@77
     char *v23; // eax@81
     int v24; // [sp+0h] [bp-18h]@15
     char *v25; // [sp+4h] [bp-14h]@2

    OpCode = ptb->OpCode;
    Operand = ptb->Operand;
    printf("set ");
	switch ( OpCode )
    {
		case 673:
            printf("dateform,[%d]",Operand);
			break;
		case 652:
            printf("tab,[%c]", Operand);
			break;
		case 654:
            printf("fill,[%c]", Operand);
			break;
          case 650:
          case 656:
          case 658:
          case 660:
          case 662:
          case 664:
          case 668:
               switch ( OpCode )
               {
                    case 656:
                         v4 = "accept,";
                         goto LABEL_13;
                    case 650:
                         v4 = "message,";
                         goto LABEL_13;
                    case 658:
                         v4 = "prompt,";
                         goto LABEL_13;
                    case 660:
                         v4 = "error,";
                         goto LABEL_13;
                    case 662:
                         v4 = "head,";
                         goto LABEL_13;
                    case 664:
                         v4 = "text,";
                         goto LABEL_13;
                    case 668:
                         v4 = "print,";
LABEL_13:
                         printf(v4);
                         break;
                    default:
                         break;
               }
               switch ( Operand )
               {
                    case 1u:
                         v24 = 'f';
                         break;
                    case 2u:
                         v24 = 's';
                         break;
                    case 4u:
                         v24 = 'u';
                         break;
                    case 0x20u:
                         v24 = 'r';
                         break;
                    case 0x10u:
                         v24 = 'B';
                         break;
                    case 8u:
                         v24 = 'b';
                         break;
                    case 0x3Fu:
                         v24 = 'n';
                         break;
                    default:
						printf("(%d)", Operand);
						return;
					break;
               }
               putchar(v24);
               return;
          case 670:
               v5 = "off";
               if ( Operand == 1 )
                    v5 = "on";
               v25 = v5;
               v3 = "abort,%s";
               goto LABEL_85;
          case 684:
               printf("align,%d", Operand);
			   break;
          case 665:
               v6 = "off";
               if ( Operand == 1 )
                    v6 = "on";
               v25 = v6;
               v3 = "E,%s";
               goto LABEL_85;
          case 630:
               v7 = "off";
               if ( Operand == 1 )
                    v7 = "on";
               v25 = v7;
               v3 = "csv,%s";
               goto LABEL_85;
          case 640:
               v8 = "off";
               if ( Operand == 1 )
                    v8 = "on";
               v25 = v8;
               v3 = "dos,%s";
               goto LABEL_85;
          case 682:
               v9 = "off";
               if ( Operand == 1 )
                    v9 = "on";
               v25 = v9;
               v3 = "goback,%s";
               goto LABEL_85;
          case 680:
               v10 = "off";
               if ( Operand == 1 )
                    v10 = "on";
               v25 = v10;
               v3 = "trim,%s";
               goto LABEL_85;
          case 676:
               v11 = "off";
               if ( Operand == 1 )
                    v11 = "on";
               v25 = v11;
               v3 = "aauto,%s";
               goto LABEL_85;
          case 678:
               v12 = "off";
               if ( Operand == 1 )
                    v12 = "on";
               v25 = v12;
               v3 = "rauto,%s";
               goto LABEL_85;
          case 679:
               v13 = "off";
               if ( Operand == 1 )
                    v13 = "on";
               v25 = v13;
               v3 = "repeat,%s";
               goto LABEL_85;
          case 666:
               v14 = "off";
               if ( Operand == 1 )
                    v14 = "on";
               v25 = v14;
               v3 = "justify,%s";
               goto LABEL_85;
          case 681:
               v15 = "off";
               if ( Operand == 1 )
                    v15 = "on";
               v25 = v15;
               v3 = "hangup,%s";
               goto LABEL_85;
          case 686:
               v16 = "off";
               if ( Operand == 1 )
                    v16 = "on";
               v25 = v16;
               v3 = "convert,%s";
               goto LABEL_85;
          case 687:
               v17 = "off";
               if ( Operand == 1 )
                    v17 = "on";
               v25 = v17;
               v3 = "rawdisplay,%s";
               goto LABEL_85;
          case 688:
               v18 = "off";
               if ( Operand == 1 )
                    v18 = "on";
               v25 = v18;
               v3 = "rawprint,%s";
               goto LABEL_85;
          case 659:
               v19 = "off";
               if ( Operand == 1 )
                    v19 = "on";
               v25 = v19;
               v3 = "null_exit,%s";
               goto LABEL_85;
          case 672:
               v20 = "off";
               if ( Operand == 1 )
                    v20 = "on";
               v25 = v20;
               v3 = "debug,%s";
               goto LABEL_85;
          case 651:
               v21 = "off";
               if ( Operand == 1 )
                    v21 = "on";
               v25 = v21;
               v3 = "xml,%s";
               goto LABEL_85;
          case 669:
               if ( Operand )
               {
                    v22 = "off";
                    if ( Operand == 1 )
                         v22 = "on";
                    v25 = v22;
                    v3 = "skip,%s";
LABEL_85:
                    printf(v3, v25);
               }
               else
               {
                    printf("skip");
               }
               return;
          case 667:
               v23 = "stdout";
               if ( Operand == 1 )
                    v23 = "console";
               v25 = v23;
               v3 = "print,%s";
               goto LABEL_85;
          default:
				printf("unknown,[%c]", Operand);
			   break;
     }
}
#endif
