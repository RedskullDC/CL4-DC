#ifndef DMERGE_C
#define DMERGE_C

#include "DBdefs.h"
#include "cl4.h"

void _dmerge(SALLOCBUF *a1, TDinfo *TDptr)
{
	SALLOCBUF *i; // edi@1

	for ( i = a1; i; i = i->NextSA )
	{
		relnode(TDptr->TDNodePtr);
		TDptr->TDNodePtr = 0;
		_dpos((DPOS*)&i->field_C, i->field_4, i->field_8, TDptr);
		i->field_1C = _dfetch((char*)&i->field_20,(DPOS*)&i->field_C, TDptr);
	}
}

#endif

