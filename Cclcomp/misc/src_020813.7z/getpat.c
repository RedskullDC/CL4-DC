#ifndef GETPATH_C
#define GETPATH_C

#include "DBdefs.h"
#include "cl4.h"

int _getpath(int *PageList, TDinfo *TDptr)
{

	short i; // di@1
	int v6; // Depth - Level into the tree structure
	PAGE *PageBuffer;
	short a3;

	//printf("_getpath(PagePtr: %08X,TDptr: %08X) Called - ",PageList,TDptr);
	v6 = _rhead(TDptr->TDDBinfo, TDptr->TDindexOff, PageList);
	for ( i = v6; i > 1; --i )
	{
		PageBuffer = _indexpg(TDptr, *PageList);
		if ( _scanpg(PageBuffer, TDptr, &a3, 9))
			++a3;
		++PageList;
		*PageList = mstol((int *)&PageBuffer->DataStart[4 * a3]);
		//printf("Pagelist[%d] = x%04X (%4d) \n",a3,*PageList2,*PageList2);
	}
	//printf("Returning %d\n",v6);
	return v6;
}
#endif
