#ifndef CHKPAGE_C
#define CHKPAGE_C

#include "DBdefs.h"
#include "cl4.h"

bool _chkpage(TDinfo *TDptr, PAGE *PageBuffer)
{
	char *v2;
	char *v4;
	bool v3;
	int v5;
	int v6;
	short v7;
	short v9;
	DBinfo *DBptr;

	DBptr = TDptr->TDDBinfo;
	if ( !(PageBuffer->PageType & 0x40) )
	{
		if ( DBptr->DBvflag == 2 )	// old style dbases
		{
			v5 = PageBuffer->NumEntries;
			if ( PageBuffer->PageType >= 0 )
				v9 = TDptr->TDRecSize * v5;
			else
				v9 = TDptr->TDKeySize * v5;
		}
		else
			v9 = (short)(int)PageBuffer->TabStart_or_RecSize * PageBuffer->NumEntries;

		return &PageBuffer->TabEnd[v9] <= &PageBuffer->PageType + DBptr->DBpgsize;	// Check that we don't exceed the page boundary
	}

	v9 = 0;
	v2 = (char*) PageBuffer->TabStart_or_RecSize + 2 * PageBuffer->NumEntries;
	v3 = 0;
	if ( (char*)(&PageBuffer->PageType + DBptr->DBpgsize) <= v2 )
		return v3;
	
	v4 = (char *)PageBuffer->TabStart_or_RecSize;
	if ( v4 >= v2 )
		return &PageBuffer->TabEnd[v9] <= &PageBuffer->PageType + DBptr->DBpgsize;
  
  //----------
	while ( 1 )
	{
		v3 = 0;
		v7 = SWAP_SHORT(v4);
		if ( v7 <= v9 )
			break;
		v9 = v7;
		v4 += 2;
		if ( v4 >= v2 )
			return &PageBuffer->TabEnd[v9] <= &PageBuffer->PageType + DBptr->DBpgsize;
	}
	return v3;
}


#endif
