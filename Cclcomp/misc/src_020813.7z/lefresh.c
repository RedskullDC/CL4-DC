#ifndef LEFRESH_C
#define LEFRESH_C

int lefresh(PTAB *ptab)
{
	short v1; // ax@1
    char *v2; // eax@4

    v1 = getsym();
    symbol = v1;			// refresh without a block name is OK
    if ( v1 != 930 && v1 )
    {
		ptab->TABno = getstrmem(syml + 1);
        v2 = ptab->TABno ? &strarr.StringTable[ptab->TABno - 1] : 0;
        cdbcpystr(v2, sym, 0);
        symbol = getsym();
	}
    return 1;
}

int lescreen(PTAB *pt)
{
	short v1; // ax@1
    int v2; // eax@4
    int result; // eax@6
    char *v4; // eax@8

    v1 = getsym();
    symbol = v1;
    if ( v1 != 930 && v1 )           // expects a block name
    {
		pt->TABno = getstrmem(syml + 1);
        v4 = pt->TABno ? &strarr.StringTable[pt->TABno - 1] : 0;
        cdbcpystr(v4, sym, 0);
        symbol = getsym();
        result = 1;
	}
    else
    {
		if ( symbol == 930 )
			v2 = 7;					// "unexpected end of line"
		else
			v2 = 6;					// "unexpected end of file"
		loaderr(v2, sym);
        result = 0;
	}
    return result;
}

#endif
