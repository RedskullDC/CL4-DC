#ifndef MSTOI_C
#define MSTOI_C

#include "DBdefs.h"
#include "cl4.h"

short mstoi(short *a1)
{
	//return *(a1 + 1) + (*a1 << 8);

	//printf("mstoi( *a1 = x%04X, returns : x%04X)\n" ,*a1,SWAP_SHORT(a1));
	return SWAP_SHORT(a1);
}

#endif

