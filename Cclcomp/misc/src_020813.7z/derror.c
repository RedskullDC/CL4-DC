#ifndef DERROR_C
#define DERROR_C

#include <stdio.h>
#include "DBdefs.h"
#include "cl4.h"

void _derror(short ErrNo)
{
    //char Buffer[16]; // [sp+10h] [bp-18h]@1

    //Buffer[itob(Buffer, ErrNo, 10)] = 0;
    //printf("Data File Error # [%s]\n", Buffer);

// *** to do - Add itob() ***
	
	printf("Data File Error # [%d]\n", ErrNo);
    sleep(1u);
    abort();
}

void derror(short ErrorCode, DBinfo *DBptr, TDinfo *TDptr)
{
	int DBno; // [sp+4h] [bp-14h]@2
	signed int TDno; // [sp+8h] [bp-10h]@2

	if ( DBptr )
	{
		TDno = -1;
		DBno = fdf2db(DBptr);
	}
	else
	{
		if ( TDptr )
			TDno = nr2td(TDptr);
		else
			TDno = -1;
		DBno = 0;
	}
	cdberror(ErrorCode, DBno, TDno);
	// cdberror never returns on LIBCL4
	_derror(ErrorCode);
}

// ***********  versions for Clcomp, Clenter and LIBCL4 are different  **********  !!!!
/*
void dberror(int ErrorCode, int DBno, int TDno)
{
	char *v3;
	char v5;
	int Context;
	char *v7;
	char *v8;

	v8 = 0;
	v7 = 0;
	Context = -1;
	v3 = "DBASE";
	if ( DBno < 0 )
		v3 = "INTERNAL";
  
	eprint("\n\a%s err %d\n", v3, -ErrorCode);
	if ( DBno >= 0 )
	{
		if ( TDno >= 0 )
		{
			v8 = dtab[ttab[TDno].DBnumber].FullDBname;
			switch (TDno)
			{
			case 0:
				v7 = "tables";
				break;
			case 1:
				v7 = "fields";
				break;
			case 2:
				v7 = "locks";
				break;
			default:
				v7 = ttab[TDno].TableName;
				break;
			}
			Context = ttab[TDno].DBcontext;
		}
		else
		{
			v8 = dtab[DBno].FullDBname;
			Context = dtab[DBno].DBcontext;
		}
	}
	
	if ( v8 )
	{
		eprint("Database: [%s] ", v8);
		if ( v7 )
			eprint("Table: [%s]", v7);
		//eprint(" ctx=%d\n", Context);
		eprint("\n");
	}

	//cllogerr(ErrorCode, pnameArr[Context - 10000], v8, v7);
	//closetlog(Context, 1);
	//exit(1);                                      // dead end error exit

	cllogerr(ErrorCode, pname, v8, v7);
	//return kill(getpid(),5);
	//kill(getpid(),5);
	exit(1);

}
*/
void dberror(int ErrorNo, int DBno, int TDno)
{
     char *v3; // eax@1
     char *v4; // eax@8
     TDesc *v5; // edx@15
     signed int v6; // ecx@15
     char *v7; // [sp+14h] [bp-14h]@1
     char *arg; // [sp+18h] [bp-10h]@1

     arg = 0;
     v7 = 0;
     v3 = "DBASE";
     if ( DBno < 0 )
          v3 = "INTERNAL";
     eprint("\n\a%s err %d\n", v3, -ErrorNo);
     if ( DBno < 0 )
          goto LABEL_21;
     if ( TDno < 0 )
     {
          arg = dtab[DBno].FullDBname;
          goto LABEL_21;
     }

     arg = dtab[DBno].FullDBname;


     if ( TDno == 1 )
     {
          v4 = "fields";
     }
     else
     {
          if ( TDno > 1 )
          {
               if ( TDno != 2 )
               {
LABEL_15:
                    v5 = ttab;
                    v6 = 0;
                    if ( no_ttabs > 0 )
                    {
                         while ( v5->TTrtd != TDno )
                         {
                              ++v6;
                              ++v5;
                              if ( v6 >= no_ttabs )
                                   goto LABEL_18;
                         }
                         v7 = v5->TableName;
                         arg = dtab[v5->DBnumber].FullDBname;
                    }
LABEL_18:
                    if ( !v7 )
                    {
                         v4 = "NOT FOUND";
                         arg = "NOT FOUND";
                         v7 = v4;
						 goto LABEL_21;

                    }
LABEL_21:
                    if ( arg )
                    {
                         eprint("Database: [%s] ", arg);
                         if ( v7 )
                              eprint("Table: [%s]", v7);
                         eprint("\n");
                    }
                    cllogerr(ErrorNo, ename, arg, v7);
                    exit(1);
               }
               v4 = "locks";
          }
          else
          {
               v4 = "tables";
               if ( TDno )
                    goto LABEL_15;
          }
     }
     v7 = v4;
     goto LABEL_21;
}

void cdberror(int a1, int DBno, int TTno)
{
	dberror(-a1, DBno, TTno);
}
#endif
