#ifndef LERFILE_C
#define LERFILE_C

short aliasexp()
{
     short v1; // si@5
     short *v2; // edx@5
     short v3; // dx@7
     short v4; // dx@9
     RTAB *v5; // eax@12
     RTAB *rt; // [sp+18h] [bp-10h]@3

     if ( symbol == 930 )
     {
          loaderr(7, sym);                      // "unexpected end of line"
          return 0;
     }
     v1 = getrtmem();
     allrtpt(v1, &rt);
     v2 = &symbol;
     if ( symbol != 930 )
     {
          while ( *v2 )
          {
               v3 = loadexp(0, 1);
               if ( !v3 )
                    break;
               rt->field_E = v3;
               if ( symbol != 930 )
               {
                    v4 = getrtmem();
                    if ( !v4 )
                         __assert_fail("tmpidx > 0", "lerfile.c", 0x2Bu, "aliasexp");
                    rt->NextRT = v4;
                    v5 = rt->NextRT ? (RTAB *)&rtarr.TableAddr[20 * (rt->NextRT - 1)] : 0;
                    rt = v5;
               }
               v2 = &symbol;
               if ( symbol == 930 )
                    goto LABEL_16;
          }
          dallrtpt(&rt);
          return 0;
     }
LABEL_16:
     dallrtpt(&rt);
     return v1;
}

int lerfile(int *a1, short Symbol)
{
     short v2; // ST00_2@1
     short v3; // ax@1
     PTAB *pt; // edi@1
     int v6; // eax@6
     short v9; // dx@42
     short v10; // dx@45
     short v14; // [sp+10h] [bp-18h]@6
     TDesc *v15; // [sp+14h] [bp-14h]@8
     RTAB *rt; // [sp+18h] [bp-10h]@6

     v2 = (*a1)++;
     v3 = getptabp(v2);
     pt = PTARR(v3);
     pt->OpCode = 400;
     pt->SrcLineNo = lla;
     symbol = getsym();
     if ( symbol != 2230 )
     {
          if ( symbol == 930 )
               loaderr(40, sym);				// "missing table/alias"
          else
               loaderr(39, sym);				// "invalid table/alias"
          return 0;
     }
     v14 = getrtmem();
     allrtpt(v14, &rt);
     v6 = findtd(sym, -1);
     if ( v6 < 0 )
     {
          loaderr(14, sym);						 // "table not open"
          dallrtpt(&rt);
          return 0;
     }
//---------------------------
	 rt->TTno = v6;
     v15 = &ttab[rt->TTno];
     pt->TABno = v14;
	
	switch (Symbol)
	{
		case 55:							// "replace"
			rt->field_2 = 0x0800u;
			pt->OpCode = 530;
			break;
		case 160:							// "clear"
			rt->field_2 = 0x0020u;
			pt->OpCode = 580;
			break;
		case 300:							// "delete"
			rt->field_2 = 0x0010u;
			pt->OpCode = 570;
			v15->TDlocked |= 0x8000;
			break;
		case 580:							// "getnext"
			rt->field_2 = 0x0002;
			pt->OpCode = 520;
			v15->TDlocked |= 0x0100;
			break;
		case 590:							// "getprev"
			rt->field_2 = 0x0004;
			pt->OpCode = 515;
			v15->TDlocked |= 0x0100;
			break;
		case 600:							// "get"
			rt->field_2 = 0x0001;
            pt->OpCode = 510;
            v15->TDlocked |= 0x0004;
			break;
		case 1220:							// "put"
			rt->field_2 = 0x0008;
            pt->OpCode = 530;
            v15->TDlocked |= 0x0002;
			break;
	}
//---------------	
	symbol = getsym();
    if ( symbol == 790 )                       // "lockr"
     {
          if ( rt->field_2 & 0xFFF8 )
          {
	          loaderr(66, sym);        // "only valid with 'get' and 'getnext' statements"
		      dallrtpt(&rt);
	          return 0;
          }
          rt->field_0 |= 0x400u;
          v15->TDlocked |= 0x80u;
          symbol = getsym();
     }
     else
     {
          if ( symbol == 800 )                  // "lock"
          {
               rt->field_0 |= 0x200u;
               v15->TDlocked |= 1u;
               symbol = getsym();
          }
     }
//-------------------
     if ( !(rt->field_2 & 7) )
     {
          if ( !(rt->field_2 & 0x0800) )	// !replace
               goto LABEL_47;
          v10 = aliasexp();
          if ( v10 )
          {
               rt->NextRT = v10;
               goto LABEL_47;
          }
          dallrtpt(&rt);
          return 0;
     }
     if ( symbol == 70 )                        // all
     {
          rt->field_2 |= 0x100u;
          symbol = getsym();
          goto LABEL_47;
     }
     if ( symbol == 1720 )                      // where
     {
          symbol = getsym();
          v9 = loadexp(1, 1);
          if ( v9 )
          {
               rt->WhereEXP = v9;
               goto LABEL_47;
          }
          dallrtpt(&rt);
          return 0;
     }
LABEL_47:
     if ( symbol != 930 )                       // <CR>
     {
          loaderr(33, sym);			// unexpected symbol
          dallrtpt(&rt);
          return 0;
     }
     dallrtpt(&rt);
     return 1;
}



#endif
