#ifndef FILL_C
#define FILL_C

#include "DBdefs.h"
#include "cl4.h"

int fill(char *Buffer, int count, char value)
{
	int i;
	char *v5;

	//printf("fill: x%08X, Count: %d, Value : x%02X [%c]\n",Buffer, count,(unsigned char)value , value);
	// unsigned in printf stops it extending to 4 bytes
	v5 = Buffer;
	for ( i = count; i; --i )
		*v5++ = value;
	return count;
}

#endif
