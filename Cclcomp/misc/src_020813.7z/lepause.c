#ifndef LEPAUSE_C
#define LEPAUSE_C

int lepause(PTAB *pt)
{
     short v1; // si@2
     short v3; // di@4
     unsigned short ENno; // ecx@6
     ENTAB *v5; // eax@6

	symbol = getsym();
    if ( symbol == 930 )			// pause with no arguments is permissible
		return 1;

	v1 = loadexp(0, 1);
    if ( v1 )
    {
		if ( symbol == 930 )		// <CR>, means only one argument
			v3 = 0;
		else
			v3 = loadexp(0, 1);		// optional second expression. Not defined in Manual
		ENno = getenmem();
        v5 = ENno ? (ENTAB *)&enarr.TableAddr[12 * (ENno - 1)] : 0;
        v5->Dest = v1;
        v5->Src = v3;
        pt->TABno = ENno;
        return 1;
     }
     return 0;	// error exit
}

#endif
