#ifndef PICKNEXT_C
#define PICKNEXT_C

#include <pthread.h>		// for pthread_mutex fns()
#include "DBdefs.h"
#include "cl4.h"

short _picknxt(TDinfo *TDptr, char *WorkArea, short SkipRecs,POS *Pos)
{
	SALLOCBUF *v4;
	SALLOCBUF *i;
	short v6;
	short v8;
	short v9;

	printf("_picknxt( TDptr: x%08X ,WorkArea = %s,SkipRecs = %d, POS = x%08X)\n", TDptr,WorkArea,SkipRecs,Pos);

	if ( TDptr->field_0 & 0x1000 )
	{
		TDptr->field_0 &= 0xEFFFu;
		_imerge(TDptr->TDSallocBuf, TDptr);
	}
  
	if ( Pos )
		v8 = cdbrindex(Pos, 0);
	else
		v8 = TDptr->TDRecSize;

	v9 = 0;
	while ( SkipRecs > v9 )
	{
		v4 = 0;
		for ( i = TDptr->TDSallocBuf; i; i = i->NextSA )
		{
			if ( i->field_1C )
			{
				if ( v4 && (v6 = _cmpkey((char*)&i->field_20, (char*)&v4->field_20, TDptr->TableDefs), v6 >= 0) )
				{
					if ( !v6 && !(((unsigned short)TDptr->field_0 >> 8) & 4) )
					{
						if ( !(((unsigned short)TDptr->field_0 >> 8) & 8) )
							_addtuple((char*)&v4->field_20,(char*) &i->field_20, TDptr->TableDefs);
						i->field_1C = _ifetch((char *)&i->field_20, (DPOS*)&i->field_C, TDptr);
					}
				}
				else
				{
					v4 = i;
				}
			}
		}
		if ( !v4 )
			break;
		tuptor(WorkArea, Pos, (char *)&v4->field_20, TDptr->TableDefs);
		v4->field_1C = _ifetch((char *)&v4->field_20, (DPOS*)&v4->field_C, TDptr);
		++v9;
		WorkArea += v8;
	}
	return v9;
}

#endif
