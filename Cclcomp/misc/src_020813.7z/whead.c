#ifndef WRITEHEAD_C
#define WRITEHEAD_C

#include "DBdefs.h"
#include "cl4.h"
//#define _LARGEFILE64_SOURCE
//void DumpPageTable(HDRTABLE* Table);


void _whead(DBinfo *DBptr, short IndexOff, int PageNo, short Depth)
{
	int v4;
	HDRTABLE v5;

    //printf("_whead(DBptr: x%08X,IndexOff: x%04X, PageNo: %d, Depth : %d)\n" ,DBptr,IndexOff, PageNo, Depth);

	ltoms(&v5.PageNo, PageNo);
	itoms(&v5.Depth, Depth);
	v4 = lseek64(DBptr->DBfilehandle, 12 * IndexOff + DBptr->DBtableaddress, 0);
	if ( v4 < 0 || write(DBptr->DBfilehandle, &v5, 6u) != 6 )
		derror(27, DBptr, 0);
}

#endif
