#ifndef FREELST_C
#define FREELST_C

#include "DBdefs.h"
#include "cl4.h"

void* frelst(void *ptr, void *a2)
{
	void *v2; // edx@1

	//printf("frelst(x%08X,x%08X)\n" ,ptr,a2);

	v2 = ptr;
	while ( v2 && v2 != a2 )
	{
		v2 = nfree(v2, *(char**)v2);  // stop defreferencing nonsense
	}
	return v2;
}


#endif
