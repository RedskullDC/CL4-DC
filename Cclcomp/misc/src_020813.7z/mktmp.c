#ifndef MAKE_TEMP_C
#define MAKE_TEMP_C

#include "DBdefs.h"
#include "cl4.h"

int _mktmp(int TDno)
{
    char *v1; // eax@2
    short v2; // esi@4
    char Dest[128]; // [sp+10h] [bp-A8h]@4

    if ( !cdbtmpdir[0] )
    {
        v1 = getevar("CLTMPDIR");
        cdbcpystr(cdbtmpdir, v1, 0);
        if ( !cdbtmpdir[0] )
            cdbcpystr(cdbtmpdir, defcdbtdir, 0);
    }
    cdbcpystr(Dest, cdbtmpdir, "/tXXXXXX", 0);
    v2 = mkstemp(Dest);
    unlink(Dest);
    return v2;
}

#endif

