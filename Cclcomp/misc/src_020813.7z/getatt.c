#ifndef GETATTRIB_C
#define GETATTRIB_C

#include "DBdefs.h"
#include "cl4.h"

bool _chkname(DBinfo *DBptr,TD0REC *Workarea)
{
	short TDno;
	TDinfo *TDptr;

	//printf("_chkname( DBptr: x%08X, TD0REC: x%08X)\n", DBptr, Workarea);
	for ( TDno = 0; ; TDno++)
	{
		if ( TDno > 2 )
			return false;
		if ( cmpstr(Workarea->TableName, sname_0[TDno]) )// System  Table names: "tables","fields","locks"
			break;
	}
	if ( TDno > 2 || TDno == 2 && DBptr->DBvflag <= 3 )	// legacy support for old CL3 dbases
		return false;

	//printf("_chkname: TDno = %d",TDno);
	TDptr = def_1[TDno];
	Workarea->IndexOff = TDptr->TDindexOff;
	Workarea->KeyFlags = TDptr->field_0 & 0xD;
	Workarea->HalfPageSize = DBptr->DBpgsize / 2;
	Workarea->RecPlusDBpagesize = TDptr->TDRecSize + DBptr->DBpgsize;
	return true;
}

DBinfo* _getattrib(int DBno, char *TableName,TD0REC *WorkArea)
{
	DBinfo *DBptr; // esi@1
	DBinfo *result; // eax@1

	//printf("_getattrib( DBno: x%04X (%3d),TableName = %s, TD0REC: x%08X)\n", DBno, DBno,TableName, WorkArea);

	DBptr = _chkdb(DBno);
	result = 0;
	if ( DBptr )
	{
		cdbcpystr(WorkArea->TableName, TableName, 0);
		if ( !_chkname(DBptr, WorkArea) && DBptr )   // if chkname returns 1, Workarea held a system table name, "tables","fields" or "locks"
		{											 // _chkname also sets fields in WorkArea.
			do
			{
				_chktd(0)->TDDBinfo = DBptr;
				if ( getr(0, (char*)WorkArea, My_pos) > 0 )	//if > 0, we found it. return DBptr that it was in
					break;
				DBptr = DBptr->DBnextDB;
			}
			while ( DBptr );
		}
		result = DBptr;
	}
	return result;
}

#endif
