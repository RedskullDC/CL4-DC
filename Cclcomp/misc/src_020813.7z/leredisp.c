#ifndef LEREDISP_C
#define LEREDISP_C

int leredisp()
{
     short v0; // ax@1
     int v1; // edi@1
     int v3; // edx@5
     short v4; // dx@7
     int result; // eax@11
     RDTAB *v6; // eax@14
     RDTAB *rd; // [sp+18h] [bp-10h]@1
	 register short RDno;

	v0 = getrdmem();
    v1 = (unsigned short)v0;
    allrdpt(v0, &rd);
	while ( symbol != 930 )				// no arguments is OK??
    {
		if ( !symbol )
        {
			dallrdpt(&rd);
            return 0;
		}
        if ( symbol != 2230 )            // variable/table name
		{
			loaderr(33, sym);                     // unexpected symbol
		    return 0;
		}
		if ( nxtch() == '.' || (v3 = findtd(sym, -1), v3 <= 0) )
        {
			v4 = loadexp(0, 1);			// This was a normal variable
            if ( !v4 )
			{
				dallrdpt(&rd);
                return 0;
			}
            rd->field_2 = v4;
		}
        else
        {
			rd->TTno = v3;				// This was a field in a table
            symbol = getsym();
		}
			//------
        if ( symbol != 930 )             // Can have multiple redisplayed records/fields all chained
        {	
			RDno =  getrdmem();			//***RDno can alter rd pointer if realloc occurs!
            rd->NextRD = RDno;
            v6 = rd->NextRD ? (RDTAB *)&rdarr.TableAddr[12 * (rd->NextRD - 1)] : 0;
            rd = v6;
		}
	}
	//( symbol == 930 )
	dallrdpt(&rd);
	return v1;	// exit_success			// result == first variable in chain
}

#endif
