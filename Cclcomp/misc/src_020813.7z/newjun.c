#ifndef NEWJUNC_C
#define NEWJUNC_C

#include "DBdefs.h"

EXPR* newjunc(EXPR *a1,short Operator,EXPR *a3)
{
	EXPR *result; // eax@1

	result = a3;
	if ( a1 )
	{
		result = a1;
		if ( a3 )
		{
			result = (EXPR *)alloc(12u, 0);
			result->NextEXPR = a1;
			result->PrevEXPR = a3;
			result->Operator = Operator;
		}
	}
	return result;
}
#endif

