#ifndef LOADENT_C
#define LOADENT_C

#include <stdio.h>
#include <stdarg.h>			// for var args stuff
#include <ctype.h>          // for islower() and toupper() functions
#include "DBdefs.h"
#include "cl4.h"

short fixbname(char *a1, char *a2)
{
     cdbcpystr(a1, a2, 0);
     a1[20] = 0;	// max buffer size == 21
     return strlen(a1) + 1;		// include the \0 terminator byte
}

FLDdesc* getvarname(char *VariableName)
{
     int FieldNo;
     FLDdesc *fld;

     FieldNo = Nvars - 1;
     fld = &ttab->TTfields[FieldNo];
     while ( FieldNo > 20 ) // <=20 are pre-defined system vars
     {
        if ( !strcmp(VariableName, fld->FLDname) ) // 0 == match
			return fld;
        --fld;
        --FieldNo;
     }
     return 0;
}

int lemaint(BTAB *btb)
{
     int TDno; // eax@5
     TDesc *TTptr; // esi@10
     FLDdesc *fld; // eax@10
     char *v7; // edx@11
     char *v8; // ecx@11
     ONESC *v12; // esi@36
     short v16; // [sp+1Ch] [bp-5Ch]@30
     char v17[32]; // [sp+20h] [bp-58h]@36

	symbol = getsym();
    if ( symbol != 2230 )                   // expecting a string literal. error if not
    {
		if ( symbol == 930 )
			loaderr(40, sym);               // missing table/alias
		else
			loaderr(39, sym);               // invalid table/alias
		return 0;
	}

	TDno = findtd(sym, -1);
    if ( TDno < 0 )
    {
		loaderr(14, sym);					// "table not open"
		return 0;
    }
	ttab[TDno].TDlocked |= 0x0007u;
    btb->TTno = TDno;

	symbol = getsym();
    if ( symbol != 180 && symbol != 330 || (symbol = getsym(), symbol != 2230) )// 180 = ",", 330="/", 2230 = string literal
		goto LABEL_26;

    TTptr = &ttab[TDno];
    fld = getvarname(sym);			// maintain code can be in a variable????  *undocumented*
    if ( fld )
    {
        v7 = (char *)fld->FLDdata;
		v8 = (char *)fld->FLDdata;
    }
    else
    {
		v8 = sym;
		v7 = sym;
	}
     
	while (*v7)
	{
		switch (*v7)
		{
			case 'a':
			case 'c':
				TTptr->TDlocked |= 0x0006;
				break;
			case 'd':
				TTptr->TDlocked |= 0x8004;
				break;
			case 'v':
				TTptr->TDlocked |= 0x0004;
				break;
			default:					// error!!!
				loaderr(42, sym);		// invalid maintain mode
				return 0;
				break;
		}
		v7++;
	}
    cdbcpystr(btb->Maintain, v8, 0);           // copy maintain codes to BTAB
     
	symbol = getsym();

LABEL_26:
    if ( !btb->Maintain[0] )
		cdbcpystr(btb->Maintain, "vac", 0);   // default = view, add, change if no codes selected
     
	while ( symbol == 970 || symbol == 1000 )     // 970="on_delete", 1000="on_exception"
    {
		v16 = symbol;					// save for check below
		symbol = getsym();
        if ( symbol != 2230 )           // string literal {block name}
		{
			if ( symbol == 930 )		// newline
				loaderr( 2, sym);		// missing block name
			else
				loaderr(33, sym);		// unexpected symbol
			return 0;
		}
		v12 = (ONESC *)getmem(16);
        v12->BlockName = getmem(fixbname(v17, sym));
        cdbcpystr(v12->BlockName, v17, 0);
        if ( v16 == 970 )               // "on_delete"
			btb->On_delete = v12;
		else
			btb->On_excep = v12;        // "on_exception
        symbol = getsym();
	}
    return 1;							// exit success
}

short lehdtxt(void)
{
     short v0; // si@1
     short result; // ax@5
     XTAB *xtab; // [sp+Ch] [bp-Ch]@1

     v0 = getxtmem();
     allxtpt(v0, &xtab);
     if ( getadwid(xtab) && getcol(xtab, 4) && getrow(xtab, 4) && getprmpt(xtab) )
     {
          dallxtpt(&xtab);
          result = v0;
     }
     else
     {
          dallxtpt(&xtab);
          result = 0;
     }
     return result;
}

int legetf()
{
	signed int v0; // edi@0
    char *v1; // eax@6
    DBase *DTptr; // esi@8
    char *v3; // eax@13
    int v7; // eax@23
    signed int v9; // eax@31
    TDesc *TTptr; // edx@41
    char *arg; // [sp+30h] [bp-B8h]@1
    char *DBname; // [sp+30h] [bp-B8h]@8
    signed int TTno; // [sp+34h] [bp-B4h]@19
    signed int Lock; // [sp+38h] [bp-B0h]@19
    signed int DBno; // [sp+3Ch] [bp-ACh]@8
    char v20[128]; // [sp+40h] [bp-A8h]@13

    arg = 0;
    symbol = getsym();
    if ( symbol == 930 )
	{
		loaderr(7, sym);		// "unexpected end of line"
        return 0;
	}
    /*if ( dbrename )		// work this out later
    {
         if ( !dbarray )
              dbarray = camake(dbrename, ',');
         arg = checkdbrename(sym);
    }*/
    v1 = arg;
    if ( !arg )
         v1 = sym;
    DBname = v1;
    DTptr = dtab;
    DBno = 0;
    while ( DBno < no_dtabs && !cmpbuf(DBname, DTptr->FullDBname, syml + 1) )
    {
         ++DBno;
         ++DTptr;
    }

	if ( DBno == no_dtabs )
    {
        v3 = chkpath(DBname, 0, "CLDPATH", 0, 384);
        cdbcpystr(v20, v3, 0);
        DBno = cldbopen(v20, 0);
        if ( DBno < 0 )
        {
             eprint("can't open database - %s\n", DBname);
             return 0;
		}
		/*  Remove Demo check nonsense
		v4 = checkForDemo(DBno, DBname);      // returns 0 if this is a demo version
        v5 = 0;
        if ( !v4 )
			return v5;
		*/
        newdtab();
        if ( DBno >= no_dtabs )
			__assert_fail("db < no_dtabs", "legetf.c", 106, "legetf");

		dtab[DBno].FullDBname = mstrcpy(sym, 0);
        dtab[DBno].DBno = DBno;
	}
    
	Lock = 0;
    TTno = 0;
    symbol = getsym();
    if ( symbol == 930 )
    {
		loaderr(7, sym);	// "unexpected end of line"
        return 0;
    }
    while ( symbol != 930 )
    {
		v7 = tdopen(DBno, sym);
        v0 = v7;
        if ( v7 < 0 )
		{
		    fprintf(stderr, "can`t identify - %s err=%d\n", sym, v7);
			fflush(stderr);
			symbol = getsym();
		    if ( symbol != 180 || (symbol = getsym(), symbol != 2230) )
				continue;
		    symbol = getsym();
			continue;
		}
        if ( no_ttabs - 1 <= v7 )
		{
			newttab();
            if ( v0 >= no_ttabs )
				__assert_fail("td < no_ttabs", "legetf.c", 132, "legetf");

		}
        cdbcpystr(ttab[v0].TableName, sym, 0);
        ttab[v0].DBnumber = DBno;
        v9 = TTno;
        if ( !TTno )
			v9 = v0;
        TTno = v9;
        symbol = getsym();
        if ( symbol == 180 )             // ',' Comma
        {
			symbol = getsym();
            if ( symbol == 2230 )
            {
				cdbcpystr(ttab[v0].TableAlias, sym, 0);
                symbol = getsym();
            }
		}
        if ( symbol == 800 )             // "lock"
        {
			Lock = 1;
			symbol = getsym();
		}
	}
//============================
LABEL_40:
    if ( Lock )
    {
		for ( TTptr = &ttab[TTno]; TTno <= v0; ++TTptr )
        {
			TTptr->TDlocked |= 0x0040u;	// bit 6 = locked indicator
            ++TTno;
        }
    }
    return 1;
}


int leincl()
{
	char *v0; // eax@3
    char *IncludeFileName; // esi@3
    INCLUDE *incl; // edi@6
    FILE *InclFP; // [sp+14h] [bp-14h]@3
    int v7; // [sp+18h] [bp-10h]@1

    v7 = 0;
    symbol = getsym();
    if ( symbol == 2220 )
    {
		v0 = chkpath(sym, incl_dir, "CLIPATH", 0, 256);
        IncludeFileName = mstrcpy(v0, 0);
        InclFP = fopen64(IncludeFileName, "r");
        if ( InclFP )
        {
			gotonl();
            incl = (INCLUDE *)mmalloc(0x14u);
            incl->FileName = mstrcpy(IncludeFileName, 0);
            FileTree->field_10 = incl;
            FileTree->LastLine = ll;
            ll = -1;
            --lla;
            incl->field_C = FileTree;
            FileTree = incl;
            MainFile = InclFP;
            incl->PrevFILE = InclFP;			// return 0 = success.
            return v7;
         }
		 loaderr(72, sym);						// "can't open include file"
     }
     else
     {
		loaderr(71, sym);						// "invalid 'include' filename"
     }
     return 1;                                  // error exit
}

int loadent(char *FullPathName)
{
	PTAB *ptb; // edi@59
	PTAB *ptb2; // edi@104
	BTAB *btb;
	BTAB *v34; // edi@110
	
	char *v1; // eax@1
	char *v2; // edx@5
	char *v10; // eax@15
	size_t v23; // esi@62
	char *v24; // eax@65
	char *ErrorStr; // eax@84
	short LineNo; // si@101
	short v35; // si@110

	TYPE24** v53; // [sp+54h] [bp-444h]@101
	short NumScreens; // [sp+58h] [bp-440h]@101
	short NumFormats; // [sp+5Ch] [bp-43Ch]@101
	short count; // [sp+60h] [bp-438h]@62
	short CurrBTno; // [sp+60h] [bp-438h]@92
	char *i; // [sp+68h] [bp-430h]@1
	char *v61; // [sp+68h] [bp-430h]@7
	char *v62; // [sp+68h] [bp-430h]@77
	int a1;
	char command[256]; // [sp+2F0h] [bp-1A8h]@24
	char FileName[168]; // [sp+3F0h] [bp-A8h]@1

	cdbcpystr(FileName, FullPathName, ".ent", 0);
	v1 = &FileName[lenstr(FileName) - 1];
	for ( i = v1; FileName < i && *i != '/'; --i )
		;
	v2 = i + 1;
	if ( i == FileName )
		v2 = i;
	v61 = v2;

	// deleted the pre-processing stuff.

	MainFile = fopen64(FileName, "r");
	if ( lenstr(v61) > 140u || !MainFile )
	{
		eprint("ent file not found - %s\n", FileName);
		exit(1);
	}
	FileTree = (INCLUDE *)mmalloc(0x14u);
	FileTree->FileName = mmalloc(lenstr(FileName) + 1);
	cdbcpystr(FileTree->FileName, FileName, 0);
	FileTree->PrevFILE = MainFile;
	ltab = mmalloc(0);
	itab = mmalloc(0);
	newltab();
	lt = ltab;
	it = itab;
	a1 = 0;	// a1 is used to count NumBTABs

	loadvars();	// initialise system vars

	symbol = getsym();
	while ( symbol && !comp_abort )
	{
		while ( symbol && symbol != 820 && !comp_abort )	//820 = "{"  start of block token
		{
			if ( symbol == 660 )		// include directive. Only valid item outside of a block construct.
				leincl();				// leincl() returns pointing at last <CR> after the include statement
			if ( symbol != 930 )
				loaderr(33, sym);		// unexpected symbol
			symbol = getsym();
		}
		if ( symbol )
		{
			if ( !comp_abort )
			{
				leblock(&a1);	// returns with symbol pointing at the "}" at the end of the block (token == 1360)

				while ( symbol && symbol != 930 )
					symbol = getsym();
			}
		}
	}
	fclose(MainFile);

// ENT file has now been read with no syntax errors, or we struck an error (or 2...)
// Lets go ahead and check it for logical errors, and link all the tables etc.

	PTARR(getptabp(a1++))->OpCode = 950;	// add two 950's to signify end of file
	PTARR(getptabp(a1))->OpCode = 950;

	if ( !comp_errs )
	{
		a1 = 0;
		while( (ptb = PTARR(getptabp(a1)), ptb->OpCode))
		{
			//DumpPTAB(ptb);
			if ( ptb->OpCode == 720 && ptb->TABno )	// 720 = do block_name
			{
				v23 = (signed short)(lenstr(&strarr.StringTable[ptb->TABno - 1]) + 1);
				btb = btab;
				count = 0;
				while ( no_btabs > count )
				{
					v24 = ptb->TABno ? &strarr.StringTable[ptb->TABno - 1] : 0;
					if ( cmpbuf(v24, btb->BlockName, v23) )
					{
						ptb->Operand = count;
						break;
					}
					++count;
					++btb;
				}
				if ( no_btabs == count )
				{
					ErrorStr = ptb->TABno ? &strarr.StringTable[ptb->TABno - 1] : 0;
					loaderr(68,ErrorStr);	// 'do/format' block name not found"
				}
			}
			else if ( ptb->OpCode == 700 && ptb->TABno )	// 700 = goto
			{
				v62 = &strarr.StringTable[ptb->TABno - 1];		// 700 goto handler. 
				for ( lt = ltab; *lt; ++lt )	// Program Label Tables
				{
					if ( cmpbuf(v62, (*lt)->LabelName, (*lt)->NameLen ))
					{
						//printf("loadent : 1171 v62 = %s, LabelName = %s, len = %d\n",v62, (*lt)->LabelName, (*lt)->NameLen);
						ptb->Operand = (*lt)->field_2;
						ptb->TABno = 0;
						if ( *lt )	// We found a match before end of the list
							goto LABEL_91;
						break;
					}
				}
				ErrorStr = ptb->TABno ? &strarr.StringTable[ptb->TABno - 1] : 0;
				cdbcpystr(sym, ErrorStr, 0);
				loaderr(11, sym);	//"label not found"
			}
			else if ( ptb->OpCode == 1 && ptb->TABno )	// 1 = accept field, look for a field specific escape
				chkoelist(*(ONESC **)&xtarr.TableAddr[52 * ptb->TABno - 28]);
LABEL_91:
			a1++;
		}

// check for global block escapes 
		chkoelist(oelist);
// lastly, check for block specific stuff: On_exit, On_entry, On_excep, On_delete
		btb = btab;
		CurrBTno = 0;
		if ( no_btabs <= CurrBTno )
			return comp_errs;
		while ( 1 )
		{
			if ( btb->BlockName[0] )
			{
				if ( btb->StartLine || btb->EndLine )
				{
					v53 = &btb->TYPE24;
					btb->TYPE24 = (TYPE24*)mmalloc(8u);
					LineNo = btb->StartLine;
					NumScreens = 0;
					NumFormats = 0;
					while ( PTARR(getptabp(LineNo))->OpCode != 999 )	// 999 == end
					{
						if ( !*v53 )
							*v53 = (TYPE24*)mmalloc(8u);
						(*v53)->PT_start = LineNo;
						
						while ( (ptb2 = PTARR(getptabp(LineNo)), ptb2->OpCode != 950)) // break;
						{
							if ( ptb2->OpCode == 600 ) // format
								NumFormats++;
							LineNo++;
						}
						(*v53)->PT_end = LineNo;
						NumScreens++;
						v53 = &(*v53)->NextT24;
						LineNo++;
					}

					btb->Scrs = NumScreens;
					btb->fmts = NumFormats;
					if ( btb->On_delete )
					{
						v34 = btab;
						v35 = 0;
						while ( no_btabs > v35 )
						{
							if ( v34->BlockName[0] && cmpbuf(v34->BlockName, btb->On_delete->BlockName, lenstr(v34->BlockName) + 1))
							{
								btb->On_delete->BlockNo = v35;
								break;
							}
							++v35;
							++v34;
						}
						if ( no_btabs == v35 )
							loaderr(75, btb->On_delete->BlockName);	// 'on_delete' block name not found
					}
					
					if ( btb->On_exit )
					{
						v34 = btab;
						v35 = 0;
						while ( no_btabs > v35 )
						{
							if ( v34->BlockName[0] && cmpbuf(v34->BlockName, btb->On_exit->BlockName, lenstr(v34->BlockName) + 1))
							{
								btb->On_exit->BlockNo = v35;
								break;
							}
							++v35;
							++v34;
						}
						if ( no_btabs == v35 )
							loaderr(79, btb->On_exit->BlockName);	// 'on_exit' block name not found
					}
					
					if ( btb->On_excep )
					{
						v34 = btab;
						v35 = 0;
						while ( no_btabs > v35 )
						{
							if ( v34->BlockName[0] && cmpbuf(v34->BlockName, btb->On_excep->BlockName, lenstr(v34->BlockName) + 1))
							{
								btb->On_excep->BlockNo = v35;
								break;
							}
							++v35;
							++v34;
						}
						if ( no_btabs == v35 )
							loaderr(80, btb->On_excep->BlockName); //'on_exception' block name not found
					}

					if ( btb->On_entry )
					{
						v34 = btab;
						v35 = 0;
						while ( no_btabs > v35 )
						{
							if ( v34->BlockName[0] && cmpbuf(v34->BlockName, btb->On_entry->BlockName, lenstr(v34->BlockName) + 1))
							{
								btb->On_entry->BlockNo = v35;
								break;
							}
							++v35;
							++v34;
						}
						if ( no_btabs == v35 )
							loaderr(80, btb->On_entry->BlockName); //'on_exception' block name not found
					}
				}
				else
					loaderr(68, btb->BlockName);	// 'do/format' block name not found
			}
			CurrBTno++;
			btb++;
			if ( no_btabs <= CurrBTno )
				return comp_errs;
		}
	}	
	if ( symbol )
	{
		fwrite("too many errors - aborting\n", 1u, 0x1Bu, stderr);
		fflush(stderr);
	}
	return comp_errs;
}

#endif
