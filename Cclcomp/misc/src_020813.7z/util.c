#ifndef UTIL_ROUTINES_C
#define UTIL_ROUTINES_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

void DumpPTAB(PTAB* ptb)
{
	printf("ptb->SrcLineNo	= 0x%04X  (%4d)\n",ptb->SrcLineNo,ptb->SrcLineNo);
	printf("ptb->OpCode     = 0x%04X  (%4d)\n",ptb->OpCode,ptb->OpCode);
	printf("ptb->Operand	= 0x%04X  (%4d)\n",ptb->Operand,ptb->Operand);
	printf("ptb->TABno      = 0x%04X  (%4d)\n",ptb->TABno,ptb->TABno);

}


#endif
