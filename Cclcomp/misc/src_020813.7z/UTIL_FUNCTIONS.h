#ifndef UTILFNS_H
#define UTILFNS_H

#include "DBdefs.h"
#include "cl4.h"

void Dump1FLD(FLDdesc *FLD);		// Just dump 1 Field Descriptor
void DumpTTFLD(FLDdesc *FLD);
void DumpTTptr(TDesc* TT, bool ShowFields);
void DumpTDptr(TDinfo* TD,bool ShowTDef);
void DumpTDefptr(TDef* TDef);
void DumpBlock(char* Buffer, int NumBytes);
void DumpEXPR(EXPR* Expr);
void DumpJUNC(EXPR* Expr);
void DumpIndexPage(char* Buffer);
void DumpPOS(POS* Pos);
void DumpDBptr(DBinfo* DB);
void DumpPageTable(HDRTABLE* Table);

#include "UTIL_FUNCTIONS.c"

#endif
