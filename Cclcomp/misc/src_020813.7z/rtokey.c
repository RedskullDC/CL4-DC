#ifndef RTOKEY_C
#define RTOKEY_C

#include "DBdefs.h"
#include "cl4.h"

int rtokey(char *KeyBuf, char *Src, POS *Pos, TDef *TDefP)
{
	TDef *tdef;
	short TDFtype;
	size_t v6;
	short v7;
	int v8;
	int v9;
	short v10;
	short v11;
	char *Dest;

	int localsize;
	char local[128];	// for testing

	//printf("rtokey(KeyBuf: x%08X,Src: x%08X,POS: x%08X, TDef: x%08X)\n" ,KeyBuf,Src,Pos,TDefP);

	tdef = TDefP;
	Dest = KeyBuf;
	if ( TDefP->TDFentry )
	{
		for ( TDFtype = TDefP->TDFtype; TDFtype & 1; TDFtype = tdef->TDFtype )	// & 1 == Keyfield.
		{
			if ( Pos )	// Has a re-position record been supplied?
			{
				v7 = cdbrindex(Pos, tdef->TDFentry);
				v8 = v7;
				if ( v7 >= 0 )
				{	
					v10 = tdef->TDFtype;
					if ( v10 & 0x08 )  //???
					{
						if ( v10 & 0x02 )
							v11 = _fwidth(&Src[v8], tdef->TDFsize, tdef->TDFtype);
						else
							v11 = tdef->TDFsize;
						v9 = cpytuc(Dest, &Src[v8], v11);
					}
					else
					{
						v9 = xtodom(Dest, tdef->TDFsize, tdef->TDFtype, &Src[v8]);
						/*DumpBlock(Dest, tdef->TDFsize);
						printf("rtokey: v9 = %d\n",v9);
						localsize = Lxtodom(local, tdef->TDFsize, tdef->TDFtype, &Src[v8]);
						DumpBlock(local, tdef->TDFsize);
						printf("rtokey: localsize = %d\n",localsize);*/

					}
				}
				else
				{
					v9 = cdbfclear(Dest, tdef->TDFsize, tdef->TDFtype);
				}
				Dest += v9;
			}
			else	// No Pos specified, just place in buffer at normal position.
			{
				if ( TDFtype & 2 )	// String field variable
					v6 = (size_t)_fwidth(Src, tdef->TDFsize, TDFtype);
				else
					v6 = tdef->TDFsize;
				Dest += cpybuf(Dest, Src, v6);
				Src += tdef->TDFsize;
			}
			tdef++;
			if ( !tdef->TDFentry )
				break;
		}
	}
	return Dest - KeyBuf;
}

#endif
