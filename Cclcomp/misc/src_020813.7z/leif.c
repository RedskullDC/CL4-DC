#ifndef LEIF_C
#define LEIF_C

int leif(int *a1)
{
     short v1; // ST00_2@4
     short v2; // di@4
     ITAB *v8; // eax@29
     short v9; // ST00_2@30
     unsigned short v10; // edi@30
     PTAB *v11; // eax@30
     short v12; // ST00_2@37
     short v13; // di@37
     short v19; // ST00_2@63
     unsigned short PTno; // edi@63
     PTAB *v21; // eax@63
     ITAB *v24; // eax@92
     PTAB *ptb; // [sp+48h] [bp-10h]@8

	if ( &itab[no_itabs] <= it )
    {
		newitab();
        if ( it >= &itab[no_itabs] )
			__assert_fail("it < max_it", "leif.c", 36, "leif");
	}
    v1 = (*a1)++;
    v2 = getptabp(v1);
    it->field_C = 1;
    it->PTno = v2;
    ++it;
    if ( &itab[no_itabs] <= it )
    {
		newitab();
        if ( it >= &itab[no_itabs] )
			__assert_fail("it < max_it", "leif.c", 47, "leif");
	}
    do
		symbol = getsym();
	while ( symbol == 930 );
    
	allptpt(v2, &ptb);
    ptb->OpCode = 300;                         // OpCode for "if"
    ptb->SrcLineNo = lla;
    ptb->TABno = loadexp(1, 1);
    dallptpt(&ptb);
    if ( !ptb->TABno || symbol != 930 )
    {
		while ( symbol )
        {
			if ( ptb->TABno )
				loaderr(33, sym);
			symbol = getsym();
            if ( comp_abort )
				break;
			if ( symbol == 930 )
				goto LABEL_15;
		}
        return 0;
	}
LABEL_15:
    while ( symbol == 930 )
		symbol = getsym();
    
	if ( symbol == 370 )                       // elsif
	{
		while ( 1 )
        {
LABEL_29:
			v8 = it - 1;
            it = v8;
            if ( v8->field_4 )
            {
				loaderr(9, sym);				// "unexpected elsif"
	            return 0;
			}
            v8->field_8 = 1;
            v9 = (*a1)++;
            v10 = getptabp(v9);
            v11 = 0;
            if ( v10 )
				v11 = (PTAB *)&ptarr.TableAddr[8 * (v10 - 1)];
			v11->OpCode = 700;	// goto
            it->PTABno = v10;
            if ( it->PTno )
            {
				*(short *)&ptarr.TableAddr[8 * it->PTno - 4] = *(short *)a1;
                it->PTno = 0;
			}
            ++it;
            if ( &itab[no_itabs] <= it )
            {
				newitab();
                if ( it >= &itab[no_itabs] )
 					__assert_fail("it < max_it", "leif.c", 100, "leif");
			}
            v12 = (*a1)++;
            v13 = getptabp(v12);
            it->field_C = 1;
            it->PTno = v13;
            ++it;
            if ( &itab[no_itabs] <= it )
            {
				newitab();
                if ( it >= &itab[no_itabs] )
					__assert_fail("it < max_it", "leif.c", 110, "leif");
			}
               
			do
				symbol = getsym();
			while ( symbol == 930 );

            allptpt(v13, &ptb);
            ptb->OpCode = 300;
            ptb->SrcLineNo = lla;
            ptb->TABno = loadexp(1, 1);
            dallptpt(&ptb);

            if ( !ptb->TABno )
				break;
			if ( symbol != 930 )
				break;
LABEL_48:
			while ( symbol == 930 )
				symbol = getsym();

			if ( symbol != 370 )             // elsif
            {
				if ( symbol != 360 && symbol != 390 && symbol )// 360 = else, 390 = endif
                {
					do
                    {
						loadstate(a1);
                        if ( comp_abort )
							return 0;
							  
						while ( symbol == 930 )
							symbol = getsym();
					}
					while ( symbol != 370 && symbol != 360 && symbol != 390 && symbol );
				}
                if ( symbol != 370 )        // 370 = elsif, 360 = else
					goto LABEL_62;
			}
		}
        while ( symbol )
        {
			if ( ptb->TABno )
				loaderr(33, sym);
			symbol = getsym();
            if ( comp_abort )
				break;
			if ( symbol == 930 )
				goto LABEL_48;
		}
        return 0;
	}
    if ( symbol != 360 && symbol != 390 && symbol )// 360 = else
    {
		do
        {
			loadstate(a1);
            if ( comp_abort )
				return 0;
			while ( symbol == 930 )
				symbol = getsym();
		}
        while ( symbol != 370 && symbol != 360 && symbol != 390 && symbol );
	}
    if ( symbol == 370 )			// 370 = "elsif"
		goto LABEL_29;
LABEL_62:
	if ( symbol == 360 )			// 360 = "else"
    {
		--it;
        it->field_4 = 1;
        v19 = (*a1)++;
        PTno = getptabp(v19);

		v21 = PTno ? (PTAB *)&ptarr.TableAddr[8 * (PTno - 1)] : 0;
		v21->OpCode = 700;	// goto
        it->PTABno = PTno;
        if ( it->PTno )
        {
			*(short *)&ptarr.TableAddr[8 * it->PTno - 4] = *(short *)a1;
            it->PTno = 0;
		}
        ++it;
        if ( &itab[no_itabs] <= it )
        {
			newitab();
            if ( it >= &itab[no_itabs] )
	             __assert_fail("it < max_it", "leif.c", 160, "leif");
		}
          
		do
			symbol = getsym();
		while ( symbol == 930 );

        while ( symbol != 390 && symbol )		// 390 = "endif"
        {
			loadstate(a1);	// recursion?
            if ( comp_abort )
				return 0;
			while ( symbol == 930 )
				symbol = getsym();
		}
	}
    if ( symbol == 390 )
    {
		symbol = getsym();
        --it;
        if ( it->field_C != 1 )
        {
			loaderr(5, sym);			// "endif without if"
            return 0;
		}
        if ( itab < it && *((int *)it - 2) )
        {
			if ( it->field_4 )
            {
				it->field_4 = 0;
                if ( it->PTABno )
                {
					*(short *)&ptarr.TableAddr[8 * it->PTABno - 4] = *(short *)a1;
                    it->PTABno = 0;
				}
			}
            if ( it->PTno )
            {
				*(short *)&ptarr.TableAddr[8 * it->PTno - 4] = *(short *)a1;
                it->PTno = 0;
			}
            if ( it->PTABno )
            {
				*(short *)&ptarr.TableAddr[8 * it->PTABno - 4] = *(short *)a1;
                it->PTABno = 0;
			}
            for ( --it; it->field_8; --it )
            {
				v24 = it;
                it->field_4 = 0;
                v24->field_8 = 0;
                if ( it->PTABno )
                {
					*(short *)&ptarr.TableAddr[8 * it->PTABno - 4] = *(short *)a1;
                    it->PTABno = 0;
				}
                if ( itab >= it )
					break;
				if ( !*((int *)it - 2) )
					break;
			}
		}
        else
        {
			if ( it->field_4 )
            {
				it->field_4 = 0;
                if ( it->PTABno )
                {
					*(short *)&ptarr.TableAddr[8 * it->PTABno - 4] = *(short *)a1;
                    it->PTABno = 0;
				}
			}
            else
            {
				if ( it->PTno )
                {
					*(short *)&ptarr.TableAddr[8 * it->PTno - 4] = *(short *)a1;
                    it->PTno = 0;
				}
			}
		}
	}
    return 1;
}

#endif
