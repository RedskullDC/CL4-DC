#ifndef LEDEFINE_C
#define LEDEFINE_C

int ledefine(bool local)
{
     char *v1; // eax@22
     char *v5; // esi@44
     char *v6; // esi@51
     short v7; // ax@53
     short v9; // ax@65
     int v10; // edi@67
     int v12; // edi@70
     FLDdesc *fld; // esi@72
     signed short v15; // ax@86
     int v16; // eax@97
     short v17; // ax@101
     double v18; // fst6@103
     short v19; // ax@104
     char VarType; // [sp+27h] [bp-221h]@7
     short ArraySize; // [sp+28h] [bp-220h]@8
	 int VarNameLen;
     int MemSize; // [sp+30h] [bp-218h]@7
     int MemSizea; // [sp+30h] [bp-218h]@65
     int StringVar; // [sp+34h] [bp-214h]@7
     int InitVar; // [sp+38h] [bp-210h]@7
     bool TypeError; // [sp+3Ch] [bp-20Ch]@1
     char s[16]; // [sp+40h] [bp-208h]@5
     char nptr[256]; // [sp+50h] [bp-1F8h]@15
     char VarName[56]; // [sp+150h] [bp-F8h]@7
     char v37[80]; // [sp+1C0h] [bp-88h]@8

	TypeError = false;
    symbol = getsym();
    
	while ( symbol != 930 )
    {
		if ( symbol != 2230 )	// not a table/record/variable name
        {
			loaderr(8, sym);	// "invalid field name or number"
		    return 0;
        }
        if ( local )
			sprintf(s, "#%d", cur_block);	// local var, append block# to differentiate
        else
			s[0] = 0;
        cdbcpystr(VarName, sym, s, 0);
        StringVar	= 0;
        InitVar		= 0;
        ArraySize	= 0;	// Variable type defaults to C20, non-array
        VarType		= 'C';
        MemSize		= 20;

// We now have variable name, check for array type or "eq" <equate>
        symbol = getsym();
        if ( symbol == 740 )                  // "["  array 
        {
			symbol = getsym();
            cdbcpystr(v37, sym, 0);
            if ( symbol == 2200 )            // Numeric constant
            {
				ArraySize = __strtol_internal(sym, 0, 10, 0);
                symbol = getsym();
				if ( symbol == 1310 )       // "]" array sub terminator
					symbol = getsym();
                else
					ArraySize = 0;
			}
            if ( ArraySize <= 0 )			// error in subscript define
            {
				loaderr(31, v37);			// "array subscript must be +ve integer"
			    return 0;
			}
			//printf("ledefine : 74 ArraySize = %d\n",ArraySize);

		}
        else if ( symbol == 1800 )            // "eq", "=" or "=="
        {
			symbol = getsym();
            cdbcpystr(nptr, sym, 0);	// save value for initialisation later

			switch (symbol)
			{
			case 2210:								// floating point literal
				//printf("ledefine : 87 symbol = 2210 \n");
			    InitVar = 1;
                v1 = strchr(nptr, '.');
				if ( v1 && 20 == lenstr(v1 + 1) )
					MemSize = 9;
				else
					MemSize = 2;
				VarType = MemSize + 48;
				break;
			case 2220:								// string literal
  				//printf("ledefine : 97 symbol = 2220 \n");
				StringVar = 1;
                VarType = 'C';
                MemSize = (signed short)lenstr(nptr);
				break;
			case 2200:								// integer literal
  				//printf("ledefine : 103 symbol = 2200 \n");
				InitVar = 1;
                VarType = 'N';
				break;

			default:
 			   	loaderr(32, VarName);				// "constant definition"
				return 0;							// error_exit
				break;
			}
            symbol = getsym();
		}

// this allows "variable = 65.5,c30".   Creates a C30 variable, but doesn't initialise it.

//-----------------------------------
// Now look for separator and vartype

        if ( symbol == 180 )                  // ","
        {
			symbol = getsym();
            if ( !isalpha(sym[0]) && sym[0] != '$' && (!isdigit(sym[0]) || syml != 1) )
            {
 				loaderr(4, sym);	//"invalid data type"
				return 0;
            }
            if ( islower(sym[0]))
				VarType = toupper(sym[0]);
			else
				VarType = sym[0];
			//printf("ledefine : 132 VarType = %C\n",VarType);

// re-map $/F VarTypes
			if ( VarType == '$' )
				VarType = '2';
			else if (VarType == 'F')
				VarType = '6';

 //-----------------------------
 // check for a match on vartype
 // alltypes[] == "BCDFGILNRT$123456789"

			v5 = alltypes;
            while ( *v5 )
            {
				if ( *v5 == VarType )
                {
LABEL_50:
					if ( VarType == 'C' )	// look for char string length bytes
                    {
						v6 = &sym[1];
                        if ( *v6 )
                        {
							if ( !isdigit(*v6) || (v7 = __strtol_internal(v6, 0, 10, 0), (MemSize = v7) == 0) )
								TypeError = 1;
						}
                        syml = 1;
					}
                    else if ( syml != 1 )	// non-string variable, syml should always be 1 char long
						TypeError = 1;

					if ( TypeError )
                    {
			 			loaderr(4, sym);	// "invalid data type"
						return 0;
					}
                    symbol = getsym();
					goto LABEL_63;			// exit_success
				}
				++v5;
			}
            TypeError = 1;	// Error. Reached end of Alltypes array with no match
            goto LABEL_50;
		}

//---------------------

LABEL_63:
        if ( VarType == 'C' )
			MemSizea = MemSize;
		else
			MemSizea = 8;

		//printf("ledefine : 186 VarSize = %d, symbol = %d\n",MemSizea, symbol);

		VarNameLen = lenstr(VarName);
        if ( VarNameLen > 55 )		// Max Variable Name Length = 56
        {
			VarName[55] = 0;
            VarNameLen = 55;
		}
        v10 = last_var;
        troot = gettnode(troot, VarName, VarNameLen + 1, 1);
        if ( v10 == last_var )
		{
			loaderr(17, VarName);						// "variable redefined"
		    return 0;
		}
		v12 = last_fnd;
		if ( getvars(last_fnd) )
			__assert_fail("getvars(fno) == ((void *)0)", "ledefine.c", 155, "ledefine");
          
		fld = getvarmem();
		if ( fld != getvars(v12) )
			__assert_fail("f == getvars(fno)", "ledefine.c", 157, "ledefine");

		fld->FLDname = getmem(VarNameLen + 1);	// variable name
        cdbcpystr(fld->FLDname, VarName, 0);
        switch ( VarType )						// calculate vartype
        {
			case 'B':
				fld->FLDlen = 1;
                fld->TDFtype = 0x0044u;
                break;
			case 'I':
                fld->FLDlen = 2;
                fld->TDFtype = 0x0044u;
                break;
            case 'N':
                fld->FLDlen = 4;
                fld->TDFtype = 0x0044u;
                break;
            case 'L':
                fld->FLDlen = 8;
                fld->TDFtype = 0x0044u;
                break;
            case 'G':
                fld->FLDlen = 4;
                fld->TDFtype = 0x0404u;
                break;
            case 'R':
                fld->FLDlen = 4;
                fld->TDFtype = 0x0604u;
                break;
            case 'T':
                fld->FLDlen = 4;
                fld->TDFtype = 0x0800u;
                break;
            case 'D':
                fld->FLDlen = 4;
                fld->TDFtype = 0x1040u;
                break;
            case 'C':
                fld->FLDlen = MemSizea;
                fld->TDFtype = 0x001Au;
                break;
            default:
                fld->FLDlen = 8;
                v15 = VarType - 48;
                if ( v15 > 2 )
                {
					if ( v15 > 4 )
                    {
						if ( v15 > 6 )
                        {
							if ( v15 > 8 )
								fld->TDFtype = 0x0184u;	// 9 or ???
							else
								fld->TDFtype = 0x0144u;	// 7 or 8
						}
                        else
							fld->TDFtype = 0x0104u;	// 5 or 6
					}
                    else
						fld->TDFtype = 0x00C4u;	// 3 or 4
				}
                else
					fld->TDFtype = 0x0084u;	// 1 or 2

				if ( v15 % 2 == 1 )
					fld->TDFtype |= 0x20u;
				break;
          }

          fld->FLDtype = VarType;
          v16 = MemSizea;
          if ( VarType == 'C' )
			v16 = MemSizea + 1;
          fld->FLDdata = getmem(v16);

//save the init value

		if (StringVar)
		{
			cdbcpystr((char *)fld->FLDdata, nptr, 0);
			if ( !nptr[0] )
				fld->FLDstat |= 0x0004;			// quick zero check
			else
		        fld->FLDstat &= 0xFFFB;
		}
        else if ( InitVar )
        {
            v18 = __strtod_internal(nptr, 0, 0);
            if ( v18 == 0.0 )
				fld->FLDstat |= 0x0004;			// quick zero check
            else
				fld->FLDstat &= 0xFFFB;
            *(double *)fld->FLDdata = v18;
        }
		else
			fld->FLDstat |= 0x0004;				// Variable is not initialised. So set quick zero flag.

		if ( ArraySize )						// Use elemID as ArraySize, since unused for local vars
			fld->FLDelemID = ArraySize;
//printf("ledefine : 309 ArraySize = %d, symbol = %d\n",ArraySize, symbol);
       
    } // end while( symbol != 930 )
	return 1;
}

#endif
