#ifndef LOADSTATE_C
#define LOADSTATE_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"


short dpexp(short ENTno)
{
	short result; // ax@1
    int OpCode; // eax@4
    char v3; // zf@16
    short v4; // di@24
    short v5; // si@24
    short v6; // ax@26
    int TDno; // [sp+10h] [bp-18h]@22
	ENTAB*	entb;
	char FLDtype;

//printf("dpexp(%d)\n",ENTno);
    result = 0;
    if ( !ENTno )
		return result;
    allenpt(ENTno, &entb);
    if ( entb->entype != 2 )
    {
		dallenpt(&entb);
        gettf(ENTno, &TDno, &FLDtype);
        return typedp(FLDtype);
	}
    if ( ((unsigned short)entb->TTno >> 8) & 3 )
	{
		dallenpt(&entb);
        return 0;
	}
    
	OpCode = entb->TTno & 0xFC00;
	switch (OpCode)
	{
	case 0x6000:
		dallenpt(&entb);
        v6 = dpexp(entb->Dest);
        return dpexp(entb->Src) + v6;
		break;

	case 0xAC00:
        gettf(ENTno, &TDno, &FLDtype);
        dallenpt(&entb);
        return typedp(FLDtype);
		break;
	
	case 0xB800:
		dallenpt(&entb);
        return 9;
		break;

	case 0x6800:
	case 0x2400:
	case 0xBC00:
	case 0x6C00:
		dallenpt(&entb);
		return 0;
		break;

	case 0x5400:
	case 0x5800:
		v4 = dpexp(entb->Dest);
		v5 = dpexp(entb->Src);
		dallenpt(&entb);
		result = v4;
		if ( v4 < v5 )
			result = v5;
		return result;
		break;

	case 0x0000:
		__assert_fail("0", "dpexp.c", 0x24u, "dpexp");
		break;

	default:
		dallenpt(&entb);
		return 99;
		break;
	
	}
}

void prstr(char *a1)
{
	char *v1; // esi@1
    const unsigned short **v2; // edi@2
    int v3; // edx@3

    v1 = a1;
    v2 = __ctype_b_loc();
	while ( *v1 );
	{
		v3 = *v1;
		if ( (*v2)[v3] & 2 )
			printf("^%c", v3 + 0x40);
		else
			_IO_putc(*v1, stdout);
		v1++;
	}
}

void prresv(int ReservedMask)
{
    const char *v1; // eax@25

	switch (ReservedMask)
	{
		case 0x0001:
			v1 = "'path'";
			break;
		case 0x0002:
			v1 = "'version'";
			break;					//0x0004 free?
		case 0x0008:
			v1 = "'date'";
			break;
		case 0x0010:
			v1 = "'time'";
			break;
		case 0x0020:
			v1 =  "'pname'";
			break;
		case 0x0040:
			v1 = "'uname'";
			break;
		case 0x0080:
			v1 = "'pid'";
			break;
		case 0x0100:
			v1 = "'uid'";
			break;
		case 0x0200:
			v1 = "'login'";
			break;
		case 0x0400:
			v1 = "'tty'";
			break;
		case 0x0800:
			v1 = "'nname'";
			break;				//0x1000 free??
		case 0x2000:
			v1 = "'pwd'";
			break;
		case 0x4000:
			v1 = "'licensee'";
			break;				//0x8000 free??
		default:	// unknown, just print mask value
			printf("'-%o-'", ReservedMask);
			return;
			break;
	}
	printf(v1);
    return;
}

int nxtch()
{
	return c;
}

short putconst(char *nptr, char FLDtype)
{
     unsigned int v2; // kr04_4@1
	 double v3;
     short v4; // cx@6
     int VarSize; // eax@8
     signed short v7; // ax@21
     int v10; // [sp+0h] [bp-78h]@5
     FLDdesc *fld; // [sp+2Ch] [bp-4Ch]@8
     short v12; // [sp+30h] [bp-48h]@10
     short v13; // [sp+38h] [bp-40h]@5
     char arg[256]; // [sp+40h] [bp-38h]@3

	v2 = strlen(nptr) + 1;
    if ( v2 - 1 > 19 )
    {
		++lit_no_0;
        sprintf(arg, ".?.%d", (unsigned short)lit_no_0);
        v4 = last_var++;
        v13 = v4;
        v10 = v4;
	}
    else
    {
		if ( FLDtype == 'C' )					// make name for literal strings start with a single quote
			cdbcpystr(arg, "'", nptr, 0);		// *** be careful of buffer overrun on this case **
        else
			sprintf(arg, "%.*f", FLDtype - 48, (double)__strtod_internal(nptr, 0, 0));

		troot = gettnode(troot, arg, strlen(arg), 1);
        v13 = last_fnd;
        v10 = last_fnd;
	}
    if ( !getvars(v10) )                       // check to see if Variable already defined
    {
		fld = getvarmem();
        fld->FLDname = getmem(strlen(arg) + 1);
        cdbcpystr(fld->FLDname, arg, 0);
        VarSize = 8;
        if ( FLDtype == 'C' )
			VarSize = v2 - 1;
		v12 = VarSize;
        fld->FLDdata = getmem(VarSize + 1);
        fld->FLDtype = FLDtype;
        switch ( FLDtype )
        {
               case 'B':
                    fld->FLDlen = 1;
                    fld->TDFtype = 0x0044u;
                    break;
               case 'I':
                    fld->FLDlen = 2;
                    fld->TDFtype = 0x0044u;
                    break;
               case 'N':
                    fld->FLDlen = 4;
                    fld->TDFtype = 0x0044u;
                    break;
               case 'L':
                    fld->FLDlen = 8;
                    fld->TDFtype = 0x0044u;
                    break;
               case 'G':
                    fld->FLDlen = 4;
                    fld->TDFtype = 0x0404u;
                    break;
               case 'T':
                    fld->FLDlen = 4;
                    fld->TDFtype = 0x0800u;
                    break;
               case 'R':
                    fld->FLDlen = 4;
                    fld->TDFtype = 0x0604u;
                    break;
               case 'D':
                    fld->FLDlen = 4;
                    fld->TDFtype = 0x1040u;
                    break;
               case 'C':
                    fld->FLDlen = v12;
                    fld->TDFtype = 0x001Au;
                    break;
               default:
                    fld->FLDlen = 8;
                    v7 = FLDtype - 48;
                    if ( v7 > 2 )
                    {
                         if ( v7 > 4 )
                         {
                              if ( v7 > 6 )
                              {
                                   if ( v7 > 8 )
                                        fld->TDFtype = 0x0184u;
                                   else
                                        fld->TDFtype = 0x0144u;
                              }
                              else
                                   fld->TDFtype = 0x0104u;
                         }
                         else
                              fld->TDFtype = 0x00C4u;
                    }
                    else
                         fld->TDFtype = 0x0084u;
                    if ( v7 % 2 == 1 )
                         fld->TDFtype |= 0x0020u;
                    break;
		}
        if ( FLDtype == 'C' )
        {
			cdbcpystr((char *)fld->FLDdata, (char *)nptr, 0);
            if ( *nptr )
				fld->FLDstat &= 0xFFFBu;
			else
				fld->FLDstat |= 0x0004u;
		}
        else
        {
			v3 = __strtod_internal(nptr, 0, 0);
            if ( v3 == 0.0 )
				fld->FLDstat |= 0x0004u;
			else
				fld->FLDstat &= 0xFFFBu;
			*(double *)fld->FLDdata = v3;
		}
        fld->FLDstat |= 0x0010u;
	}
    return v13;
}

int lutree(VARTREE *vartree, char *s1, int StrLen)
{
     int v3; // edx@1
     int v4; // eax@2
     int v9; // [sp+18h] [bp-10h]@1

	v9 = 0;
    v3 = 0;
    if ( vartree )
    {
		v4 = strncmp(s1, vartree->VarName, StrLen + 1);
        v3 = 1;
        if ( v4 )
        {
			if ( v4 >= 0 )
            {
				if ( v4 <= 0 )
					return v9;             // return ZERO, shouldn't be reachable (zero case)
	            return lutree(vartree->VarNext, s1, StrLen);       // recursion here
			}
            else
	            return lutree(vartree->VarPrev, s1, StrLen);       // recursion here
		}
	}
    return v3;
}

void _define(char *StringVal)
{
     int v1; // kr04_4@1
     FLDdesc *fld; // edi@3

     v1 = strlen(StringVal) + 1;

	 if ( getvars(last_var) )
          __assert_fail("getvars(last_var) == ((void *)0)", "isdef.c", 61, "_define");
     
	 fld = getvarmem();

	 if ( fld != getvars(last_var) )
          __assert_fail("f == getvars(last_var)", "isdef.c", 63, "_define");
     
	 fld->FLDname = getmem(v1);
     cdbcpystr(fld->FLDname, StringVal, 0);
     fld->FLDlen = v1 - 1;
     fld->TDFtype = 0x001Au;	// string type
     fld->FLDtype = 'C';
     fld->FLDdata = getmem(v1);
     cdbcpystr((char *)fld->FLDdata, StringVal, 0);// copy string to data area as well as name
     fld->FLDstat &= 0xFFFBu;
}

int isdef(char *StringVal)
{
     if ( !lutree(troot, StringVal, strlen(StringVal)) )
          _define(StringVal);
     return 1;
}


int lefork(PTAB *pt)
{
	short ENTno;
    int TDno;
    char FieldType;

    symbol = getsym();
    if ( symbol == 930 )                       // fork with no arguments is ok
		return 1;
    if ( symbol != 2230 && symbol != 2220 )		// string literal or string variable
	{
		loaderr(64, sym);	// "'fork' command must be character"
        return 0;
    }
	ENTno = loadexp(0, 0);
    if ( ENTno )
    {
		gettf(ENTno, &TDno, &FieldType);
        if ( FieldType != 'C' )
        {
			loaderr(64, sym);	// "'fork' command must be character"
            return 0;
        }
        pt->TABno = ENTno;
        if ( symbol != 930 )
        {
			loaderr(33, sym);
            return 0;
        }
        return 1;	// exit_success
	}
    return 0;
}

void prdatefield(unsigned short ENTno, unsigned short XTno, PRTAB *pr)
{
     ENTAB *ent; // ecx@1
     ENTAB *v4; // eax@5
     int TTno; // edi@12
     char *EntFileName; // esi@17
     char *Version; // eax@17
     char *v8; // eax@18
     TDesc *v9; // edx@22
     char *v10; // eax@23
     ENTAB *v12; // ecx@32
     signed short v13; // si@32
     ENTAB *v14; // eax@34
     int v15; // edi@41
     TDesc *v17; // edx@49
     char *v18; // eax@50
     TDesc *v19; // edx@56
     char *v20; // eax@57
     XTAB *v26; // [sp+14h] [bp-14h]@10
     FLDdesc *v27; // [sp+18h] [bp-10h]@13
     FLDdesc *v28; // [sp+18h] [bp-10h]@42

	ent = ENTno ? (ENTAB *)&enarr.TableAddr[12 * (ENTno - 1)] : 0;
     
	if ( ent->Dest )
    {
		if ( !ent->Dest )
        {
			v4 = 0;
            goto LABEL_7;
		}
        do
        {
			v4 = (ENTAB *)&enarr.TableAddr[12 * (ent->Dest - 1)];
LABEL_7:
            ent = v4;
		}
        while ( v4->Dest );
	}
    
	if ( ent->entype != 1 )
		__assert_fail("((tf)->entype == 0x1)", "prdebug.c", 733, "prdatefield");

	v26 = XTno ? (XTAB *)&xtarr.TableAddr[52 * (XTno - 1)] : 0;
    
	TTno = ent->TTno;
    if ( TTno )
		v27 = &ttab[TTno].TTfields[ent->RecNo];
	else
		v27 = getvars(ent->RecNo);

	if ( v27->FLDtype == 'D' )
    {
		++count_0;
        if ( count_0 == 1 )
        {
			EntFileName = clbasename(ename);
            Version = getclver();
            print("cl (%s) checking %s.ent for date fields\n", Version, EntFileName);
		}
        v8 = "Output";
        if ( v26 )
			v8 = "Input";
		print("%s %s: ln %d: ", FileTree->FileName, v8, (unsigned short)ll);
        if ( TTno )
        {
			v9 = &ttab[TTno];
            if ( v9->TableAlias[0] )
				v10 = v9->TableAlias;
			else
				v10 = v9->TableName;
			print("%s.%s ", v10, v27->FLDname);
		}
        else
			print("%s ", v27->FLDname);

		if ( v26 )
        {
			if ( v26->widthEXP )
				prtfid(v26->widthEXP);
			else
				print("%d.", v26->width);
            print("\n");
            return;
		}
        if ( !pr )
		{
            print("\n");
			return;
		}
		if ( !pr->field_2 )
        {
			print("fw=%d", pr->field_4 & 0xFFFF83FF);
            print("\n");
			return;
		}
        v12 = (ENTAB *)&enarr.TableAddr[12 * (pr->field_2 - 1)];
        v13 = 0;
        while ( v12->Dest )
        {
			v13 = 1;
            v14 = v12->Dest ? (ENTAB *)&enarr.TableAddr[12 * (v12->Dest - 1)]: 0;
            v12 = v14;
		}
        if ( v12->entype != 1 )
	        __assert_fail("((tf)->entype == 0x1)", "prdebug.c", 764, "prdatefield");

		v15 = v12->TTno;
          
		if ( v15 )
			v28 = &ttab[v15].TTfields[v12->RecNo];
		else
			v28 = getvars(v12->RecNo);
          
		if ( v28->FLDtype == 'C' )
        {
			if ( v15 )
            {
				v17 = &ttab[v15];
                if ( v17->TableAlias[0] )
					v18 = v17->TableAlias;
				else
					v18 = v17->TableName;
				print("%s.%s ", v18, v28->FLDname);
			}
            else
            {
				if ( *v28->FLDname == '\'' )// ??? mask literals ???
					print("mask=literal val=[%s] ", v28->FLDdata);
				else
					print("mask=[%s] val=[%s] ", v28->FLDname, (char *)v28->FLDdata);
			}
		}
        else
        {
			if ( v15 )
            {
				v19 = &ttab[v15];
                if ( v19->TableAlias[0] )
					v20 = v19->TableAlias;
				else
					v20 = v19->TableName;
				print("%s.%s [%c] ", v20, v28->FLDname, v28->FLDtype);
			}
			else
				print("var=[%s[%c]] ", v28->FLDname, v28->FLDtype);
		}
        if ( v13 )
			print("expr ");
		print("\n");
        return;
	}
}

bool isnumop(unsigned int a1)
{
	switch (a1)
	{
	case 0x5C00:
	case 0x9800:
	case 0xE000:
	case 0xE800:
	case 0xD800:
	case 0x6800:
	case 0x9000:
	case 0x6000:
	case 0x3C00:
	case 0x4C00:
	case 0x5400:
	case 0x4400:
	case 0xEC00:
	case 0xE400:
	case 0xDC00:
	case 0x9400:
	case 0x6400:
	case 0x5800:
	case 0x5000:
	case 0x4800:
	case 0x1000:
	case 0x0800:
	case 0x0C00:
	case 0x1400:
	case 0x1800:
		return true;
		break;

	default:
		return false;
	}
}

void warncexp()
{
     eprint("\"%s\", line %4d - ", FileTree->FileName, ll);
     eprint("+-*%%/ will be unsupported on strings in future releases\n");
}

// Normal accept type field. OpCode = 1
int leaccept(short a1)
{
     short v1; // ax@3
     signed int v2; // edi@5
     short v3; // ax@25
     int FieldNo; // esi@25
     int v7; // edx@36
     FLDdesc *v8; // ecx@37
     FLDdesc *fld; // ecx@47
     signed short FieldLen; // ax@58
     signed int v12; // [sp+1Ch] [bp-6Ch]@1
     int	v13;
     int	TTno;
	 XTAB*	xtabptr;
	 char	v16[128];
	 char	FLDtype;

    v12 = 1;
    cdbcpystr(v16, sym, 0);
    if ( block_no_0 != cur_block )
    {
		block_no_0 = cur_block;
        got_fdf_1 = 0;
	}
    v1 = getxtmem();
    v13 = (unsigned short)v1;
    allxtpt(v1, &xtabptr);
    xtabptr->VarExpNo = a1;
	if ( !getadwid(xtabptr) )
	{
		dallxtpt(&xtabptr);
        return 0;
	}
	if ( symbol == 180 )                       // ","
    {
		v2 = 1;
        symbol = getsym();
	}
    else
		v2 = 0;

	if ( !v2 && (symbol != 2230 || syml != 1) )
          goto LABEL_22;

    if ( sym[0] == 'R' || sym[0] == 'r' )		// Required
	{
          xtabptr->Flags |= 0x0400u;
          symbol = getsym();
          goto LABEL_22;
	}
    if ( sym[0] == 'D' || sym[0] == 'd' )		// Display Only
    {
		xtabptr->Flags |= 0x0004u;
        v12 = 0;
        symbol = getsym();
        goto LABEL_22;
	}

LABEL_20:
     if ( v2 )
     {
          loaderr(37, sym);                     // "invalid field width"
          dallxtpt(&xtabptr);
          return 0;
     }

LABEL_22:
     if ( v12 && !got_fdf_1 )
     {
          xtabptr->Flags |= 0x0008u;			// This is first editable field on screen
          got_fdf_1 = 1;
     }
     v3 = gettf(xtabptr->VarExpNo, &TTno, &FLDtype);
     FieldNo = v3;
     if ( v3 < 0 )
          __assert_fail("fno >= 0", "leaccept.c", 0x55u, "leaccept");
     switch ( FLDtype )
     {
          case 'C':
               xtabptr->Flags |= 0x0001;	// String
               break;
          case 'D':
               xtabptr->Flags |= 0x0002;	// Date
               break;
          case 'T':
               xtabptr->Flags |= 0x0800;	// Time
               break;
          default:
               xtabptr->Flags |= 0x0200;	// Numeric type?
               break;
     }
     if ( v12 )
     {
          if ( TTno )
          {
               v7 = btab[cur_block].TTno;
               if ( TTno == v7 )
               {
                    v8 = &ttab[v7].TTfields[FieldNo];
                    if ( v8->FLDstat < 0 )
                    {
                         xtabptr->Flags |= 0x8000u;
                         if ( v8[1].FLDstat >= 0 )
                              xtabptr->Flags |= 0x0040u;
                    }
               }
          }
    }
    if ( !getcol(xtabptr, 2) || !getrow(xtabptr, 2) || !getcol(xtabptr, 1) || !getrow(xtabptr, 1) || !getprmpt(xtabptr) )
	{
		dallxtpt(&xtabptr);
        return 0;	// error_exit
	}
	if ( TTno )
		fld = &ttab[TTno].TTfields[FieldNo];
	else
		fld = getvars(FieldNo);
	
	if ( !(((unsigned short)xtabptr->PLine >> 8) & 0x7E) && !(((unsigned short)xtabptr->PCol >> 8) & 0x7E)
       && !(((unsigned short)xtabptr->ACol >> 8) & 0x7E) && !(((unsigned short)xtabptr->ALine >> 8) & 0x7E)
       && !xtabptr->PCol_exp && !xtabptr->ACol_exp && !TTno && fld->FLDlen )
	{
		if ( FLDtype == 'C' )
			FieldLen = fld->FLDlen + 1;      // String variable can have different lengths
		else
			FieldLen = 8;                    // all other variables are stored in 8 bytes
		xtabptr->Width = FieldLen;
	}
    dallxtpt(&xtabptr);
    return v13;	// exit_success
}

int lesrand(PTAB *ptab)
{
     short v1; // dx@1
     int v2; // ecx@1

     symbol = getsym();
     v1 = loadexp(0, 1);
     v2 = 0;
     if ( v1 )
     {
          ptab->TABno = v1;
          v2 = 1;
     }
     return v2;
}

int lesleep(PTAB *ptab)
{
     short v1; // dx@1
     int v2; // ecx@1

     symbol = getsym();
     v1 = loadexp(0, 1);
     v2 = 0;
     if ( v1 )
     {
          ptab->TABno = v1;
          v2 = 1;                               // exit_success
     }
     return v2;
}

int leescape(int PTno, int a4)
{
	PTAB *ptb; // ecx@0
    XTAB *xtab; // eax@5
	bool AcceptField; // eax@1
    ONESC **v6; // edi@7
    ONESC *v7; // eax@11
    ONESC *v8; // eax@11
    short KeyNumber; // dx@18
    char v16[32]; // [sp+20h] [bp-58h]@27

printf("leescape(%d, %d) \n", PTno, a4); 

	AcceptField = 0;
	if ( PTno )
    {
		ptb = PTARR(getptabp(PTno - 1));
        AcceptField = ptb->OpCode == 1;        // Is this an accept field?
    }
printf("leescape : AcceptField = %s\n", AcceptField? "true":"false"); 
	if ( AcceptField )
    {
		if ( ptb->TABno )
			xtab = (XTAB *)&xtarr.TableAddr[52 * (ptb->TABno - 1)];
		else
			xtab = 0;
		v6 = &xtab->onesc;                    // Look at individual field escapes
    }
    else
    {
		v6 = &oelist;                         // Not an accpet field, look at global block escapes
    }

// Find the last blank on_esc entry
	if ( *v6 )
    {
		if ( (*v6)->NextESC )
        {
			while ( 1 )
			{
				v7 = *v6;
				v6 = &v7->NextESC;
				v8 = v7->NextESC;
				if ( !v8 )
					break;
				if ( !v8->NextESC )
					goto LABEL_13;
			}
		}
        else
		{
LABEL_13:
			if ( *v6 )
				v6 = &(*v6)->NextESC;
		}
	}
    v8 = (ONESC *)getmem(16);
    *v6 = v8;
    v8->field_0 = a4 == 1020;	// ??

//-----------
// work out the key number equivalent, or single char value
    symbol = getsym();
    if ( syml == 1 && (*__ctype_b_loc())[sym[0]] & 0x0400 )// single char keyname specifier (isalpha())
    {
		(*v6)->KeyNumber = sym[0];
printf("leescape : single char key %C\n", sym[0]); 

    }
	else
    {
		KeyNumber = KeyToNumber(sym);
		if ( !KeyNumber )
		{
            loaderr(73, sym);				// "invalid 'escape' character"
            return 0;
		}
		(*v6)->KeyNumber = KeyNumber;
	}

// Now load black name
	symbol = getsym(); 
    if ( symbol != 2230 )                   // not a strig literal
    {
        if ( symbol == 930 )
			loaderr(2, sym);                // "missing block name"
		else
			loaderr(33, sym);	           // "unexpected symbol"
        return 0;
	}
    (*v6)->BlockName = getmem(fixbname(v16, sym));	// truncate the blockname to 20chars + 1 for \0
    cdbcpystr((*v6)->BlockName, v16, 0);
printf("leescape : BlockName = %s\n", v16); 
    symbol = getsym();
    return 1;
}

int gettfs(unsigned short ENTABno, int *TTno, char *FLDtype, short *Status)
{
    ENTAB *entb; // edx@1
    signed int FieldNo; // esi@10
    int v6; // eax@18
    FLDdesc *fld; // [sp+18h] [bp-10h]@1

    fld = 0;
	entb = ENTABno ? (ENTAB *)&enarr.TableAddr[12 * (ENTABno - 1)] : 0;
    
	if ( !entb )
		goto LABEL_23;
	while ( entb->Dest )
    {
		entb = (ENTAB *)&enarr.TableAddr[12 * (entb->Dest - 1)];
        if ( !entb )
			goto LABEL_23;
	}
    if ( !entb )
		goto LABEL_23;
	if ( entb->entype == 2 && entb->TTno & 0x0100 )
    {
LABEL_23:
		FieldNo = -1;
        *TTno = 0;
        *FLDtype = 0;
        return FieldNo;
	}
    *TTno = 0;
    FieldNo = -1;
    switch ( entb->entype )
    {
	case 4:
        *FLDtype = '6';
		break;
	case 8:
		*FLDtype = 'N';
        break;
	case 0x10:
		*FLDtype = 'C';
        break;
	default:
		if ( entb->entype != 1 )
			__assert_fail("((t)->entype == 0x1)", "gettf.c", 0x5Cu, "gettfs");
		v6 = entb->TTno;
        *TTno = v6;
        FieldNo = entb->RecNo;
        if ( v6 )
			fld = &ttab[*TTno].TTfields[FieldNo];
		else
			fld = getvars(entb->RecNo);
		*FLDtype = fld->FLDtype;
        break;
	}
    *Status = fld->FLDstat;
    return FieldNo;
}

int loadstate(int *a1)
{
     int result; // eax@12
     char v6; // zf@13
     char v7; // zf@26
     char v8; // zf@34
     char v9; // zf@77
     int v10; // eax@113
     short v19; // ax@118
     signed int v22; // edx@120
     signed int v25; // eax@125
     int v29; // eax@130
     short v32; // ax@135
     char *v35; // eax@144
     short v39; // esi@159
     signed int v43; // eax@168
     short v68; // dx@190
     short v82; // si@219
     char v83; // zf@226
     char v84; // zf@228
     int FieldNo; // edi@239
     short v86; // dx@276
     ENTAB *v87; // edx@280
     short v88; // ax@280
     FLDdesc *v92; // edx@290
     short v93; // dx@294
     int v100; // [sp+0h] [bp-B8h]@176
     int v101; // [sp+0h] [bp-B8h]@180
     int Join; // [sp+4h] [bp-B4h]@155
     short v112; // [sp+30h] [bp-88h]@245
     int v113; // [sp+34h] [bp-84h]@241
     int AuxError; // [sp+38h] [bp-80h]@4
     ENTAB *v115; // [sp+3Ch] [bp-7Ch]@245
     int TTno; // [sp+40h] [bp-78h]@239
     char FieldType; // [sp+47h] [bp-71h]@219
	 ENTAB*	entb;
     PTAB *ptab1; // [sp+4Ch] [bp-6Ch]@114
     char v119[64]; // [sp+50h] [bp-68h]@128
     int a4; // [sp+9Eh] [bp-1Ah]@239

//printf("loadstate called - *a1 = %d\n",*a1);
	if ( comp_abort )
		return 0;
	while ( symbol == 930 )
		symbol = getsym();
        
	AuxError = 0;
	switch (symbol)
	{
	case 0:									// no symbol found, usually means EOF
		return 0;		// error_exit
		break;

	case 660:								// include
		if ( leincl())
			return 1;
		break;

	case 510:
		if ( leformat((short *)a1, 1))
			return 1;
		break;

	case 55:								// replace
	case 160:								// clear
	case 300:								// delete
	case 580:								// getnext
	case 590:								// getprev
	case 600:								// get
	case 1220:								// put
		if ( lerfile(a1, symbol))
			return 1;
		break;

	case 1430:								// set
		if ( leset(a1) )
			return 1;
		break;

	case 1260:								// range
		if ( lerange(*a1))
			return 1;
		break;

	case 1680:								// 1680 = unlock
		if ( leulck(a1))
			return 1;
		break;

	case 990:								// on_eop
		if ( leeop(*a1))
			return 1;
		break;

	case 420:								// escape
		if ( leescape(*a1, symbol))
			return 1;
		break;

	case 1020:								// on_key
		if ( leescape(*a1, symbol))
			return 1;
		break;

	case 620:									// goto
		symbol = getsym();	// 620 goto
        allptpt(getptabp((*a1)++), &ptab1);
        ptab1->OpCode = 700;
        ptab1->SrcLineNo = lla;
        if ( symbol != 720 )        // LABEL type.   string followed by colon.  "HELLO:"
		{
			loaderr(44, sym);		// "invalid label"
            AuxError = 1;
            dallptpt(&ptab1);
		}
		else
		{
			ptab1->TABno = getstrmem(syml + 1);
			v35 = ptab1->TABno ? &strarr.StringTable[ptab1->TABno - 1] : 0;
			cdbcpystr(v35, sym, 0);
			symbol = getsym();
			dallptpt(&ptab1);
			if ( !AuxError )
				return 1;
		}
		break;

	case 650:									// if
		if ( !leif((short *)a1) )
        {
			AuxError = 1;
            while ( symbol != 390 && symbol )
				symbol = getsym();
    		if ( symbol )
				symbol = getsym();
		}
		if ( !AuxError )
			return 1;
		break;

	case 1730:									// while
		++while_count;
		if ( !lewhile((short *)a1) )
		{
			AuxError = 1;
            while ( symbol != 1710 && symbol )	// wend
				symbol = getsym();
			if ( symbol )
				symbol = getsym();
		}
		while_count--;
		if ( !AuxError )
			return 1;
		break;

	case 1610:									// text
		symbol = getsym();
		allptpt(getptabp((*a1)++), &ptab1);
		ptab1->OpCode = 4;
		ptab1->SrcLineNo = lla;
		v19 = lehdtxt();
        v22 = 1;
		if ( v19 )
			v22 = 0;
		AuxError = v22;
        ptab1->TABno = v19;
	    dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		break;

	case 950:									// no_join
	case 690:				                    // join
		if (symbol == 950)
			Join = 0;		// 950 no_join
		else
			Join = 1;
		if ( lejoin(*a1, Join))
			return 1;
		break;

	case 400:									// endloop
	case 210:									// continue
		if ( !while_count )
        {
			loaderr(78, sym);	// "'continue/endloop' must be inside 'while' block
			goto LABEL_307;
		}
        allptpt(getptabp((*a1)++), &ptab1);
        if ( symbol == 210 )   // continue
			v32 = 320;	// continue
		else
			v32 = 330;	// endloop
		ptab1->OpCode = v32;
        ptab1->SrcLineNo = lla;
        ptab1->Operand = 0;
        symbol = getsym();
        if ( symbol != 930 )
        {
			loaderr(33, sym);
			AuxError = 1;
		}
        dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		break;

	case 350:										// do {blockname}
		symbol = getsym();
        allptpt(getptabp((*a1)++), &ptab1);
        ptab1->OpCode = 720;
        ptab1->SrcLineNo = lla;
        if ( symbol == 2230 )	// string literal
        {
			ptab1->TABno = getstrmem( fixbname(v119, sym) );
			v35 = ptab1->TABno ? &strarr.StringTable[ptab1->TABno - 1] : 0;
			cdbcpystr(v35, v119, 0);
			symbol = getsym();
			dallptpt(&ptab1);
			if ( !AuxError )
				return 1;
		}
		else
		{
			if ( symbol == 930 )
				loaderr(33, sym);	// unexpected symbol
			else
				loaderr(2 , sym);	// "missing block name"
			AuxError = 1;
			dallptpt(&ptab1);
		}
		break;

	case 402:								// endtran
		allptpt(getptabp((*a1)++), &ptab1);
        ptab1->OpCode = 340;
        ptab1->SrcLineNo = lla;
        dallptpt(&ptab1);
        symbol = getsym();
        if ( symbol == 930 )
			return 1;
		else
			loaderr(33, sym);			// unexpected symbol
		break;

	case 870:							// message
		allptpt(getptabp((*a1)++), &ptab1);
		ptab1->OpCode = 270;
		ptab1->SrcLineNo = lla;
		v29 = lemsg(ptab1);
        v6 = v29 == 0;
        v43 = 1;
		if ( !v6 )
			v43 = 0;
        AuxError = v43;
        dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		break;

	case 90:							// exit_block
	case 310:							// exit_do
	case 1090:							// exit_process
	case 1240:							// restart_block

        allptpt(getptabp((*a1)++), &ptab1);

        if ( symbol == 90 )			// exit_block
			ptab1->OpCode = 882;
        else if ( symbol == 310 )	// exit_do
			ptab1->OpCode = 884;
        else if ( symbol == 1090 )	// exit_process
			ptab1->OpCode = 886;
        else if ( symbol == 1240 )	// restart_block
			ptab1->OpCode = 888;

		ptab1->SrcLineNo = lla;
		dallptpt(&ptab1);
		symbol = getsym();
		if ( symbol == 930 )
		{
			if ( !AuxError )
				return 1;
		}
		else
			loaderr(33, sym);			// unexpected symbol
		break;

	case 1060:							// pause
		allptpt(getptabp((*a1)++), &ptab1);
        ptab1->OpCode = 870;
		ptab1->SrcLineNo = lla;
		v29 = lepause(ptab1);
        v6 = v29 == 0;
        v43 = 1;
		if ( !v6 )
			v43 = 0;
        AuxError = v43;
        dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		break;

	case 500:								// fork
		allptpt(getptabp((*a1)++), &ptab1);		// 500 fork()
        ptab1->OpCode = 750;
        ptab1->SrcLineNo = lla;
        v29 = lefork(ptab1);
        v6 = v29 == 0;
        v43 = 1;
		if ( !v6 )
			v43 = 0;
		AuxError = v43;
        dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		break;

	case 430:								// openapp
	case 460:								// openin
	case 530:								// openout
		allptpt(getptabp((*a1)++), &ptab1);
        ptab1->OpCode = 860;
        ptab1->SrcLineNo = lla;
        v100 = 0;				// 0 == file
        v19 = leopen(v100);
        v22 = 1;
		if ( v19 )
			v22 = 0;
		AuxError = v22;
        ptab1->TABno = v19;
	    dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		break;

	case 1460:									// select
		allptpt(getptabp((*a1)++), &ptab1);
        ptab1->OpCode = 560;
        ptab1->SrcLineNo = lla;
        v68 = leselect();
        if ( !v68 )
        {
			AuxError = 1;
			ptab1->OpCode = 400;	// no-op ??
		}
        ptab1->TABno = v68;
        dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		break;

	case 1320:									// redisplay
		allptpt(getptabp((*a1)++), &ptab1);
        ptab1->OpCode = 730;
        ptab1->SrcLineNo = lla;
        symbol = getsym();
        v19 = leredisp();
        v22 = 1;
		if ( v19 )
			v22 = 0;
		AuxError = v22;
        ptab1->TABno = v19;
	    dallptpt(&ptab1);
		if ( !AuxError )
			return 1;	// exit_success
		break;

	case 230:								// copy
	case 240:								// create
		switch (symbol)
		{
		case 230:
            allptpt(getptabp((*a1)++), &ptab1);
            ptab1->OpCode = 800;
            ptab1->SrcLineNo = lla;
            v19 = lecopy();
			break;
		case 240:
            allptpt(getptabp((*a1)++), &ptab1);
            ptab1->OpCode = 450;
            ptab1->SrcLineNo = lla;
            v19 = lecreate();
			break;
		}
        v22 = 1;
		if ( v19 )
			v22 = 0;
		AuxError = v22;
        ptab1->TABno = v19;
	    dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		break;

	case 1350:								// refresh
	case 1390:								// screen
	case 1470:								// sleep
	case 1510:								// srandom
		switch (symbol)
		{
		case 1350:
			allptpt(getptabp((*a1)++), &ptab1);
            ptab1->OpCode = 250;
            ptab1->SrcLineNo = lla;
			v29 = lefresh(ptab1);
			break;

		case 1390:
		    allptpt(getptabp((*a1)++), &ptab1);
            ptab1->OpCode = 260;
            ptab1->SrcLineNo = lla;
			v29 = lescreen(ptab1);
			break;
		
		case 1470:
			allptpt(getptabp((*a1)++), &ptab1);
			ptab1->OpCode = 880;
			ptab1->SrcLineNo = lla;
			v29 = lesleep(ptab1);
			break;

		case 1510:
			allptpt(getptabp((*a1)++), &ptab1);
            ptab1->OpCode = 760;
            ptab1->SrcLineNo = lla;
			v29 = lesrand(ptab1);
			break;
		}
		v6 = v29 == 0;
        v43 = 1;
		if ( !v6 )
			v43 = 0;
        AuxError = v43;
        dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		goto LABEL_307;
		break;

	case 560:			//   **** check this case ***
	case 540:
	case 440:
		allptpt(getptabp((*a1)++), &ptab1);		// 440? close() and/or  read()?
		ptab1->OpCode = 860;
		ptab1->SrcLineNo = lla;
		v101 = 0;
		v19 = leread(v101);
		v22 = 1;
		if ( v19 )
			v22 = 0;
		AuxError = v22;
		ptab1->TABno = v19;
		dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		goto LABEL_307;
		break;

	case 940:										// 940 = delay_form
		allptpt(getptabp((*a1)++), &ptab1);
        ptab1->OpCode = 265;
		ptab1->SrcLineNo = lla;
		dallptpt(&ptab1);
		symbol = getsym();
		if ( symbol == 930 )
			return 1;
		else
			loaderr(33, sym);			// unexpected symbol
		break;

	case 1120:							// popenio
	case 1110:							// 1110 = popenin
	case 1150:							// 1150 = popenout
		allptpt(getptabp((*a1)++), &ptab1);
		ptab1->OpCode = 850;
		ptab1->SrcLineNo = lla;
		v100 = 1;
        v19 = leopen(v100);
        v22 = 1;
		if ( v19 )
			v22 = 0;
		AuxError = v22;
        ptab1->TABno = v19;
	    dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		goto LABEL_307;
		break;

	case 1190:							// 1190 = print
		allptpt(getptabp((*a1)++), &ptab1);
        ptab1->OpCode = 900;
        ptab1->SrcLineNo = lla;
        symbol = getsym();
        v19 = leprint();
        v22 = 1;
		if ( v19 )
			v22 = 0;
		AuxError = v22;
        ptab1->TABno = v19;
	    dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		goto LABEL_307;
		break;

	case 1180:
	case 1230:
		allptpt(getptabp((*a1)++), &ptab1);
		ptab1->OpCode = 850;
		ptab1->SrcLineNo = lla;
		v101 = 1;
		v19 = leread(v101);
        v22 = 1;
		if ( v19 )
			v22 = 0;
		AuxError = v22;
        ptab1->TABno = v19;
	    dallptpt(&ptab1);
		if ( !AuxError )
			return 1;
		goto LABEL_307;
		break;

	case 140:							// clear_eos
	case 130:							// 130 = clear_eol
		if (symbol == 140)
		{
			allptpt(getptabp((*a1)++), &ptab1);
            ptab1->OpCode = 922;
		}
		else
		{
			allptpt(getptabp((*a1)++), &ptab1);
            ptab1->OpCode = 920;
		}
        ptab1->SrcLineNo = lla;
        dallptpt(&ptab1);
		symbol = getsym();
		if ( !AuxError )
			return 1;
		goto LABEL_307;
		break;

	case 720:		// we hit a LABEL: as an lvalue
		v39 = 0;
		if ( lti > 0 )
		{
			while ( !cmpbuf(sym, ltab[v39]->LabelName, ltab[v39]->NameLen) )
			{
				v39++;
				if ( lti <= v39 )
					goto LABEL_162;
			}
			loaderr(16, sym);		//"duplicate label"
			AuxError = 1;
		}
LABEL_162:
		if ( !AuxError )
		{
			if ( lti < no_ltabs || (newltab(), lti < no_ltabs) )
			{
				++lti;
				*lt = (LTAB *)getmem(syml + 6);
				(*lt)->NameLen = syml;
				(*lt)->field_2 = *(short*)a1;
				cdbcpystr((*lt)->LabelName, sym, 0);
				++lt;
				symbol = getsym();
				if ( !AuxError )
					return 1;	// exit_success
				goto LABEL_307;
			}
			__assert_fail("lti < no_ltabs", "loadstate.c", 221, "loadstate");
		}
		goto LABEL_307;
		break;

	case 2230:		// we hit a variable name as an lvalue
		
		allptpt(getptabp((*a1)++), &ptab1);
		ptab1->SrcLineNo = lla;
		v82 = getenmem();
		allenpt(v82, &entb);
		if ( !gettfexp(v82) )
		{
			ptab1->OpCode = 400;	// no-op?
			AuxError = 1;
            dallenpt(&entb);
            dallptpt(&ptab1);
			goto LABEL_307;
		}
		switch (symbol)
		{

		// we found an accept field
		case 50:							// "+"
		case 930:							// <CR> not sure this is correct....
		case 2200:							// string literal
		case 2230:							// another variable?
			v93 = leaccept(v82);
            if ( v93 )
			{
				ptab1->OpCode = 1;
                ptab1->TABno = v93;
				if ( yflag )
					prdatefield(v82, v93, 0);
	            dallenpt(&entb);
	            dallptpt(&ptab1);
				if ( !AuxError )
					return 1;
			}
			else
			{
				AuxError = 1;
				dallenpt(&entb);
				dallptpt(&ptab1);
			}
			goto LABEL_307;
			break;
		// variable assignment follows
		case 40:							// 40 "+="
		case 320:							// "/="
		case 850:							// %=
		case 880:							// "*="
		case 1160:				            // **=
		case 1560:							// -=
		case 1800:							// 1800 "=" or "eq" or "=="
			FieldNo = gettfs(v82, &TTno, &FieldType, (short *)&a4);
            if ( FieldNo < 0 )
				__assert_fail("fno >= 0", "loadstate.c", 459, "loadstate");
			v113 = 0;
			if ( FieldType == 'B' || FieldType == 'I' || FieldType == 'N' )
				v113 = 1;
            v112 = getenmem();
            allenpt(v112, &v115);
            v115->Dest = v82;
			switch (symbol)
			{
			case 880:					// "*="
				v115->TTno = 0xE000u;
				break;
			case 1560:					// "-="
				v115->TTno = 0xDC00u;
				break;
			case 1800:					// "=" or "==" or "eq"
				v115->TTno = 0xA800u;
				break;
			case 1160:					// "**="
				v115->TTno = 0xEC00u;
				break;
			case 320:					// "/="
				v115->TTno = 0xE400u;
				break;
			case 850:					// "%="
				v115->TTno = 0xE800u;
				break;
			case 40:					// 40 "+="
				v115->TTno = 0xD800u;
				break;
			default:
				__assert_fail("0", "loadstate.c", 472, "loadstate");
				break;
			}
            if ( a4 & 0x0040 )
			{
				loaderr(83, sym);	// "can't assign to read-only variable"
                AuxError = 1;
				dallenpt(&v115);
                dallenpt(&entb);
                dallptpt(&ptab1);
				goto LABEL_307;
			}
			v115->entype = 2;
                
			if ( FieldType == 'C' && isnumop(v115->TTno) )
				warncexp();            // "+-*%%/ will be unsupported on strings in future releases\n"
               
			symbol = getsym();
            if ( symbol == 930 )
            {
				loaderr(7, sym);	//  "unexpected end of line"
                AuxError = 1;
				dallenpt(&v115);
                dallenpt(&entb);
                dallptpt(&ptab1);
				goto LABEL_307;
			}
            ptab1->OpCode = 200;	// assignment operator
            v86 = loadexp(0, v113);
            if ( !v86 )
			{
				AuxError = 1;
				goto LABEL_285;
            }
            v115->Src = v86;
            if ( v113 && intexp(v115->Src) )
			{
				v87 = v115;
				v88 = v115->TTno | 0x0200;
            }
            else
			{
				if ( FieldType == 'C' || ( dpexp(v115->Dest) >= dpexp(v115->Src) ))
				{
LABEL_285:
					if ( !AuxError )
					{
						if ( symbol != 930 )
						{
							loaderr(33, sym);
							AuxError = 1;
						}
                        if ( !AuxError )
						{
							ptab1->TABno = v112;
                            if ( TTno )
								v92 = &ttab[TTno].TTfields[FieldNo];
							else
								v92 = getvars(FieldNo);
							v92->FLDstat |= 0x0008u;
						}
					}
					dallenpt(&v115);
	                dallenpt(&entb);
		            dallptpt(&ptab1);
					if ( !AuxError )
						return 1;
					goto LABEL_307;
				}
                v87 = v115;
				v88 = v115->TTno | 0x0040u;
			}
            v87->TTno = v88;
			goto LABEL_285;
			break;

		default:
			if ( symbol == 930 )
				loaderr(7 , sym);	// "unexpected end of line"
			else
				loaderr(33, sym);	// " unexpected symbol"
			AuxError = 1;
            dallenpt(&entb);
            dallptpt(&ptab1);
			goto LABEL_307;
			break;
		}
		break;

	default:
		loaderr(33, sym);	// "unexpected symbol" error exit
        symbol = getsym();
		break;
	}

// general exit
LABEL_307:
	if ( comp_abort )
		return 0;	// error_exit
	
	while ( symbol != 930 && symbol )	// symbol == 0 may mean EOF
		symbol = getsym();

	return 1;	// exit_success
}


#endif
