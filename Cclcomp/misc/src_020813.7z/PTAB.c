#ifndef PTAB_C
#define PTAB_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"

PTAB *PTARR(unsigned short PTABno)
{
  PTAB *ptab; // eax@1

  ptab = 0;
  if ( PTABno )
    ptab = (PTAB *)&ptarr.TableAddr[8 * (PTABno - 1)];
  return ptab;
}

#endif
