#ifndef UPDTUPL_C
#define UPDTUPL_C

#include "DBdefs.h"
#include "cl4.h"

// not public in libcl4

bool inlist_0(short *a1, short a2)
{
	short *v2;

	//printf("inlist_0(List: x%08X, a2: %d)\n",a1,a2);
	v2 = a1;
	while( *v2 )
	{
		if (*v2++ == a2)
			return true;
	}
	return false;
}

int _uptuple(char *Dest, char *Buffer, char *a3, POS *Pos, TDef *TDefPtr, short *a6)
{
	TDef *tdef;
	char *i;
	char *v9;
	size_t v10;
	short v11;
	size_t v14;
	size_t NumBytes; 
	int v12;

	//printf("_uptuple(Dest: x%08X,Buffer: x%08X,a3: x%08X,POS: x%08X, TDefPtr: x%08X, a6: x%08X)\n" ,Dest,Buffer,a3,Pos,TDefPtr,a6);

	tdef = TDefPtr;
	for ( i = Dest; tdef->TDFentry; ++tdef )
	{
		if ( tdef->TDFtype & 2 )	// string variable
			NumBytes = _fwidth(Buffer, tdef->TDFsize, tdef->TDFtype);
		else
			NumBytes = tdef->TDFsize;
    
		if ( Pos )
		{
			v11 = cdbrindex(Pos, tdef->TDFentry);
			if ( v11 >= 0 )
				v12 = xtodom(i, tdef->TDFsize, tdef->TDFtype, &a3[v11]);
			else
				v12 = cpybuf(i, Buffer, NumBytes);
			i += v12;
		}
		else
		{
			if ( !a6 || inlist_0(a6, tdef->TDFentry) )
			{
				if ( tdef->TDFtype & 2 )
					v14 = _fwidth(a3, tdef->TDFsize, tdef->TDFtype);
				else
					v14 = tdef->TDFsize;
				v9 = a3;
			}
			else
			{
				v14 = NumBytes;
				v9 = Buffer;
			}
			i += cpybuf(i, v9, v14);
			a3 += tdef->TDFsize;
		}
		Buffer += NumBytes;
	}
	return i - Dest;
}

#endif
