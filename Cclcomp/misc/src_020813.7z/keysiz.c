#ifndef KEYSIZ_C
#define KEYSIZ_C

#include "DBdefs.h"
#include "cl4.h"

int _keysize(TDef *tdef)		// distinctly different to keysize(TDno);
{
	int KeySize;

	for ( KeySize = 0; tdef->TDFentry && (tdef->TDFtype & 1); ++tdef )
		KeySize += tdef->TDFsize;
	return KeySize;
}

int _keymin(TDef *tdef)
{
	int KeyMin; // ecx@1
	short TDFtype; // ax@2

	KeyMin = 0;
	for ( TDFtype = tdef->TDFtype; tdef->TDFentry && (TDFtype & 1); tdef++, TDFtype = tdef->TDFtype )
	{
		if ( TDFtype & 2 )		// String field == variable length
			KeyMin++;			// Minimum size = 1 byte (for the \0 terminator) 
		else
			KeyMin += tdef->TDFsize;
		tdef++;
	}
	return KeyMin;
}

#endif
