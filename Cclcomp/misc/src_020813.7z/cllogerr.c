#ifndef CLLOGERROR_C
#define CLLOGERROR_C

void cllogerr(int ErrorCode, char *ProgName, char *DBASEname, char *TABLEname)
{
	char *v4; // eax@3
	char *v5; // eax@3
	char *TimeStamp; // edi@8
	__pid_t PID; // esi@8
	__uid_t UID; // ST14_4@8
	char *v9; // eax@9
	FILE *stream; // [sp+28h] [bp-D0h]@5
	time_t timer; // [sp+2Ch] [bp-CCh]@8
	char v14[32]; // [sp+30h] [bp-C8h]@6
	char v15[32]; // [sp+50h] [bp-A8h]@3
	char FileName[80]; // [sp+70h] [bp-88h]@3

	if ( ErrorCode != 15 || !isCGI )
	{
		fflush(stderr);
		v4 = ttyname(2);
		cdbcpystr(v15, v4, 0);
		v5 = getevar("CLELOG");
		cdbcpystr(FileName, v5, 0);
		if ( !FileName[0] )
			cdbcpystr(FileName, "CLELOG", 0);
		stream = fopen64(FileName, "a+");
		if ( stream )
		{
			cdbcpystr(v14, v15, 0);
			if ( !v14[0] )
				cdbcpystr(v14, "bkgnd", 0);
			time(&timer);
			TimeStamp = ctime(&timer);
			PID = getpid();
			UID = getuid();
			fprintf(stream, "%s(%s): tty=%s, uid=%d, pid=%d, %s", _pname, ProgName, v14, UID, PID, TimeStamp);
			if ( ErrorCode >= 0 )
			{
				if ( ErrorCode <= 0 )
				{
					if ( DBASEname && *DBASEname )
						fprintf(stream, "\t%s\n", DBASEname);
					if ( !TABLEname || !*TABLEname )
					{	
						fflush(stream);
						fclose(stream);
						return;
					}
					fprintf(stream, "\t%s\n", TABLEname);
				}
				else
				{
					fprintf(stream, "\tSignal %d\n", -ErrorCode);
				}
			}
			else
			{
				v9 = "INTERNAL";
				if ( DBASEname )
					v9 = "DBASE";
				fprintf(stream, "\t%s err %d ", v9, -ErrorCode);
				if ( DBASEname && *DBASEname )
				{
					fprintf(stream, "Database: [%s] ", DBASEname);
					if ( TABLEname )
						fprintf(stream, "Table: [%s]", TABLEname);
				}
				fputc('\n', stream);
			}
			fflush(stream);
			fclose(stream);
			return;
		}
	}
}

#endif
