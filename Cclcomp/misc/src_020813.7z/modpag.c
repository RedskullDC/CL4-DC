#ifndef MODPAGE_C
#define MODPAGE_C

#include "DBdefs.h"
#include "cl4.h"

short modpage(NODE *Node, short ModpNo, char *RecBuffer, short a4)
{
	NODE_1 *N1p;
	int v5;

	N1p = &Node->NODE1ptr[ModpNo];
	N1p->Data = RecBuffer;
	v5 = (a4 - N1p->Size);
	N1p->Size = a4;
	Node->DataEnd += v5;
	return v5;
}

#endif

