#ifndef STEPFWD_C
#define STEPFWD_C

#include "DBdefs.h"
#include "cl4.h"
int findnxt( TDinfo *TDptr)
{
	PAGE *PagePtr;
	int v2;
	char *v3;
	int v4;
	short Depth;
	int PageNo;
	short N1_2idx;

	//printf("findnxt(TDptr: x%08X)\n", TDptr);
	PageNo = 0;
	Depth = _rhead(TDptr->TDDBinfo, TDptr->TDindexOff, &PageNo);
	for ( TDptr->Key1Size = 0; Depth > 1; --Depth )
	{
		PagePtr = _indexpg(TDptr, PageNo);
		if ( _scanpg(PagePtr, TDptr, &N1_2idx, TDptr->field_3A | 8) )
			++N1_2idx;
		
		PageNo = mstol((int *)&PagePtr->DataStart[4 * N1_2idx]);
		if ( N1_2idx != PagePtr->NumEntries )
		{
			v2 = _itosz(PagePtr, N1_2idx);
			v3 = _itoptr(PagePtr, N1_2idx);
			v4 = TDptr->TDKeySize;
			if ( v4 > (unsigned int)v2 )
				v4 = v2;
			TDptr->Key1Size = cpybuf(TDptr->KeyBuf1, v3, v4);
		}
	}
	return PageNo;
}

NODE_1*	_stepfwd(TDinfo *TDptr)
{
	short v1;
	int PageNo;
	NODE_1 *result;
	NODE *NodePtr;
	NODE *v5;
	short N1idx;

	//printf("_stepfwd(TDptr: x%08X)\n", TDptr);

	if ( TDptr->TDNodePtr && TDptr->TDNodePtr->NumEntries > TDptr->N1_2idx ) // Node loaded, and entries left
	{
LABEL_9:
		//printf("_stepfwd: NodePtr set, NumEntries = %3d, N1_2idx = %3d\n",TDptr->TDNodePtr->NumEntries, TDptr->N1_2idx);
		v5 = TDptr->TDNodePtr;
		N1idx = TDptr->N1_2idx;
		TDptr->N1_2idx = N1idx + 1;                 // Next Record
		result = &v5->NODE1ptr[N1idx];
	}
	else
	{
		while ( 1 )
		{
			//printf("_stepfwd: NodePtr not set, or NumEntries <= N1_2idx\n");
			v1 = cpybuf(TDptr->TDKeyDefs, TDptr->KeyBuf1, TDptr->Key1Size);
			TDptr->KeyDefSize = v1;
			if ( TDptr->TDNodePtr )
			{
				if ( !v1 )
					break;
			}
			PageNo = findnxt(TDptr);
			if ( !PageNo )
				break;
			//printf("_stepfwd: PageNo = x%04X (%3d)\n", PageNo, PageNo);
			relnode(TDptr->TDNodePtr);
			NodePtr = getnode(TDptr, PageNo, 0);
			TDptr->TDNodePtr = NodePtr;
			_scanpg((PAGE *)NodePtr, TDptr, &TDptr->N1_2idx, TDptr->field_3A);
			TDptr->field_3A = 1;
			if ( TDptr->TDNodePtr && TDptr->TDNodePtr->NumEntries > TDptr->N1_2idx )
				goto LABEL_9;
		}
		result = 0;     // \0 means we have reached the end of the line. No more data!
	}
	return result;
}

#endif
