#ifndef SPLIT_C
#define SPLIT_C

#include "DBdefs.h"
#include "cl4.h"

int _split(TDinfo *TDptr, NODE *Node, NODE *Node2, short N1_2idx2, char **a5)
{
	NODE *NewNODE; // edi@2
	int v6; // ST0C_4@7
	int v8; // [sp+24h] [bp-14h]@1

   //printf("_split(TDptr: x%08X, Node: x%08X, Node2: x%08X,N1_2idx: %d, a5 = x%08X)\n",TDptr,Node,Node2,N1_2idx2,a5);

	v8 = 0;
	if ( TDptr->TDDBinfo->DBpgsize < Node->DataEnd )// Node data won't fit in one page!!
	{
		do
		{
			NewNODE = freshnode(TDptr, Node->PageType);
			if ( NewNODE->DataEnd < TDptr->HalfPageSize || TDptr->TDDBinfo->DBpgsize < Node->DataEnd )
			{
				while ( TDptr->TDDBinfo->DBpgsize >= (Node->NODE1ptr[Node->NumEntries - 1].Size + NewNODE->DataEnd + NewNODE->field_16) )
				{
					moveright(Node, NewNODE, 1);
					if ( NewNODE->DataEnd >= TDptr->HalfPageSize && TDptr->TDDBinfo->DBpgsize >= Node->DataEnd )
							break;
				}
			}
			v6 = _promote(a5[v8], Node, NewNODE, Node2->PageType & 1, TDptr);
			addpage(Node2, N1_2idx2, a5[v8], v6);
			Node2->NODE2ptr[N1_2idx2 + 1].PageNo = NewNODE->PageNo;
			putnode(TDptr, NewNODE);
			relnode(NewNODE);
			v8++;
		}
		while ( v8 <= 1 && TDptr->TDDBinfo->DBpgsize < Node->DataEnd );
	}
	if ( v8 )
	{
		Node2->NODE2ptr[N1_2idx2].PageNo = _repos(TDptr, Node);
	}
	else
	{
		putnode(TDptr, Node);
		_lockpg(TDptr->TDDBinfo, Node->PageNo, 0);
	}
	relnode(Node);
	return v8;
}

#endif
