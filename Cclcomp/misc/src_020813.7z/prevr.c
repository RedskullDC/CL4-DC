#ifndef PREVREC_C
#define PREVREC_C

#include "DBdefs.h"
#include "cl4.h"

//*not* public in libcl4

int _prevr(int TDNo, char *WorkArea,short SkipRecs, POS *Pos, EXPR *SelectExpr)
{
	TDinfo *v5; // eax@1
	TDinfo *TDptr; // esi@1
	int v7; // eax@1
	int v8; // edx@3
	NODE_1 *v9; // edi@20
	int v11; // [sp+18h] [bp-10h]@12

	//printf("_prevr( TDno: x%04X (%3d),WorkArea = %s,SkipRecs = %d, POS = x%08X, EXPR: x%08X)\n", TDNo,TDNo,WorkArea,SkipRecs,Pos,SelectExpr);

	v5 = _chktd(TDNo);
	TDptr = v5;
	if ( v7 = check_bup_sem(v5->TDDBinfo))
		derror(v7, 0, TDptr);
	//printf("_prevr: v7 = %d\n", v7);
	v8 = 0;
	if ( (TDptr->field_0 & 0x210) != 0x210 )
	{
		if ( !(TDptr->field_0 & 0x0200) )
		{
			relnode(TDptr->TDNodePtr);
			TDptr->TDNodePtr = 0;
			TDptr->field_0 |= 0x200u;
		}
		if ( TDptr->field_0 & 2 )
			return _pickprev(TDptr, WorkArea, SkipRecs, Pos);
		
		if ( !TDptr->KeyBuf1 )
			newseq(TDptr);
		
		if ( Pos )
			cdbrindex(Pos, 0);	// Pointless code?
		
		TDptr->Key1Size = 0;
		v11 = 0;
		if ( SkipRecs > 0 )
		{
			while ( 1 )
			{
				while ( 1 )
				{
					v9 = _stepbak(TDptr);
					if ( v9 )
						break;
LABEL_23:
					TDptr->field_0 |= 0x10u;
LABEL_24:
					if ( !(TDptr->field_0 & 0x10) )
					{
						if ( ++v11 < SkipRecs )
							continue;
					}
					v8 = v11;
					if ( !v11 )
					{
						relseq(TDptr);
						v8 = 0;
					}
					return v8;
				}
				
				if ( _match(v9->Data, SelectExpr, TDptr->TableDefs) )
					break;

				if ( _beyond(SelectExpr, 0x30u, v9->Data, TDptr->TableDefs) )
				{
					TDptr->field_0 |= 0x10u;
					if ( v9 )
						goto LABEL_24;
					goto LABEL_23;
				}
			}

			if ( !TDptr->Key1Size )
			{
				TDptr->Key1Size = cpybuf(TDptr->KeyBuf1, v9->Data, TDptr->TDKeySize);
				TDptr->field_3A = 2;
			}
			tuptor(WorkArea, Pos, v9->Data, TDptr->TableDefs);

			if ( v9 )
				goto LABEL_24;
			goto LABEL_23;
		}
		v8 = v11;
		if ( !v11 )
		{
			relseq(TDptr);
			v8 = 0;
		}
	}
	return v8;
}

// HACK! These should call through xenter()

int prevr(int TDno, char *WorkArea, POS *Pos, EXPR *Expr)
{
  return _prevr(TDno, WorkArea, 1, Pos, Expr);
}

int getprev(int TDno, char *WorkArea, EXPR *Expr)
{
  return _prevr(TDno, WorkArea, 1, 0, Expr);
}

int prevset(int TDno, char *WorkArea, int SkipRecs, POS *Pos, EXPR *Expr)
{
  return _prevr(TDno, WorkArea, SkipRecs, Pos, Expr);
}


#endif
