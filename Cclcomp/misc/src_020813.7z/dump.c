#ifndef DUMPENC_C
#define DUMPENC_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"
int *__errno_location(void);

int dumpenc(char *EncFileName)
{
     TDesc *TTptr; // edi@5
     FLDdesc *fld; // esi@9
     TDesc *TTptr2; // edi@25
     FLDdesc *fld2; // esi@39
     int *v2; // eax@4
     int *v3; // esi@4
     char *v4; // eax@4
     short v7; // ax@12
     short v8; // dx@15
     char *v10; // esi@29
     ONESC *onesc; // edx@33
     short NumEscs; // si@33
     int v13; // edi@37
     unsigned short i; // edx@45
     PTAB *v16; // eax@47
     KXTAB *kx; // esi@55
     int j; // edi@58
     size_t v19; // esi@59
     short PTABno; // edx@62
     PTAB *v21; // ecx@63
     XTAB *xt; // eax@67
     int v23; // eax@70
     BTAB *v27; // esi@87
     BTAB *k; // esi@91
     char *ptr; // [sp+18h] [bp-20h]@58
     short NumTables; // [sp+20h] [bp-18h]@5
     short TempTables; // [sp+24h] [bp-14h]@5
     short count; // [sp+28h] [bp-10h]@5

    if ( !btab->BlockName[0] )
	{
        eprint("This is an empty ent file - nothing to compile!\n");
		return 1;
    }
    dp = fopen64(EncFileName, "w");
    if ( !dp )
	{
        v2 = __errno_location();
        v3 = v2;
        v4 = strerror(*v2);
        eprint("can't open %s for writing - %s\n", EncFileName, v4);
		return -*v3;
    }
    putucount(0x9DD3u);                        // 0x9DD4 = 40404 = version number
printf("dumpenc: version = %d\n",0x9dd3);
	putcount(tpenc);                           // Signify if this is a Portable enc
printf("dumpenc: portable = %s\n",tpenc? "true":"false");

    TempTables = 0;
    NumTables = 0;
    TTptr = ttab;
    count = 0;
    while ( no_ttabs > count )
	{
		if ( TTptr->TableName[0] )
        {
			NumTables++;
            if ( TTptr->TDlocked & 0x0200 )	// Temporary table flag
				TempTables++;
			fld = TTptr->TTfields;
            if ( isclcomp )
            {
				while ( fld->FLDelemID )
				{
					if ( fld->FLDtype == 'S' )
						TTptr->TDlocked |= 0x4000;	// Sub Records flag bit = 0x4000
					else
					{
						// Key Tables flag bit = 0x0010
						if ( fld->FLDtype != 'K' || findtd(fld->FLDname, -1) <= 0 || (v8 = TTptr->TDlocked | 0x0010, TTptr->TDlocked = v8, !(v8 & 0x0006)) )
							goto LABEL_18;
						TTptr->TDlocked = v8 | 0x0008;	// ????
					}
LABEL_18:
					++fld;
				}
			}
		}
		++count;
        ++TTptr;
    }
//==================================
	if ( isclcomp )
    {
		eprint("%5d open tables\n", NumTables - TempTables);
		if ( TempTables )
            eprint("%5d temp tables\n", TempTables);
    }
printf("dumpenc: open tables = %d [x%04X]\n",NumTables,NumTables);
    putcount(NumTables);		// Open Tables
    TTptr2 = ttab;
    count = 0;
    while ( no_ttabs > count )
	{
		if ( TTptr2->TableName[0] )
        {
			puttext(dtab[TTptr2->DBnumber].FullDBname, 0);
            if ( TTptr2->TDlocked & 0x40 )
				puttext("locking", 0);
            v10 = mstrcpy(TTptr2->TableName, "," ,TTptr2->TableAlias, 0);
            puttext(v10, 0);
            mfree_0(v10);
            putbits(TTptr2->TDlocked);
            if ( notabchks )
				TTptr2->TableCRC = 0;	// Ignore CRC of tables. dangerous!!
			putcount(TTptr2->TableCRC);
		}
        ++count;
        ++TTptr2;
	}
//-----------------------------------
// Dump Global Escapes next
    onesc = oelist;
    for ( NumEscs = 0; onesc; ++NumEscs )
		onesc = onesc->NextESC;
	putcount(NumEscs);
printf("dumpenc: Global Escapes = %d [x%04X]\n",NumEscs,NumEscs);
    if ( NumEscs )
		dumpoe(oelist);
//-----------------------------------
// Dump Variables
	v13 = last_var;
    if ( isclcomp )
		eprint("%5d variables\n", last_var);
    putcount(v13);
printf("dumpenc: Variables = %d [x%04X]\n",v13,v13);
    putftabs(ttab->TTfields, v13);			// **** puts too many to disk??? ****
    
	fld2 = ttab->TTfields;                     // Variables hang off Table 0 as regular fields
    count = v13 - 1;
    while ( count >= 0 )
	{
		if ( !(fld2->FLDstat & 0x0004) )	// check quick zero flag.
        {
			if ( fld2->FLDtype == 'C' )
			{
				puttext((char *)fld2->FLDdata, fld2->FLDlen);
				printf("dumpenc: Var# %d [%s], String = [%s], Length = %d [x%04X]\n",count,fld2->FLDname,(char *)fld2->FLDdata,fld2->FLDlen,fld2->FLDlen);
			}
			else
			{
				putdouble(*(double *)fld2->FLDdata, fld2->TDFtype);
				printf("dumpenc: Var# %d [%s], Double = [%G], Length = %d [x%04X]\n",count,fld2->FLDname,*(double *)fld2->FLDdata,fld2->FLDlen,fld2->FLDlen);
			}
		}
        ++fld2;
        --count;
	}
//-------------------------------------------
// Next dump number of program steps
    count = 0;
    for ( i = getptabp(0); ; i = getptabp(count) )
    {
		v16 = i ? (PTAB *)&ptarr.TableAddr[8 * (i - 1)] : 0;
		if ( !v16->OpCode )
			break;
		count++;
	}
    if ( isclcomp )
		eprint("%5d steps\n", count);
printf("dumpenc: Steps = %d [x%04X]\n",count,count);

// Dump program steps array
printf("dumpenc: putptabs\n");
	putptabs(&ptarr);

//-------------------------------------------
// Next dump program nodes
    if ( isclcomp )
		eprint("%5d nodes\n", enarr.NextElement);
	putenodes(&enarr);                         // enodes = expressions

printf("dumpenc: putxtabs\n");
    putxtabs(&xtarr);                          // Accept field defs
printf("dumpenc: putrtabs\n");
    putrtabs(&rtarr);                          // Redisplay defs
printf("dumpenc: putratabs\n");
    putratabs(&raarr);                         // Range Defs
printf("dumpenc: putxftabs\n");
    putxftabs(&xfarr);                         // XFER defs.  Copy command defs
printf("dumpenc: putsftabs\n");
    putsftabs(&sfarr);                         // FCBs:  Files we open/read/write
printf("dumpenc: putprtabs\n");
    putprtabs(&prarr);                         // print statements
printf("dumpenc: putrdtabs\n");
    putrdtabs(&rdarr);                         // read statements
printf("dumpenc: putkxtabs\n");
    putkxtabs(&kxarr);                         // Create statement defs
    
	count = 0;
	while ( count < kxarr.NextElement ) // kx = Create statements
    {
		kx = (KXTAB *)&kxarr.TableAddr[64 * count];
        putcount(kx->NumKeyFields);
        putarrcount(kx->KeyElemIDs, kx->NumKeyFields);
        putarrcount(kx->TkeyTy, kx->NumKeyFields);
        putcount(kx->NumDataFields);
        putarrcount(kx->DataElemIDs, kx->NumDataFields);
        putcount(kx->NumTTs);
        putarrtds(kx->TTlist, kx->NumTTs);
        count++;
	}
    if ( isclcomp )
		eprint("%5ld strings\n", strarr.StrTableSize);
    putLong(strarr.StrTableSize);              // 4 bytes of string table size
    ptr = strarr.StringTable;
    for ( j = strarr.StrTableSize; j; j -= v19 )
    {
		v19 = 15000;                          // Dump 15000 bytes at a time
        if ( j < 15001 )
			v19 = j;
		putbuf(ptr, v19);
        ptr += v19;
	}
    
	count = 0;
    for ( PTABno = (unsigned short)getptabp(0); ; PTABno = (unsigned short)getptabp(count) )
    {
		v21 = PTABno ? (PTAB *)&ptarr.TableAddr[8 * (PTABno - 1)] : 0;
		if ( !v21->OpCode )
			break;
		if ( (unsigned short)(v21->OpCode - 1) > 48u )
        {
			v23 = v21->OpCode;
            if ( v23 == 250 || v23 == 260 )  // 250 = refresh, 260 = screen
            {
				if ( v21->TABno )  // 250 = refresh, 260 = screen
					puttext(v21->TABno ? &strarr.StringTable[v21->TABno - 1] : 0, 0);		// Save a "screen_name" here
			}
            else
            {
				if ( (unsigned short)(v21->OpCode - 650) <= 48u && v21->TABno )
					putbuf(v21->TABno ? &strarr.StringTable[v21->TABno - 1] : 0, 20u);      // Put a block name here? (max 20chars)
			}
		}
        else
        {
			xt = v21->TABno ? (XTAB *)&xtarr.TableAddr[52 * (v21->TABno - 1)] : 0;
			dumpoe(xt->onesc);	// Dump On-Escape
		}
		++count;
	}
    
	v27 = btab;
    for ( count = 0; v27->BlockName[0]; ++v27 )
		count++;
	if ( isclcomp )
		eprint("%5d process blocks\n", count);
printf("dumpenc: putbtabs\n");
	putbtabs(count);
printf("dumpenc: onEscapes:\n");
    for ( k = btab; k->BlockName[0]; ++k )
    {
		dumpscr(k->TYPE24);                   // screens
        dumpoe(k->On_delete);                 // global escapes follow for this block
        dumpoe(k->On_exit);
        dumpoe(k->On_excep);
        dumpoe(k->On_entry);
	}
    fclose(dp);
    return 0;
}

#endif
