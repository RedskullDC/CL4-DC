#ifndef DIFFAT_C
#define DIFFAT_C

#include "DBdefs.h"
#include "cl4.h"

// only called by _diffkey()
int _diffattrib(char *a1, char *a2, unsigned int a3, short TDFtype)
{
	char *v4; // eax@2
	unsigned int i; // edi@3
	unsigned char v6; // eax@4
	unsigned char v7; // esi@4
	unsigned char v8; // ecx@6
	unsigned char v9; // zf@9

    //printf("_diffattrib(a1: x%08X, a2: x%08X, a3 = %d, TDFtype: x%04X)\n" ,a1,a2,a3,TDFtype);

	if ( TDFtype & 0x4000 )
	{
		v4 = a1;	// swap src and dest ??
		a1 = a2;
		a2 = v4;
	}
	for ( i = 0; i < a3; ++i )
	{
		v6 = a1[i];
		v7 = a2[i];
		if ( v6 != v7 )
		{
			if ( !(TDFtype & 8) )
				break;
			v8 = v6;					// check for a match between upper/lower case
			if ( (v6 - 65) <= 0x19u )
				v8 += 32;
			v9 = (v7 - 65) > 0x19u ? v8 == v7 : v8 == v7 + 32;
			if ( !v9 )
				break;
		}
	}
	return i;	// return number of chars that matched. same as a3 if equal
}

#endif



