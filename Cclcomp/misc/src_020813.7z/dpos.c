#ifndef DPOS_C
#define DPOS_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"


void _dpos(DPOS *dpos, int PageNo, short Depth, TDinfo *TDptr)
{
	int PageNo2;
	short v5;
	PAGE *v6;

	PageNo2 = PageNo;
	dpos->field_8 = 0;
	dpos->NumEntries = 0;
	
	v5 = Depth - 1;		// How many branches does the tree descend into...
	while ( v5 > 0 )
	{
		v6 = _indexpg(TDptr, PageNo2);
		dpos->field_8 = PageNo2;
		dpos->NumEntries = v6->NumEntries;
		PageNo2 = mstol(&v6->DataStart[4 * dpos->NumEntries]);
		--v5;
	}
	
	dpos->PageNo = PageNo2;
	dpos->field_4 = 0;
}

#endif
