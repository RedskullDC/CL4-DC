#ifndef ALLLOWER_C
#define ALLLOWER_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include <ctype.h>      // for islower() and toupper() functions
#include "DBdefs.h"
#include "cl4.h"

void alltoupper(char *a1)
{
	char *v1; // esi@1
	int v2; // edi@3
	const unsigned short **v3; // [sp+8h] [bp-10h]@2

    v3 = __ctype_b_loc();
	v1 = a1;
	while ( *v1 )
	{
		v2 = *v1;
		if ((*v3)[v2] & 0x0200 )
			*v1 = toupper(v2);
		++v1;
	}
}

bool alllower(char *a1)
{
	bool result; // eax@2
	char *v2; // esi@5
	const unsigned short **v3; // edi@6
	unsigned short v4; // dx@7
	signed short v5; // [sp+8h] [bp-10h]@1
  
  v3 = __ctype_b_loc();

  v5 = 0;
  if ( (*v3)[*a1] & 0x0400 )
  {
    if ( (*v3)[*a1] & 0x0200 )
      v5 = 1;
    v2 = a1 + 1;
    if ( a1[1] )
    {
      while ( 1 )
      {
        v4 = (*v3)[*v2];
        if ( !(v4 & 0x0800) )
        {
          result = 0;
          if ( v4 & 0x0100 )
            break;
        }
        if ( (*v3)[*v2] & 0x0200 )
          ++v5;
        ++v2;
        if ( !*v2 )
          goto LABEL_12;
      }
    }
    else
    {
LABEL_12:
      result = v5 > 0;
    }
  }
  else
  {
    result = 0;
  }
  return result;
}

#endif
