#ifndef TABLES_C
#define TABLES_C

#include <stdio.h>
#include <stdarg.h>		// for var args stuff
#include "DBdefs.h"
#include "cl4.h"


void allptpt(unsigned short PTno, PTAB **a2)
{
     signed int v2; // eax@1
     PTAB *v3; // eax@3

     v2 = 29;
     while ( ptptrs[v2] )
     {
          --v2;
          if ( v2 < 0 )
          {
               fwrite("allptpt: no pointer space available\n", 1u, 0x24u, stderr);
               exit(1);
          }
     }
     ptptrs[v2] = a2;
     v3 = 0;
     if ( PTno )
          v3 = (PTAB *)&ptarr.TableAddr[8 * (PTno - 1)];
     *a2 = v3;
}

void dallptpt(PTAB **ptab)
{
     signed int v1; // eax@1

     v1 = 29;
     while ( ptptrs[v1] != ptab )
     {
          --v1;
          if ( v1 < 0 )
               return;
     }
     ptptrs[v1] = 0;
}

void allxtpt(short a1, XTAB **xtp)
{
     signed int v2; // edx@1
     XTAB *xt; // eax@3

     v2 = 29;
     while ( xtptrs[v2] )
     {
          --v2;
          if ( v2 < 0 )
          {
               fwrite("allxtpt: no pointer space available\n", 1u, 0x24u, stderr);
               exit(1);
          }
     }
     xtptrs[v2] = xtp;
     xt = 0;
     if ( a1 )
          xt = (XTAB *)&xtarr.TableAddr[52 * (a1 - 1)];
     *xtp = xt;
}

void dallxtpt(XTAB **xtp)
{
     int v1; // eax@1

     v1 = 29;
     while ( xtptrs[v1] != xtp )
     {
          --v1;
          if ( v1 < 0 )
               return;
     }
     xtptrs[v1] = 0;
}

void movextptrs(XTAB *old, XTAB *New)
{
     signed int v2; // ecx@1
     XTAB **v3; // edx@3

     v2 = 29;
     do
     {
          if ( xtptrs[v2] )
          {
               v3 = xtptrs[v2];
               *v3 = (XTAB *)((char *)New + (((char *)*v3 - (char *)old)));
          }
          --v2;
     }
     while ( v2 >= 0 );
}
short getxtmem(void)
{
     CLArrayPtr *v0; // edi@1
     short v1; // ax@3
     int v2; // ecx@4
     short v3; // ax@4
     XTAB *v4; // esi@4
     XTAB *v5; // eax@4

     v0 = &xtarr + (unsigned short)curxtarr;
     if ( !v0->MaxAvail )
          v0->TableAddr = (char *)mmalloc(0);
     v1 = v0->NextElement;
     if ( v1 == v0->MaxAvail )
     {
          v2 = v0->MaxAvail;
          v3 = v1 + 50;
          v0->MaxAvail = v3;
          v4 = (XTAB*)v0->TableAddr;
          v5 = (XTAB*)mrealloc(v0->TableAddr, 52 * v2, 52 * (unsigned short)v3);
          v0->TableAddr = (char *)v5;
          movextptrs(v4, v5);
     }
     v0->NextElement++;
     return v0->NextElement;
}

short getptmem()
{
	CLArrayPtr *v0; // edi@1
	short v1; // ax@3
	short v2; // edx@4
	short v3; // ax@4
	PTAB	*v4; // esi@4
	PTAB	*v5; // eax@4

	v0 = &ptarr + curptarr;
	if ( !v0->MaxAvail )
		v0->TableAddr = (char *)mmalloc(0);
	v1 = v0->NextElement;
//printf("getptmem 139 v1 = %d, MaxAvail = %d\n",v1, v0->MaxAvail);
	if ( v1 == v0->MaxAvail )
	{
		//printf("getptmem 144 v1(%d) == MaxAvail(%d)\n",v1, v0->MaxAvail);
		v2 = v0->MaxAvail;
		v3 = v1 + 1500;                             // alloc in blocks of 1500
		v0->MaxAvail = v3;
		v4 = (PTAB*)v0->TableAddr;
		v5 = (PTAB*)mrealloc(v0->TableAddr, 8 * v2, 8 * (unsigned short)v3);
		v0->TableAddr = (char*)v5;
		moveptptrs(v4, v5);
	}
	v0->NextElement++;
//printf("getptmem 154 MaxAvail = %d, NextElement = %d\n", v0->MaxAvail,v0->NextElement);
	return v0->NextElement;
}

void moveptptrs(PTAB *a1, PTAB *a2)
{
     signed int v2; // ecx@1
     PTAB **v3; // edx@3

     v2 = 29;
     do
     {
          if ( ptptrs[v2] )
          {
               v3 = ptptrs[v2];
               *v3 = (PTAB *)((char *)a2 + ((char *)*v3 - (char *)a1));
          }
          --v2;
     }
     while ( v2 >= 0 );
}
short getxfmem()
{
     CLArrayPtr *v0; // edi@1
     short v1; // ax@3
     int v2; // edx@4
     short v3; // ax@4
     XFTAB *xft_old; // esi@4
     XFTAB *xft_new; // eax@4
     short result; // ax@5

     v0 = &xfarr + (unsigned short)curxfarr;
     if ( !v0->MaxAvail )
          v0->TableAddr = (char *)mmalloc(0);
     v1 = v0->NextElement;
     if ( v1 == v0->MaxAvail )
     {
          v2 = v0->MaxAvail;
          v3 = v1 + 10;
          v0->MaxAvail = v3;
          xft_old = (XFTAB *)v0->TableAddr;
          xft_new = (XFTAB *)mrealloc(v0->TableAddr, 8 * v2, 8 * (unsigned short)v3);
          v0->TableAddr = (char *)xft_new;
          movexfptrs(xft_old, xft_new);
     }
     result = v0->NextElement + 1;
     v0->NextElement = result;
     return result;
}

void allxfpt(unsigned short XFno, XFTAB **a2)
{
     signed int v2; // eax@1
     XFTAB *v3; // eax@3

     v2 = 29;
     while ( xfptrs[v2] )
     {
          --v2;
          if ( v2 < 0 )
          {
               fwrite("allxfpt: no pointer space available\n", 1u, 0x24u, stderr);
               exit(1);
          }
     }
     xfptrs[v2] = a2;
     v3 = 0;
     if ( XFno )
          v3 = (XFTAB *)&xfarr.TableAddr[8 * (XFno - 1)];
     *a2 = v3;
}
void dallxfpt(XFTAB **xftab)
{
     signed int v1; // eax@1

     v1 = 29;
     while ( xfptrs[v1] != xftab )
     {
          --v1;
          if ( v1 < 0 )
               return;
     }
     xfptrs[v1] = 0;
}

void movexfptrs(XFTAB *xft_from, XFTAB *xft_to)
{
     signed int v2; // ecx@1
     XFTAB **v3; // edx@3

     v2 = 29;
     do
     {
          if ( xfptrs[v2] )
          {
               v3 = xfptrs[v2];
               *v3 = (XFTAB *)((char *)xft_to + ((char *)*v3 - (char *)xft_from));
          }
          --v2;
     }
     while ( v2 >= 0 );
}
short getenmem()
{
     CLArrayPtr *v0; // edi@1
     short v1; // ax@3
     int v2; // edx@4
     short v3; // ax@4
     ENTAB *v4; // esi@4
     ENTAB *v5; // eax@4

     v0 = &enarr + (unsigned short)curenarr;
     if ( !v0->MaxAvail )
          v0->TableAddr = (char *)mmalloc(0);
     v1 = v0->NextElement;
     if ( v1 == v0->MaxAvail )
     {
          v2 = v0->MaxAvail;
          v3 = v1 + 200;
          v0->MaxAvail = v3;
          v4 = (ENTAB *)v0->TableAddr;
          v5 = (ENTAB *)mrealloc(v0->TableAddr, 12 * v2, 12 * (unsigned short)v3);
          v0->TableAddr = (char *)v5;
          moveenptrs(v4, v5);
     }
     v0->NextElement++;
     return v0->NextElement;
}

void allenpt(short a1, ENTAB **a2)
{
     signed int v2; // edx@1
     ENTAB *v3; // eax@3

     v2 = 29;
     while ( enptrs[v2] )
     {
          --v2;
          if ( v2 < 0 )
          {
               fwrite("allenpt: no pointer space available\n", 1u, 0x24u, stderr);
               exit(1);
          }
     }
     enptrs[v2] = a2;
     v3 = 0;
     if ( a1 )
          v3 = (ENTAB *)&enarr.TableAddr[12 * (a1 - 1)];
     *a2 = v3;
}
void dallenpt(ENTAB **a1)
{
     signed int v1; // eax@1

     v1 = 29;
     while ( enptrs[v1] != a1 )
     {
          --v1;
          if ( v1 < 0 )
               return;
     }
     enptrs[v1] = 0;
}
void moveenptrs(ENTAB *a1, ENTAB *a2)
{
     signed int v2; // ecx@1
     ENTAB **v3; // edx@3

     v2 = 29;
     do
     {
          if ( enptrs[v2] )
          {
               v3 = enptrs[v2];
               *v3 = (ENTAB *)((char *)a2 + ((char *)*v3 - (char *)a1));
          }
          --v2;
     }
     while ( v2 >= 0 );
}

void allrdpt(unsigned short RDno, RDTAB **a2)
{
     signed int v2; // edx@1
     RDTAB *v3; // eax@3

     v2 = 29;
     while ( rdptrs[v2] )
     {
          --v2;
          if ( v2 < 0 )
          {
               fwrite("allrdpt: no pointer space available\n", 1u, 0x24u, stderr);
               exit(1);
          }
     }
     rdptrs[v2] = a2;
     v3 = 0;
     if ( RDno )
          v3 = (RDTAB *)&rdarr.TableAddr[12 * (RDno - 1)];
     *a2 = v3;
}

void dallrdpt(RDTAB **rdtb)
{
     signed int v1; // eax@1

     v1 = 29;
     while ( rdptrs[v1] != rdtb )
     {
          --v1;
          if ( v1 < 0 )
               return;
     }
     rdptrs[v1] = 0;
}

void moverdptrs(RDTAB *a1, RDTAB *a2)
{
     signed int v2; // ecx@1
     RDTAB **v3; // edx@3

     v2 = 29;
     do
     {
          if ( rdptrs[v2] )
          {
               v3 = rdptrs[v2];
               *v3 = (RDTAB *)((char *)a2 + ((char *)*v3 - (char *)a1));
          }
          --v2;
     }
     while ( v2 >= 0 );
}
short getrtmem(void)
{
     CLArrayPtr *v0; // edi@1
     short v1; // ax@3
     int v2; // edx@4
     short v3; // ax@4
     RTAB *v4; // esi@4
     RTAB *v5; // eax@4
     short result; // ax@5

     v0 = &rtarr + (unsigned short)currtarr;
     if ( !v0->MaxAvail )
          v0->TableAddr = (char *)mmalloc(0);
     v1 = v0->NextElement;
     if ( v1 == v0->MaxAvail )
     {
          v2 = v0->MaxAvail;
          v3 = v1 + 50;                         // alloc in blocks of 50
          v0->MaxAvail = v3;
          v4 = (RTAB *)v0->TableAddr;
          v5 = (RTAB *)mrealloc(v0->TableAddr, 20 * v2, 20 * (unsigned short)v3);
          v0->TableAddr = (char *)v5;
          movertptrs(v4, v5);
     }
     result = v0->NextElement + 1;
     v0->NextElement = result;
     return result;
}

void dallrtpt(RTAB **a1)
{
     signed int v1; // eax@1

     v1 = 29;
     while ( rtptrs[v1] != a1 )
     {
          --v1;
          if ( v1 < 0 )
               return;
     }
     rtptrs[v1] = 0;
}

void allrtpt(unsigned short a1, RTAB **a2)
{
     signed int v2; // edx@1
     RTAB *v3; // eax@3

     v2 = 29;
     while ( rtptrs[v2] )
     {
          --v2;
          if ( v2 < 0 )
          {
               fwrite("allrtpt: no pointer space available\n", 1u, 0x24u, stderr);
               exit(1);
          }
     }
     rtptrs[v2] = a2;
     v3 = 0;
     if ( a1 )
          v3 = (RTAB *)&rtarr.TableAddr[20 * a1 - 20];
     *a2 = v3;
}

void movertptrs(RTAB *Old, RTAB *New)
{
     signed int v2; // ecx@1
     RTAB **v3; // edx@3

     v2 = 29;
     do
     {
          if ( rtptrs[v2] )
          {
               v3 = rtptrs[v2];
               *v3 = (RTAB *)((char *)New + ((char *)*v3 - (char *)Old));
          }
          --v2;
     }
     while ( v2 >= 0 );
}

void moveprptrs(PRTAB *a1, PRTAB *a2)
{
     signed int v2; // ecx@1
     PRTAB **v3; // edx@3

     v2 = 29;
     do
     {
          if ( prptrs[v2] )
          {
               v3 = prptrs[v2];
               *v3 = (PRTAB *)((char *)a2 + ((char *)*v3 - (char *)a1));
          }
          --v2;
     }
     while ( v2 >= 0 );
}

short getprmem()
{
     CLArrayPtr *v0; // edi@1
     short v1; // ax@3
     int v2; // edx@4
     short v3; // ax@4
     PRTAB *v4; // esi@4
     PRTAB *v5; // eax@4
     short result; // ax@5

    v0 = &prarr + (unsigned short)curprarr;
	//eprint("getprmem() - v0->MaxAvail = %d , v0->NextElement = %d\n",v0->MaxAvail,v0->NextElement);

    if ( !v0->MaxAvail )
		v0->TableAddr = (char *)mmalloc(0);
    v1 = v0->NextElement;
    if ( v1 == v0->MaxAvail )
    {
		v2 = v0->MaxAvail;
        v3 = v1 + 50;
        v0->MaxAvail = v3;
		//eprint("getprmem(realloc) - v0->MaxAvail = %d \n",v0->MaxAvail);
        v4 = (PRTAB *)v0->TableAddr;
        v5 = (PRTAB *)mrealloc(v0->TableAddr, 10 * v2, 10 * (unsigned short)v3);
		//eprint("getprmem(realloc) - v5 = x%08X\n",v5);
        v0->TableAddr = (char *)v5;
        moveprptrs(v4, v5);
	}
    result = v0->NextElement + 1;
    v0->NextElement = result;
	//eprint("getprmem - result = %d \n",result);
    return result;
}

void allprpt(unsigned short a1, PRTAB **a2)
{
     signed int v2; // edx@1
     PRTAB *v3; // eax@3

     v2 = 29;
     while ( prptrs[v2] )
     {
          --v2;
          if ( v2 < 0 )
          {
               fwrite("allprpt: no pointer space available\n", 1u, 0x24u, stderr);
               exit(1);
          }
     }
     prptrs[v2] = a2;
     v3 = 0;
     if ( a1 )
          v3 = (PRTAB *)&prarr.TableAddr[10 * a1 - 10];
     *a2 = v3;
}

void dallprpt(PRTAB **a1)
{
     signed int v1; // eax@1

     v1 = 29;
     while ( prptrs[v1] != a1 )
     {
          --v1;
          if ( v1 < 0 )
               return;
     }
     prptrs[v1] = 0;
}

short getsfmem()
{
     CLArrayPtr *v0; // edi@1
     short v1; // ax@3
     int v2; // edx@4
     short v3; // ax@4
     SFTAB *v4; // esi@4
     SFTAB *v5; // eax@4
     short result; // ax@5

     v0 = &sfarr + cursfarr;
     if ( !v0->MaxAvail )
          v0->TableAddr = (char *)mmalloc(0);
     v1 = v0->NextElement;
     if ( v1 == v0->MaxAvail )
     {
          v2 = v0->MaxAvail;
          v3 = v1 + 10;
          v0->MaxAvail = v3;
          v4 = (SFTAB *)v0->TableAddr;
          v5 = (SFTAB *)mrealloc(v0->TableAddr, 8 * v2, 8 * (unsigned short)v3);
          v0->TableAddr = (char *)v5;
          movesfptrs(v4, v5);
     }
     result = v0->NextElement + 1;
     v0->NextElement = result;
     return result;
}
void allsfpt(unsigned short a1, SFTAB **a2)
{
     signed int v2; // eax@1
     SFTAB *v3; // eax@3

     v2 = 29;
     while ( sfptrs[v2] )
     {
          --v2;
          if ( v2 < 0 )
          {
               fwrite("allsfpt: no pointer space available\n", 1u, 0x24u, stderr);
               exit(1);
          }
     }
     sfptrs[v2] = a2;
     v3 = 0;
     if ( a1 )
          v3 = (SFTAB *)&sfarr.TableAddr[8 * (a1 - 1)];
     *a2 = v3;
}

void dallsfpt(SFTAB **a1)
{
     signed int v1; // eax@1

     v1 = 29;
     while ( sfptrs[v1] != a1 )
     {
          --v1;
          if ( v1 < 0 )
               return;
     }
     sfptrs[v1] = 0;
}

void movesfptrs(SFTAB *a1, SFTAB *a2)
{
     signed int v2; // ecx@1
     SFTAB **v3; // edx@3

     v2 = 29;
     do
     {
          if ( sfptrs[v2] )
          {
               v3 = sfptrs[v2];
               *v3 = (SFTAB *)((char *)a2 + ((char *)*v3 - (char *)a1));
          }
          --v2;
     }
     while ( v2 >= 0 );
}
short getramem(void)
{
     CLArrayPtr *v0; // esi@1
     short v1; // ax@3
     int v2; // edx@4
     short v3; // ax@4
     short result; // ax@5

     v0 = &raarr + curraarr;
     if ( !v0->MaxAvail )
          v0->TableAddr = (char *)mmalloc(0);
     v1 = v0->NextElement;
     if ( v1 == v0->MaxAvail )
     {
          v2 = v0->MaxAvail;
          v3 = v1 + 10;
          v0->MaxAvail = v3;
          v0->TableAddr = (char *)mrealloc(v0->TableAddr, 12 * v2, 12 * (unsigned short)v3);
     }
     result = v0->NextElement + 1;
     v0->NextElement = result;
     return result;
}

short getkxmem(void)
{
     CLArrayPtr *v0; // edi@1
     short v1; // ax@3
     int v2; // edx@4
     short v3; // ax@4
     KXTAB *v4; // esi@4
     KXTAB *v5; // eax@4
     short result; // ax@5

     v0 = &kxarr + curkxarr;
     if ( !v0->MaxAvail )
          v0->TableAddr = (char *)mmalloc(0);
     v1 = v0->NextElement;
     if ( v1 == v0->MaxAvail )
     {
          v2 = v0->MaxAvail;
          v3 = v1 + 10;
          v0->MaxAvail = v3;
          v4 = (KXTAB *)v0->TableAddr;
          v5 = (KXTAB *)mrealloc(v0->TableAddr, v2 << 6, (unsigned short)v3 << 6);
          v0->TableAddr = (char *)v5;
          movekxptrs(v4, v5);
     }
     result = v0->NextElement + 1;
     v0->NextElement = result;
     return result;
}

void dallkxpt(KXTAB **kxtab)
{
     signed int v1; // eax@1

     v1 = 29;
     while ( kxptrs[v1] != kxtab )
     {
          --v1;
          if ( v1 < 0 )
               return;
     }
     kxptrs[v1] = 0;
}
void allkxpt(unsigned short a1, KXTAB **a2)
{
     signed int v2; // eax@1
     KXTAB *v3; // eax@3

     v2 = 29;
     while ( kxptrs[v2] )
     {
          --v2;
          if ( v2 < 0 )
          {
               fwrite("allkxpt: no pointer space available\n", 1u, 0x24u, stderr);
               exit(1);
          }
     }
     kxptrs[v2] = a2;
     v3 = 0;
     if ( a1 )
          v3 = (KXTAB *)&kxarr.TableAddr[64 * a1 - 64];
     *a2 = v3;
}

void movekxptrs(KXTAB *a1, KXTAB *a2)
{
     signed int v2; // ecx@1
     KXTAB **v3; // edx@3

     v2 = 29;
     do
     {
          if ( kxptrs[v2] )
          {
               v3 = kxptrs[v2];
               *v3 = (KXTAB *)((char *)a2 + ((char *)*v3 - (char *)a1));
          }
          --v2;
     }
     while ( v2 >= 0 );
}

short getptabp(short a1)
{
	CLArrayPtr *PTarr; // edx@1
	unsigned short v3; // edx@4

	PTarr = &ptarr + (unsigned short)curptarr;
	
	if ( a1 > PTarr->NextElement )
		__assert_fail("seq <= pt->nextel", "getpt.c", 35, "getptabp");

	if ( a1 == PTarr->NextElement )
	{
		v3 = getptmem();

		if ( a1 + 1 != v3 )
			__assert_fail("seq+1 == ptidx", "getpt.c", 45, "getptabp");
	}
	else
	{
		v3 = a1 + 1;
	}
	//printf("getptabp(%d) returned %d\n",a1, v3);
	return v3;
}

PTAB* PTARR(unsigned short PTABno)
{
	//printf("PTARR(%d) \n", PTABno);
	if ( PTABno )
		return (PTAB *)&ptarr.TableAddr[8 * (PTABno - 1)];
	return 0;
}

int newltab()
{
  int v0; // edi@2
  LTAB **v1; // eax@4
  LTAB **v2; // edx@5
  unsigned int v4; // [sp+18h] [bp-10h]@0

  if ( no_ltabs )
  {
    v0 = no_ltabs + 1;
    v4 = lt - ltab;
  }
  else
  {
    v0 = 0;
  }
  v1 = (LTAB **)mrealloc(ltab, 4 * v0, 4 * no_ltabs + 8);
  ltab = v1;
  if ( v0 )
    v2 = &v1[v4];
  else
    v2 = ltab;
  lt = v2;
  return no_ltabs++ + 1;
}

int newbtab()
{
     int v0; // edx@2

     if ( no_btabs )
          v0 = no_btabs + 1;
     else
          v0 = 0;
     btab = (BTAB *)mrealloc(btab, 72 * v0, 72 * no_btabs + 144);
     return no_btabs++ + 1;
}

short getrdmem()
{
     CLArrayPtr *v0; // edi@1
     short v1; // ax@3
     int v2; // edx@4
     short v3; // ax@4
     RDTAB *v4; // esi@4
     RDTAB *v5; // eax@4
     short result; // ax@5

     v0 = &rdarr + currdarr;
     if ( !v0->MaxAvail )
          v0->TableAddr = (char *)mmalloc(0);
     v1 = v0->NextElement;
     if ( v1 == v0->MaxAvail )
     {
          v2 = v0->MaxAvail;
          v3 = v1 + 50;
          v0->MaxAvail = v3;
          v4 = (RDTAB *)v0->TableAddr;
          v5 = (RDTAB *)mrealloc(v0->TableAddr, 12 * v2, 12 * (unsigned short)v3);
          v0->TableAddr = (char *)v5;
          moverdptrs(v4, v5);
     }
     result = v0->NextElement + 1;
     v0->NextElement = result;
     return result;
}

short getstrmem(int a1)
{
     CLStrArray *v1; // esi@3
     int v2; // edx@6
     size_t v3; // eax@6
     short v4; // ax@7

     if ( a1 > 199 )
          __assert_fail("amt < 200", "getmem.c", 0x203u, "getstrmem");
     v1 = &strarr + curstrarr;
     if ( !v1->StrMaxSize )
          v1->StringTable = (char *)mmalloc(0);
     if ( v1->StrTableSize + a1 >= v1->StrMaxSize )
     {
          v2 = v1->StrMaxSize;
          v3 = v1->StrMaxSize + 200;            // blocks of 200bytes at a time
          v1->StrMaxSize = v3;
          v1->StringTable = (char *)mrealloc(v1->StringTable, v2, v3);
     }
     v4 = v1->StrTableSize;
     v1->StrTableSize += a1;
     return v4 + 1;
}

void newitab(void)
{
     int v0; // edi@2
     ITAB *v1; // eax@4
     unsigned int v2; // [sp+18h] [bp-10h]@0

     if ( no_itabs )
     {
          v0 = no_itabs + 1;
          v2 = it - itab;
     }
     else
     {
          v0 = 0;
     }
     v1 = (ITAB *)mrealloc(itab, 16 * v0, 16 * no_itabs + 32);
     itab = v1;
     if ( v0 )
          it = &v1[v2];
     else
          it = itab;
     ++no_itabs;
}

#endif
