#ifndef OPENSHARE_C
#define OPENSHARE_C

#include "DBdefs.h"
#include "cl4.h"
//#define _LARGEFILE64_SOURCE

short _oshare(char *a1,char *a2)
{
	*a2 = 0;
	return open64(a1, 2);
}

#endif
