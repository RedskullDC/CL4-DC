#ifndef LEULCK_C
#define LEULCK_C

int leulck(int *a1)
{
    short v1; // ST00_2@1
    short v2; // ax@1
    PTAB *ptab; // edi@1
    int v4; // eax@2
    int v7; // [sp+0h] [bp-18h]@5

    v1 = (*a1)++;
    v2 = getptabp(v1);
    ptab = PTARR(v2);
    ptab->OpCode = 400;					// Appears superfluous?
    ptab->SrcLineNo = lla;
    symbol = getsym();
    if ( symbol == 70 )                 // all
    {
		ptab->Operand = 0;
		ptab->OpCode = 910;
		symbol = getsym();
		return 1;                       // success exit
	}
	if ( symbol == 2230 )               // string literal
    {
		v4 = findtd(sym, -1);           // -1 == look in all open DBases
        if ( v4 >= 0 )
		{
			ptab->Operand = v4;
			ptab->OpCode = 910;
			symbol = getsym();
		    return 1;                   // success exit
		}
        v7 = 14;                        // "table not open"
	}
    else
    {
        if ( symbol == 930 )
			v7 = 40;                    // "missing table/alias"
		else
			v7 = 39;                    // "invalid table/alias"
	}
    loaderr(v7, sym);
    return 0;                           // error exit
}

#endif
