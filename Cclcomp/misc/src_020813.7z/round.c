#ifndef CLROUND_C
#define CLROUND_C

#include "DBdefs.h"
#include "cl4.h"

double clround(double a1, char FLDtype)
{
	int Negative; // esi@1
	double result; // fst7@1
	short v4; // ax@4
	long double v6; // fst7@5
	long double v7; // fst6@5
	long double v8; // fst5@5
	short v9; // dx@5
	long double v10; // fst4@6
	long double v12; // t2@8
	long double v13; // fst4@8
	long double v17; // [sp+8h] [bp-20h]@1

	v17 = (long double)a1;
	Negative = 0;
	result = 0.0;
	if ( a1 != 0.0 )
	{
		if ( a1 < 0.0 )
		{
			Negative = 1;
			//BYTE7(v17) ^= 0x80u;		//flip high bit
			v17 = -v17;			// is same as?
		}

		// only round floating point values. Var types: 0-9
		v4 = typedp(FLDtype);
		//printf("clround : v4 = %d\n",v4);
		if ( v4 <= 9 )
		{
			v6 = (long double)(long int)v17;// work out fractional part
			v7 = v17 - v6;	
			
			//printf("clround v7 = %lg\n",v7);
			// work out dec place to round on:
			v8 = 100.0;
			v9 = v4 - 1;
			if ( v4 != 0 )
			{
				v10 = 10.0;
				do
				{
					v8 *= v10;
					--v9;
				}
				while ( v9 != -1 );
			}
			//printf("clround v8 = %lg\n",v8);

			// do actual rounding
			v12 = v7 * v8 + 0.5000000001;
			//printf("clround v12a = %lg\n",v12);
			v12 = (long double)(long int)v12;
			//printf("clround v12b = %lg\n",v12);
			v12 /= v8;
			//printf("clround v12c = %lg\n",v12);
			v13 = v8 / 100.0;
			//printf("clround v13 = %lg\n",v13);
			v12 = (long double)(long int)(v12 * v13 + 0.5000000001);
			//printf("clround v12d = %lg\n",v12);
			v17 = v6 + (v12 / v13);
			//printf("clround v17 = %lg\n",v17);
		}
		
		result = (double)v17;
		if ( Negative )
			result = (double)-v17;
	}
	//printf("clround(%g,%c) returns %g\n",a1,FLDtype,result);

	return result;
}

#endif
